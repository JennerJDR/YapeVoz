package pe.pagovoz

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences(PaymentNotificationListener.PREFS, MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var screen = 0
    private val purple = Color.rgb(107,53,201)
    private val dark = Color.rgb(36,20,90)
    private val green = Color.rgb(21,148,71)
    private val bg = Color.rgb(250,249,253)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        firstLaunchSetup()
        PaymentNotificationListener.syncDefaultVoice(this)
        PaymentWatchdogService.start(this)
    }

    private fun firstLaunchSetup() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top = LinearLayout(this).apply { setPadding(20,22,14,18); gravity=Gravity.CENTER_VERTICAL; setBackgroundColor(dark) }
        val title = TextView(this).apply { text="Pago Voz Pro"; textSize=24f; setTextColor(Color.WHITE); setTypeface(typeface,1) }
        top.addView(title, LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
        val mode = TextView(this).apply { text="☀"; textSize=24f; setTextColor(Color.WHITE); setPadding(12,4,12,4); setOnClickListener{toggleTheme(this)} }
        top.addView(mode)
        root.addView(top)
        content = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,10) }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))
        val nav = LinearLayout(this).apply { setPadding(8,8,8,8); setBackgroundColor(Color.WHITE) }
        nav.addView(navButton("Inicio"){show(0)}, LinearLayout.LayoutParams(0,58,1f))
        nav.addView(navButton("Configuración"){show(1)}, LinearLayout.LayoutParams(0,58,1f))
        nav.addView(navButton("Resumen"){show(2)}, LinearLayout.LayoutParams(0,58,1f))
        root.addView(nav)
        setContentView(root)
        show(0)
    }

    private fun navButton(text:String, click:()->Unit)=Button(this).apply{this.text=text;setTextColor(dark);setAllCaps(false);setOnClickListener{click()}}
    private fun show(which:Int){screen=which;content.removeAllViews();when(which){0->home();1->settings();2->summary()}}
    private fun card():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,14,16,14);setBackgroundColor(Color.WHITE);elevation=3f}
    private fun addSpace(dp:Int=12){content.addView(Space(this),LinearLayout.LayoutParams(1,dp))}
    private fun sectionTitle(t:String)=TextView(this).apply{text=t;textSize=18f;setTextColor(dark);setTypeface(typeface,1);setPadding(0,8,0,4)}
    private fun sourceCard(label:String, sub:String, key:String, icon:String){val c=card();val row=LinearLayout(this).apply{gravity=Gravity.CENTER_VERTICAL};val i=TextView(this).apply{text=icon;textSize=28f};row.addView(i,LinearLayout.LayoutParams(48,48));val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};texts.addView(TextView(this).apply{text=label;textSize=17f;setTextColor(dark);setTypeface(typeface,1)});texts.addView(TextView(this).apply{text=sub;textSize=12f;setTextColor(Color.GRAY)});row.addView(texts,LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f));val sw=Switch(this).apply{isChecked=prefs.getBoolean(key,true);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean(key,v).apply()}};row.addView(sw);c.addView(row);content.addView(c)}
    private fun home(){content.addView(TextView(this).apply{text="Tus pagos, ahora en voz";textSize=28f;setTextColor(dark);setTypeface(typeface,1)});content.addView(TextView(this).apply{text="Activa cada fuente por separado.";textSize=14f;setTextColor(Color.GRAY)});addSpace(16);sourceCard("Yape","Escuchar pagos recibidos por Yape","yape_enabled","🟣");addSpace();sourceCard("Banco Falabella","Escuchar abonos y pagos recibidos","falabella_enabled","🟢");addSpace(16);val c=card();c.addView(TextView(this).apply{text="Estado del lector";textSize=17f;setTextColor(green);setTypeface(typeface,1)});c.addView(TextView(this).apply{text=if(PaymentNotificationListener.isConnected(this@MainActivity))"Activo y conectado a notificaciones" else "Activa el acceso a notificaciones en Configuración";setTextColor(Color.DKGRAY)});content.addView(c)}
    private fun settings(){content.addView(sectionTitle("Voz y TTS"));val c=card();val voice=Button(this).apply{text="Seleccionar voz";setAllCaps(false);setOnClickListener{startActivity(Intent("com.android.settings.TTS_SETTINGS"))}};c.addView(voice);c.addView(Button(this).apply{text="▶  Probar voz";setAllCaps(false);setOnClickListener{PaymentNotificationListener.testSpeech(this@MainActivity)}});content.addView(c);addSpace();content.addView(sectionTitle("Información del pagador"));val names=RadioGroup(this).apply{orientation=RadioGroup.VERTICAL};val first=RadioButton(this).apply{id=View.generateViewId();text="Solo nombre"};val full=RadioButton(this).apply{id=View.generateViewId();text="Nombre y apellido"};names.addView(first);names.addView(full);if(prefs.getString(PaymentNotificationListener.KEY_NAME_MODE,PaymentNotificationListener.NAME_FIRST)==PaymentNotificationListener.NAME_FULL)full.isChecked=true else first.isChecked=true;names.setOnCheckedChangeListener{_,id->prefs.edit().putString(PaymentNotificationListener.KEY_NAME_MODE,if(id==full.id)PaymentNotificationListener.NAME_FULL else PaymentNotificationListener.NAME_FIRST).apply()};content.addView(names);addSpace();content.addView(sectionTitle("Información del pago"));val pay=card();pay.addView(Switch(this).apply{text="Leer monto";isChecked=prefs.getBoolean(PaymentNotificationListener.KEY_READ_AMOUNT,true);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean(PaymentNotificationListener.KEY_READ_AMOUNT,v).apply()}});pay.addView(Switch(this).apply{text="Leer código de seguridad";isChecked=prefs.getBoolean(PaymentNotificationListener.KEY_READ_CODE,false);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean(PaymentNotificationListener.KEY_READ_CODE,v).apply()}});content.addView(pay);addSpace();content.addView(sectionTitle("Notificaciones"));val n=card();n.addView(Switch(this).apply{text="Leer solo en modo normal";isChecked=prefs.getBoolean(PaymentNotificationListener.KEY_RESPECT_SILENT,true);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean(PaymentNotificationListener.KEY_RESPECT_SILENT,v).apply()}});content.addView(n);addSpace();content.addView(sectionTitle("Permisos"));permissionButton("Acceso a notificaciones"){startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))};permissionButton("Batería sin restricciones"){try{startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:$packageName")))}catch(_:Exception){startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}};permissionButton("Autoencendido / inicio automático"){openAutoStart()};}
    private fun permissionButton(t:String, click:()->Unit){content.addView(Button(this).apply{text=t;setAllCaps(false);setOnClickListener{click()}});addSpace(6)}
    private fun summary(){content.addView(TextView(this).apply{text="Resumen";textSize=28f;setTextColor(dark);setTypeface(typeface,1)});content.addView(TextView(this).apply{text="Historial combinado de Yape y Banco Falabella";textSize=14f;setTextColor(Color.GRAY)});addSpace(14);val c=card();c.addView(TextView(this).apply{text=PaymentNotificationListener.getHistoryText(this@MainActivity);textSize=15f;setTextColor(Color.DKGRAY)});content.addView(c)}
    private fun openAutoStart(){val i=Intent().apply{component=ComponentName("com.miui.securitycenter","com.miui.permcenter.autostart.AutoStartManagementActivity")};try{if(i.resolveActivity(packageManager)!=null){startActivity(i);return}}catch(_:Exception){};startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName")))}
    private fun toggleTheme(v:TextView){v.text=if(v.text=="☀")"🌙" else "☀";Toast.makeText(this,"Modo claro/oscuro: base preparada",Toast.LENGTH_SHORT).show()}
}
