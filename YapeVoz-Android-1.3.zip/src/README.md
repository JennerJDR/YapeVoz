# Yape Voz 1.2

Aplicación Android que escucha exclusivamente las notificaciones de la app Yape (`com.bcp.innovacxion.yapeapp`) y anuncia por voz los pagos recibidos.

Incluye:
- detección basada en monto, sin depender de una frase exacta de Yape;
- filtro para no leer códigos de seguridad/OTP;
- voz en español y volumen de notificaciones;
- control para modo normal/silencio/DND;
- selector de lectura del nombre: solo nombre, nombre y apellido, apellido y nombre;
- prueba de voz;
- pantalla morada estilo Yape con botones blancos;
- icono "Yape Voz" en blanco sobre morado.
