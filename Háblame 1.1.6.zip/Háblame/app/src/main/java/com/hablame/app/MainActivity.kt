package com.hablame.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.regex.Pattern
import kotlin.math.roundToInt

object Prefs {
    private const val P = "hablame_prefs"
    private fun p(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)
    fun getBool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun getInt(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun getFloat(c: Context, k: String, d: Float) = p(c).getFloat(k, d)
    fun setFloat(c: Context, k: String, v: Float) = p(c).edit().putFloat(k, v).apply()
    fun getString(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun setString(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

object TextCleaner {
    private val emoji = Pattern.compile("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}\\x{1F3FB}-\\x{1F3FF}]")

    fun cleanName(value: CharSequence?): String {
        if (value == null) return ""
        val s = emoji.matcher(value.toString()).replaceAll("")
        return s.replace(Regex("[\\p{So}\\p{Cn}]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun cleanContent(value: CharSequence?): String {
        if (value == null) return ""
        return value.toString().replace(Regex("\\s+"), " ").trim()
    }

    fun speakableContent(value: CharSequence?): String {
        if (value == null) return ""
        var s = cleanContent(value)
        val replacements = linkedMapOf(
            "❤️" to " corazón ", "❤" to " corazón ", "😂" to " cara llorando de risa ",
            "🤣" to " rodando de risa ", "😊" to " sonrisa ", "🙂" to " sonrisa ",
            "😀" to " cara feliz ", "😃" to " cara feliz ", "😄" to " sonrisa ",
            "😁" to " sonrisa amplia ", "😆" to " risa ", "😅" to " sonrisa nerviosa ",
            "😉" to " guiño ", "😍" to " enamorado ", "😘" to " beso ",
            "🥰" to " enamorado ", "😎" to " gafas de sol ", "😭" to " llorando ",
            "😢" to " triste ", "😡" to " enojado ", "😠" to " enojado ",
            "😱" to " asustado ", "😮" to " sorprendido ", "😴" to " durmiendo ",
            "🤔" to " pensando ", "🙄" to " poniendo los ojos en blanco ",
            "👍" to " pulgar arriba ", "👎" to " pulgar abajo ", "👏" to " aplausos ",
            "🙏" to " manos juntas ", "🔥" to " fuego ", "🎉" to " celebración ",
            "💯" to " cien por cien ", "⭐" to " estrella ", "✨" to " brillo ",
            "💔" to " corazón roto ", "💚" to " corazón verde ", "💙" to " corazón azul ",
            "💜" to " corazón morado ", "💛" to " corazón amarillo ", "🩷" to " corazón rosa ",
            "🚀" to " cohete ", "⚠️" to " advertencia ", "❗" to " exclamación ",
            "❓" to " pregunta ", "☀️" to " sol ", "🌙" to " luna", "☕" to " café ",
            "🎵" to " nota musical ", "🎶" to " notas musicales "
        )
        replacements.forEach { (emoji, word) -> s = s.replace(emoji, word) }
        return s.replace(Regex("\\s+"), " ").trim()
    }
}

object TtsEngine {
    private fun getSelectedTtsEngine(c: Context): String? = try {
        Settings.Secure.getString(c.contentResolver, "tts_default_synth")
    } catch (_: Exception) {
        null
    }

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var enginePackage: String? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private val repeatHandler = Handler(Looper.getMainLooper())
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val lock = Any()
    private var repeatToken = 0

    fun init(c: Context, onReady: (() -> Unit)? = null) {
        val app = c.applicationContext
        synchronized(lock) {
            if (tts != null && ready) {
                onReady?.invoke()
                return
            }
            audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val selectedEngine = try { getSelectedTtsEngine(app) } catch (_: Exception) { null }
            enginePackage = selectedEngine
            try {
                // Igual que Pago Voz: usar el motor TTS preferido del sistema
                // mediante el constructor estándar. Esto permite que MultiTTS
                // exponga todas las voces que realmente ofrece al usuario,
                // incluidas las voces Microsoft Neural.
                tts = TextToSpeech(app) { status -> onInitialized(app, status, onReady) }
            } catch (_: Exception) {
                tts = null
                ready = false
                onReady?.invoke()
            }
        }
    }

    private fun onInitialized(c: Context, status: Int, onReady: (() -> Unit)?) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            applySavedVoice(c)
            applySpeechRate(c)
            applyAudioAttributes(c)
        }
        onReady?.invoke()
    }

    private fun applySavedVoice(c: Context) {
        val saved = Prefs.getString(c, "tts_voice", "")
        if (saved.isBlank()) return
        try { tts?.voices?.firstOrNull { it.name == saved }?.let { tts?.voice = it } } catch (_: Exception) { }
    }

    fun ensureCurrentEngine(c: Context, onReady: (() -> Unit)? = null) {
        val app = c.applicationContext
        val selected = try { getSelectedTtsEngine(app) } catch (_: Exception) { null }
        if (tts == null || !ready || selected != enginePackage) {
            reload(app, selected, onReady)
        } else {
            applySpeechRate(app)
            applyAudioAttributes(app)
            onReady?.invoke()
        }
    }

    fun reload(c: Context, onReady: (() -> Unit)? = null) {
        val selected = try { getSelectedTtsEngine(c.applicationContext) } catch (_: Exception) { null }
        reload(c.applicationContext, selected, onReady)
    }

    private fun reload(c: Context, selectedEngine: String?, onReady: (() -> Unit)?) {
        stop()
        synchronized(lock) {
            ready = false
            enginePackage = selectedEngine
            try { tts?.shutdown() } catch (_: Exception) { }
            tts = null
        }
        init(c, onReady)
    }

    private fun speechRateFor(c: Context): Float =
        Prefs.getFloat(c, "speech_rate", 1.0f).coerceIn(0.6f, 1.4f)

    private fun applySpeechRate(c: Context) {
        try { tts?.setSpeechRate(speechRateFor(c.applicationContext)) } catch (_: Exception) { }
    }

    fun speechRate(c: Context): Float = speechRateFor(c)

    fun setSpeechRate(c: Context, rate: Float) {
        val safe = rate.coerceIn(0.6f, 1.4f)
        Prefs.setFloat(c.applicationContext, "speech_rate", safe)
        applySpeechRate(c.applicationContext)
    }

    // Háblame gestiona internamente el audio; no expone al usuario
    // un selector de canal. Los anuncios usan el canal de notificaciones,
    // igual que Pago Voz, y se apoyan en foco de audio temporal.
    private fun usageFor(@Suppress("UNUSED_PARAMETER") c: Context): Int =
        AudioAttributes.USAGE_NOTIFICATION

    private fun streamForUsage(@Suppress("UNUSED_PARAMETER") usage: Int): Int =
        AudioManager.STREAM_NOTIFICATION

    fun refreshAudioAttributes(c: Context) {
        applyAudioAttributes(c.applicationContext)
    }

    private fun applyAudioAttributes(c: Context) {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        try { tts?.setAudioAttributes(attrs) } catch (_: Exception) { }
    }

    private fun requestFocus(c: Context): Boolean {
        val am = audioManager ?: (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { audioManager = it }
        val usage = AudioAttributes.USAGE_NOTIFICATION
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        if (Build.VERSION.SDK_INT >= 26) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .build()
            focusRequest = request
            return am.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        @Suppress("DEPRECATION")
        return am.requestAudioFocus(null, streamForUsage(usage), AudioManager.AUDIOFOCUS_GAIN_TRANSIENT) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { try { am.abandonAudioFocusRequest(it) } catch (_: Exception) { } }
        } else {
            @Suppress("DEPRECATION")
            try { am.abandonAudioFocus(null) } catch (_: Exception) { }
        }
        focusRequest = null
    }

    fun speak(c: Context, text: String) {
        speakRepeated(c, text, 1)
    }

    fun speakRepeated(c: Context, text: String, count: Int) {
        if (text.isBlank()) return
        if (!ready) {
            ensureCurrentEngine(c) {
                if (ready) speakRepeated(c, text, count)
            }
            return
        }
        repeatToken++
        val token = repeatToken
        repeatHandler.removeCallbacksAndMessages(null)
        stopInternal(false)
        applySpeechRate(c)
        applyAudioAttributes(c)
        requestFocus(c)
        var remaining = count.coerceIn(1, 5)

        fun speakNext() {
            if (token != repeatToken || remaining <= 0 || !ready) {
                abandonFocus()
                return
            }
            val utteranceId = "hablame_${System.currentTimeMillis()}_${remaining}"
            val listener = object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    if (token != repeatToken) return
                    remaining--
                    if (remaining > 0) repeatHandler.postDelayed({ speakNext() }, 500L)
                    else abandonFocus()
                }
                override fun onError(id: String?) { if (token == repeatToken) abandonFocus() }
            }
            try {
                tts?.setOnUtteranceProgressListener(listener)
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), utteranceId)
            } catch (_: Exception) { abandonFocus() }
        }
        speakNext()
    }

    private fun stopInternal(abandon: Boolean) {
        try { tts?.stop() } catch (_: Exception) { }
        if (abandon) abandonFocus()
    }

    fun stop() {
        repeatToken++
        repeatHandler.removeCallbacksAndMessages(null)
        stopInternal(true)
    }

    fun loadVoicesAsync(c: Context, onResult: (List<android.speech.tts.Voice>, String?) -> Unit) {
        ensureCurrentEngine(c) {
            val engineName = enginePackage
            worker.execute {
                // Pago Voz obtiene la lista desde una instancia nueva de
                // TextToSpeech con el motor preferido del sistema. Hacemos lo
                // mismo para que MultiTTS entregue su inventario actual,
                // incluidas las voces Microsoft Neural instaladas.
                var loader: TextToSpeech? = null
                var delivered = false
                var initCallbackReceived = false

                try {
                    loader = TextToSpeech(c.applicationContext) { result ->
                        initCallbackReceived = true

                        // Algunos motores pueden llamar a onInit() antes de que
                        // el constructor haya terminado de devolver la instancia.
                        // Esperamos brevemente y luego usamos la referencia nullable,
                        // evitando referencias a propiedades lateinit locales que
                        // Kotlin no admite.
                        Handler(Looper.getMainLooper()).postDelayed({
                            if (!delivered) {
                                val currentLoader = loader
                                if (currentLoader != null) {
                                    val voices = if (result == TextToSpeech.SUCCESS) {
                                        currentLoader.voices.orEmpty()
                                            .filter { it.locale.language.equals("es", ignoreCase = true) }
                                            .distinctBy { it.name }
                                            .sortedBy { it.name.lowercase(Locale.ROOT) }
                                    } else emptyList()

                                    delivered = true
                                    onResult(voices, engineName)
                                    try { currentLoader.shutdown() } catch (_: Exception) { }
                                    loader = null
                                }
                            }
                        }, 50L)
                    }
                } catch (_: Exception) {
                    if (!initCallbackReceived && !delivered) {
                        delivered = true
                        Handler(Looper.getMainLooper()).post { onResult(emptyList(), engineName) }
                    }
                }

                if (loader == null && !initCallbackReceived && !delivered) {
                    delivered = true
                    Handler(Looper.getMainLooper()).post { onResult(emptyList(), engineName) }
                }
            }
        }
    }

    fun currentVoiceName(): String = try { tts?.voice?.name.orEmpty() } catch (_: Exception) { "" }
    fun currentEnginePackage(): String? = enginePackage
    fun setVoice(v: android.speech.tts.Voice) { if (ready) try { tts?.voice = v } catch (_: Exception) { } }
    fun setVoiceByName(name: String) {
        if (!ready || name.isBlank()) return
        try {
            tts?.voices?.firstOrNull { it.name == name }?.let { tts?.voice = it }
        } catch (_: Exception) { }
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var statusPill: TextView
    private var current = "inicio"
    private var waitingForPermissionSettings = false
    private var permissionFlowStarted = false
    private var runtimePermissionDenied = false
    private var runtimeDialogActive = false
    private var openedTtsSettings = false
    private val pageCache = mutableMapOf<String, View>()
    private var buildingCachedPage = false

    private val blue by lazy { ContextCompat.getColor(this, R.color.hab_blue) }
    private val green by lazy { ContextCompat.getColor(this, R.color.hab_green) }
    private val textColor by lazy { ContextCompat.getColor(this, R.color.hab_text) }
    private val muted by lazy { ContextCompat.getColor(this, R.color.hab_muted) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val scroll = findViewById<ScrollView>(R.id.scroll)
        setupSwipeNavigation(scroll)
        val baseTop = dp(10)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            val bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, top + baseTop, view.paddingRight, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(scroll)
        content = findViewById(R.id.page_container)
        statusPill = findViewById(R.id.service_status)
        findViewById<TextView>(R.id.app_version)?.text = "v${packageManager.getPackageInfo(packageName, 0).versionName}"
        setupBottomNav()
        TtsEngine.init(this)
        refreshStatus()
        showPage("inicio")
    }

    override fun onPause() {
        super.onPause()
        if (!waitingForPermissionSettings && !runtimeDialogActive) {
            permissionFlowStarted = false
            runtimePermissionDenied = false
        }
    }

    override fun onResume() {
        super.onResume()
        if (openedTtsSettings) {
            openedTtsSettings = false
            TtsEngine.ensureCurrentEngine(this) {
                if (current == "voice" && !isFinishing && !isDestroyed) showPage("voice")
            }
        }
        refreshStatus()
        if (waitingForPermissionSettings) {
            waitingForPermissionSettings = false
            Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 450)
        } else if (!permissionFlowStarted && !runtimePermissionDenied) {
            permissionFlowStarted = true
            Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 500)
        }
    }

    private fun continuePermissionFlow() {
        if (isFinishing || isDestroyed) return
        refreshStatus()

        if (!HablameNotificationListener.isEnabled(this)) {
            waitingForPermissionSettings = true
            try {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            return
        }

        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
            return
        }

        if (!hasPermission(Manifest.permission.READ_PHONE_STATE) ||
            (Build.VERSION.SDK_INT >= 26 && !hasPermission(Manifest.permission.READ_PHONE_NUMBERS)) ||
            !hasPermission(Manifest.permission.READ_CALL_LOG)) {
            runtimeDialogActive = true
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_PHONE_NUMBERS,
                    Manifest.permission.READ_CALL_LOG
                ), 21
            )
            return
        }

        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isBatteryOptimized()) {
            waitingForPermissionSettings = true
            openBatterySettings()
            return
        }

        if (!Prefs.getBool(this, "auto_background_prompted", false)) {
            Prefs.setBool(this, "auto_background_prompted", true)
            waitingForPermissionSettings = true
            openAutoStartSettings()
            return
        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        runtimeDialogActive = false
        val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (!allGranted) {
            runtimePermissionDenied = true
            Toast.makeText(this, "Quedan permisos pendientes. Se volverán a solicitar al entrar nuevamente.", Toast.LENGTH_LONG).show()
            refreshStatus()
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 350)
    }

    private fun setupBottomNav() {
        findViewById<View>(R.id.nav_home).setOnClickListener { showPage("inicio") }
        findViewById<View>(R.id.nav_apps).setOnClickListener { showPage("apps") }
        findViewById<View>(R.id.nav_calls).setOnClickListener { showPage("calls") }
        findViewById<View>(R.id.nav_voice).setOnClickListener { showPage("voice") }
        findViewById<View>(R.id.nav_permissions).setOnClickListener { showPage("permissions") }
        updateBottomNav("inicio")
    }

    private fun setupSwipeNavigation(scroll: ScrollView) {
        var downX = 0f
        var downY = 0f
        scroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (kotlin.math.abs(dx) > dp(72) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                        if (dx < 0) showAdjacentPage(1) else showAdjacentPage(-1)
                    }
                }
            }
            false
        }
    }

    private fun showAdjacentPage(direction: Int) {
        val pages = listOf("inicio", "apps", "calls", "voice", "permissions")
        val index = pages.indexOf(current)
        if (index < 0) return
        val next = (index + direction).coerceIn(0, pages.lastIndex)
        if (next != index) showPage(pages[next])
    }

    private fun updateBottomNav(page: String) {
        val ids = listOf(R.id.nav_home, R.id.nav_apps, R.id.nav_calls, R.id.nav_voice, R.id.nav_permissions)
        ids.forEachIndexed { index, id ->
            val item = findViewById<LinearLayout>(id)
            val active = when (index) {
                0 -> page == "inicio"
                1 -> page == "apps"
                2 -> page == "calls"
                3 -> page == "voice"
                else -> page == "permissions"
            }
            item.background = if (active) getDrawable(R.drawable.bg_nav_active) else null
            val icon = item.getChildAt(0) as? ImageView
            val label = item.getChildAt(1) as? TextView
            icon?.setColorFilter(if (active) green else blue)
            label?.setTextColor(if (active) green else blue)
            item.alpha = if (active) 1f else 0.82f
        }
    }

    private fun refreshStatus() {
        val enabled = Prefs.getBool(this, "service_enabled", true)
        val notificationOk = HablameNotificationListener.isEnabled(this)
        val phoneOk = hasPermission(Manifest.permission.READ_PHONE_STATE)
        val contactsOk = hasPermission(Manifest.permission.READ_CONTACTS)
        val listenerConnected = HablameNotificationListener.isConnected()
        val permissionsOk = notificationOk && phoneOk && contactsOk && listenerConnected
        when {
            !enabled -> {
                statusPill.text = "Servicio desactivado"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_disabled_pill)
            }
            permissionsOk -> {
                statusPill.text = "✓  Servicio activo"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_green_pill)
            }
            else -> {
                statusPill.text = "⚠  Requiere permisos"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_red_pill)
            }
        }
    }

    private fun showPage(page: String, forceRebuild: Boolean = false) {
        current = page
        updateBottomNav(page)
        val cacheable = page == "apps" || page == "calls"
        if (forceRebuild && cacheable) pageCache.remove(page)

        val cached = if (cacheable) pageCache[page] else null
        content.removeAllViews()
        if (cached != null) {
            content.addView(cached)
        } else {
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(-1, -2)
            }
            val previous = content
            buildingCachedPage = cacheable
            content = root
            when (page) {
                "inicio" -> homePage()
                "apps" -> appsPage()
                "calls" -> callsPage()
                "voice" -> voicePage()
                "permissions" -> permissionsPage()
            }
            content = previous
            buildingCachedPage = false
            if (cacheable) pageCache[page] = root
            content.addView(root)
        }
        findViewById<ScrollView>(R.id.scroll)?.post { findViewById<ScrollView>(R.id.scroll)?.scrollTo(0, 0) }
    }

    private fun homePage() {
        val enabled = Prefs.getBool(this, "service_enabled", true)
        addSectionTitle("Háblame")
        addText("Lee en voz alta llamadas y notificaciones para que estés siempre informado, sin mirar tu teléfono.", 14, muted)
        val status = card()
        status.addView(text("Estado de Háblame", 17, textColor, true))
        status.addView(space(5))
        val listenerReady = HablameNotificationListener.isEnabled(this) && HablameNotificationListener.isConnected()
        status.addView(text(when {
            !enabled -> "Háblame está desactivado. No anunciará llamadas ni notificaciones."
            listenerReady -> "Servicio conectado y escuchando notificaciones."
            HablameNotificationListener.isEnabled(this) -> "Acceso concedido, pero el servicio necesita reconectarse."
            else -> "Falta el acceso a notificaciones para poder escuchar WhatsApp y otras apps."
        }, 13, muted))
        content.addView(status)
        addSpacer(8)

        val permanentNotification = card()
        val permanentRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        permanentRow.addView(
            text("Notificación permanente", 14, textColor, true),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        val permanentSwitch = newGreenSwitch()
        permanentSwitch.isChecked = Prefs.getBool(this, "permanent_notification", true)
        permanentSwitch.setOnCheckedChangeListener { _, value ->
            Prefs.setBool(this, "permanent_notification", value)
            if (value) {
                HablameNotificationListener.updatePersistentNotification(this)
            } else {
                HablameNotificationListener.cancelPersistentNotification(this)
            }
        }
        permanentRow.addView(permanentSwitch)
        permanentNotification.addView(permanentRow)
        permanentNotification.addView(
            text(
                "Muestra “Háblame está activo” en la barra de notificaciones.",
                11, muted
            )
        )
        content.addView(permanentNotification)

        addSpacer(10)
        homeActionCard(R.drawable.ic_call, "Llamadas", if (!enabled) "Desactivadas" else if (hasPermission(Manifest.permission.READ_PHONE_STATE)) "Activadas" else "Requiere permiso") { showPage("calls") }
        homeActionCard(R.drawable.ic_bell, "Notificaciones", if (!enabled) "Desactivadas" else if (HablameNotificationListener.isEnabled(this)) "Activadas" else "Requiere acceso") { showPage("apps") }
        addSpacer(8)
        homeActionCard(R.drawable.ic_settings, "Acceso rápido a permisos", "Revisar permisos pendientes") { showPage("permissions") }
        addSpacer(10)
        val toggle = button(if (enabled) "Desactivar Háblame" else "Activar Háblame")
        toggle.background = getDrawable(if (enabled) R.drawable.bg_blue_button else R.drawable.bg_inactive_button)
        toggle.setOnClickListener {
            val next = !Prefs.getBool(this, "service_enabled", true)
            Prefs.setBool(this, "service_enabled", next)
            if (!next) {
                TtsEngine.stop()
                try { (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(1001) } catch (_: Exception) { }
            } else {
                HablameNotificationListener.requestRebind(this)
            }
            refreshStatus()
            showPage("inicio")
            Toast.makeText(this, if (next) "Háblame activado." else "Háblame desactivado.", Toast.LENGTH_SHORT).show()
        }
        content.addView(toggle)
        addSpacer(10)
        val reactivate = button("↻  Reactivar servicio")
        reactivate.background = getDrawable(R.drawable.bg_green_pill)
        reactivate.setTextColor(Color.WHITE)
        reactivate.setOnClickListener { reactivateService() }
        content.addView(reactivate)
        addText("Usa este botón solo si el servicio dejó de responder. No cambia tus configuraciones.", 11, muted)
        addSpacer(18)
    }

    private fun reactivateService() {
        Prefs.setBool(this, "service_enabled", true)
        if (!HablameNotificationListener.isEnabled(this)) {
            Toast.makeText(this, "Háblame necesita volver a tener acceso a las notificaciones.", Toast.LENGTH_LONG).show()
            waitingForPermissionSettings = true
            try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
            return
        }
        TtsEngine.ensureCurrentEngine(this)
        HablameNotificationListener.requestRebind(this)
        Handler(Looper.getMainLooper()).postDelayed({
            refreshStatus()
            showPage("inicio")
            Toast.makeText(this, if (HablameNotificationListener.isConnected()) "Servicio reactivado." else "Se solicitó la reconexión del servicio.", Toast.LENGTH_SHORT).show()
        }, 700)
    }

    private fun appsPage() {
        addSectionTitle("Aplicaciones")
        addText("Todas las aplicaciones con notificaciones pueden ser leídas. Háblame anuncia primero la aplicación y luego el título de la notificación.", 14, muted)

        val apps = listOf(
            Triple("WhatsApp", "com.whatsapp", "app_com.whatsapp"),
            Triple("Telegram", "org.telegram.messenger", "app_org.telegram.messenger"),
            Triple("Messenger", "com.facebook.orca", "app_com.facebook.orca"),
            Triple("Facebook", "com.facebook.katana", "app_com.facebook.katana"),
            Triple("Instagram", "com.instagram.android", "app_com.instagram.android"),
            Triple("TikTok", "com.zhiliaoapp.musically", "app_com.zhiliaoapp.musically"),
            Triple("Mensajes", "com.google.android.apps.messaging", "app_com.google.android.apps.messaging"),
            Triple("Gmail", "com.google.android.gm", "app_com.google.android.gm")
        )
        apps.forEach { (name, pkg, key) -> appRow(name, pkg, key) }

        val other = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("Otras aplicaciones", 15, textColor, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = newGreenSwitch()
        sw.isChecked = Prefs.getBool(this, "read_other_apps", true)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, "read_other_apps", v) }
        row.addView(sw)
        other.addView(row)
        other.addView(text("Lee la aplicación y el título de cualquier otra notificación.", 11, muted))
        content.addView(other)
        addSpacer(7)
    }

    private fun appRow(name: String, pkg: String, key: String) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        val lp = LinearLayout.LayoutParams(dp(40), dp(40))
        lp.marginEnd = dp(12)
        icon.layoutParams = lp
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
        catch (_: Exception) { icon.setImageResource(R.drawable.ic_bell) }
        row.addView(icon)
        val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        label.addView(text(name, 15, textColor, true))
        label.addView(text("Lectura de notificaciones", 11, muted))
        row.addView(label)
        val sw = newGreenSwitch()
        sw.isChecked = Prefs.getBool(this, key, true)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v) }
        row.addView(sw)
        c.addView(row)
        c.setOnClickListener { appDetail(name, pkg, key) }
        content.addView(c)
        addSpacer(7)
    }

    private fun appDetail(name: String, pkg: String, key: String) {
        content.removeAllViews()
        addBack("Aplicaciones") { showPage("apps") }
        addSectionTitle(name)
        addText("Háblame leerá la notificación que llegue de $name.", 14, muted)
        settingSwitch("Activada", Prefs.getBool(this, key, true), key) { }
        settingSwitch("Leer el título de la notificación", Prefs.getBool(this, "title_$pkg", true), "title_$pkg") { }
        settingSwitch("Leer el contenido de la notificación", Prefs.getBool(this, "content_$pkg", true), "content_$pkg") { }
        addSubTitle("Regla general")
        val rule = card()
        rule.addView(text("Emojis y símbolos del nombre de la persona o del grupo se omiten. Los emojis que estén dentro del mensaje se interpretan y se anuncian.", 13, muted))
        content.addView(rule)
    }

    private fun callsPage() {
        addSectionTitle("Llamadas")
        addText("Configura cómo quieres que se anuncien las llamadas entrantes.", 14, muted)
        settingSwitch("Contactos guardados — leer el nombre del contacto", Prefs.getBool(this, "call_contact_name", true), "call_contact_name") { }
        addSubTitle("Números desconocidos")
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val a = RadioButton(this).apply { id = View.generateViewId(); text = "Leer el número" }
        val b = RadioButton(this).apply { id = View.generateViewId(); text = "Decir “número desconocido”" }
        val c = RadioButton(this).apply { id = View.generateViewId(); text = "No anunciar" }
        group.addView(a); group.addView(b); group.addView(c)
        when (Prefs.getString(this, "unknown_mode", "number")) {
            "unknown" -> b.isChecked = true
            "none" -> c.isChecked = true
            else -> a.isChecked = true
        }
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setString(this, "unknown_mode", when (id) { b.id -> "unknown"; c.id -> "none"; else -> "number" })
        }
        content.addView(group)
        addSubTitle("Repetición del anuncio")
        val repCard = card()
        repCard.addView(text("Cuántas veces anunciar una llamada entrante", 14, textColor, true))
        val repSpinner = Spinner(this)
        val repLabels = (1..5).map { if (it == 1) "1 vez" else "$it veces" }
        repSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, repLabels)
        repSpinner.setSelection((Prefs.getInt(this, "call_repetitions", 2).coerceIn(1, 5)) - 1)
        repSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Prefs.setInt(this@MainActivity, "call_repetitions", position + 1)
            }
        }
        repCard.addView(repSpinner)
        content.addView(repCard)
        addSpacer(8)
        addSubTitle("Otras opciones")
        val soundRule = card()
        val soundRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val soundCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val soundTitle = text("", 14, textColor, true)
        val soundDescription = text("", 12, muted)
        soundCol.addView(soundTitle)
        soundCol.addView(soundDescription)
        soundRow.addView(soundCol)
        val soundSwitch = newGreenSwitch()
        val respectSoundMode = Prefs.getBool(this, "normal_only", true)
        soundSwitch.isChecked = respectSoundMode
        fun updateSoundText(enabled: Boolean) {
            if (enabled) {
                soundTitle.text = "Respetar modo de sonido"
                soundDescription.text =
                    "En silencio, vibración o No molestar no realizará anuncios."
            } else {
                soundTitle.text = "Ignorar modo de sonido"
                soundDescription.text =
                    "También realizará anuncios en silencio, vibración o No molestar."
            }
        }
        updateSoundText(respectSoundMode)
        soundSwitch.setOnCheckedChangeListener { _, value ->
            Prefs.setBool(this, "normal_only", value)
            updateSoundText(value)
        }
        soundRow.addView(soundSwitch)
        soundRule.addView(soundRow)
        content.addView(soundRule)
    }

    private fun voicePage() {
        addSectionTitle("Voz")
        addText("Configura la voz del motor TTS seleccionado en Android. Háblame gestiona automáticamente el audio de sus anuncios.", 14, muted)

        val c = card()
        c.addView(text("Voces del TTS actual", 13, textColor, true))
        val settings = button("⚙  Configurar TTS")
        settings.setOnClickListener {
            openedTtsSettings = true
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
        }
        c.addView(settings)
        addSpacer(6)

        val engineInfo = text("Motor TTS: detectando…", 11, muted)
        c.addView(engineInfo)
        addSpacer(3)
        val spinner = Spinner(this)
        spinner.isEnabled = false
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Cargando voces del motor TTS…"))
        c.addView(spinner)
        addSpacer(5)

        val test = button("▶  Probar voz")
        test.setOnClickListener { TtsEngine.speak(this, "Esta es una prueba de voz de Háblame.") }
        c.addView(test)
        content.addView(c)

        addSpacer(8)
        addSubTitle("Velocidad de lectura")
        val speedCard = card()
        speedCard.addView(text("Esta velocidad es exclusiva de Háblame. No modifica la velocidad TTS del teléfono ni de otras aplicaciones.", 12, muted))
        val initialRate = TtsEngine.speechRate(this)
        val speedValue = text("Velocidad: ${String.format(Locale.getDefault(), "%.1f", initialRate)}×", 15, textColor, true)
        speedCard.addView(speedValue)
        val speedBar = SeekBar(this).apply {
            max = 8
            progress = ((initialRate - 0.6f) * 10f).roundToInt().coerceIn(0, 8)
            contentDescription = "Velocidad de lectura de Háblame"
        }
        speedCard.addView(speedBar, LinearLayout.LayoutParams(-1, dp(48)))
        speedCard.addView(text("0,6×  ·  0,8×  ·  1,0×  ·  1,2×  ·  1,4×", 11, muted))
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val rate = 0.6f + progress * 0.1f
                speedValue.text = "Velocidad: ${String.format(Locale.getDefault(), "%.1f", rate)}×"
                if (fromUser) TtsEngine.setSpeechRate(this@MainActivity, rate)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        val testSpeed = button("▶  Probar velocidad")
        testSpeed.setOnClickListener { TtsEngine.speak(this, "Esta es una prueba para comprobar la velocidad de lectura de Háblame.") }
        speedCard.addView(testSpeed)
        content.addView(speedCard)

        TtsEngine.loadVoicesAsync(this) { voices, enginePackage ->
            if (isFinishing || isDestroyed || current != "voice") return@loadVoicesAsync
            val engineLabel = try {
                if (!enginePackage.isNullOrBlank()) packageManager.getApplicationLabel(packageManager.getApplicationInfo(enginePackage, 0)).toString()
                else "Motor TTS del sistema"
            } catch (_: Exception) { enginePackage ?: "Motor TTS del sistema" }
            engineInfo.text = "Motor TTS: $engineLabel"

            val labels = voices.map { voice ->
                val locale = voice.locale.toLanguageTag().ifBlank { voice.locale.displayLanguage }
                "${voice.name} — $locale"
            }.ifEmpty { listOf("No hay voces en español instaladas en este motor") }

            spinner.isEnabled = voices.isNotEmpty()
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

            val saved = Prefs.getString(this, "tts_voice", "")
            val currentVoice = TtsEngine.currentVoiceName()
            val idx = voices.indexOfFirst { it.name == saved || it.name == currentVoice }
            if (idx >= 0) spinner.setSelection(idx, false)

            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position in voices.indices) {
                        TtsEngine.setVoiceByName(voices[position].name)
                        Prefs.setString(this@MainActivity, "tts_voice", voices[position].name)
                    }
                }
            }
        }

        addSpacer(8)
        addSpacer(8)
        addSubTitle("Volumen de notificaciones")
        val volumeCard = card()
        volumeCard.addView(text("Controla el volumen de los anuncios de Háblame sin modificar la velocidad ni la configuración TTS de otras aplicaciones.", 12, muted))
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxNotification = audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION).coerceAtLeast(1)
        val currentNotification = audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION).coerceIn(0, maxNotification)
        val volumeValue = text("Volumen: ${currentNotification * 100 / maxNotification}%", 15, textColor, true)
        volumeCard.addView(volumeValue)
        val volumeBar = SeekBar(this).apply {
            max = maxNotification
            progress = currentNotification
            contentDescription = "Volumen de notificaciones de Háblame"
        }
        volumeCard.addView(volumeBar, LinearLayout.LayoutParams(-1, dp(48)))
        volumeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val safe = progress.coerceIn(0, maxNotification)
                volumeValue.text = "Volumen: ${safe * 100 / maxNotification}%"
                if (fromUser) audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION, safe, 0)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        content.addView(volumeCard)

        addSpacer(8)
        settingSwitch("Solo en modo sonido normal", Prefs.getBool(this, "normal_only", true), "normal_only") { }
        addText("No hablar en silencio, vibración o No molestar.", 12, muted)
        val rule = card()
        rule.addView(text("Emojis y símbolos en nombres y grupos", 14, textColor, true))
        rule.addView(text("Se omiten automáticamente en el nombre de la persona o del grupo. Si aparecen dentro del mensaje, Háblame los interpreta al hablar.", 12, muted))
        content.addView(rule)
    }

    private fun permissionsPage() {
        addSectionTitle("Permisos")
        addText("Al entrar por primera vez, Háblame solicita automáticamente los permisos que falten.", 14, muted)
        permissionRow("Acceso a notificaciones", HablameNotificationListener.isEnabled(this)) {
            waitingForPermissionSettings = true
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        permissionRow("Notificaciones de Háblame", Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        permissionRow("Batería sin restricciones", !isBatteryOptimized()) {
            waitingForPermissionSettings = true
            openBatterySettings()
        }
        permissionRow("Auto encendido en segundo plano", Prefs.getBool(this, "auto_background_prompted", false)) {
            openAutoStartSettings()
        }
        permissionRow("Teléfono", hasPermission(Manifest.permission.READ_PHONE_STATE) && hasPermission(Manifest.permission.READ_CALL_LOG)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_CALL_LOG), 21)
        }
        permissionRow("Contactos", hasPermission(Manifest.permission.READ_CONTACTS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
        }
        permissionRow("Texto a voz", true) {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { }
        }
    }

    private fun permissionRow(title: String, ok: Boolean, action: () -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        icon.setImageResource(if (ok) R.drawable.ic_shield else R.drawable.ic_bell)
        row.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(text(title, 14, textColor, true))
        col.addView(text(if (ok) "Permitido" else "Requiere atención", 12, if (ok) green else ContextCompat.getColor(this, R.color.hab_red)))
        row.addView(col)
        row.addView(text(if (ok) "✓" else "›", 20, if (ok) green else blue, true))
        c.addView(row)
        c.setOnClickListener { action() }
        content.addView(c)
        addSpacer(7)
    }

    private fun newGreenSwitch(): androidx.appcompat.widget.SwitchCompat {
        val sw = androidx.appcompat.widget.SwitchCompat(this)
        val checked = intArrayOf(android.R.attr.state_checked)
        val unchecked = intArrayOf(-android.R.attr.state_checked)
        sw.thumbTintList = ColorStateList(arrayOf(checked, unchecked), intArrayOf(green, Color.rgb(97, 97, 97)))
        sw.trackTintList = ColorStateList(arrayOf(checked, unchecked), intArrayOf(ContextCompat.getColor(this, R.color.hab_green_light), Color.rgb(210, 210, 210)))
        return sw
    }

    private fun settingSwitch(label: String, checked: Boolean, key: String, onChanged: (Boolean) -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(label, 14, textColor, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = newGreenSwitch()
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v); onChanged(v) }
        row.addView(sw)
        c.addView(row)
        content.addView(c)
        addSpacer(7)
    }

    private fun homeActionCard(iconRes: Int, title: String, sub: String, onClick: () -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        icon.setImageResource(iconRes)
        row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(text(title, 15, textColor, true))
        col.addView(text(sub, 12, green))
        row.addView(col)
        row.addView(text("✓", 20, green, true))
        c.addView(row)
        c.setOnClickListener { onClick() }
        content.addView(c)
        addSpacer(7)
    }

    private fun addBack(label: String, onClick: () -> Unit) {
        val b = TextView(this).apply {
            text = "‹  $label"; textSize = 14f; setTextColor(blue); setPadding(0, 4, 0, 12); setOnClickListener { onClick() }
        }
        content.addView(b)
    }

    private fun addSectionTitle(s: String): TextView {
        val t = text(s, 25, textColor, true)
        t.setPadding(0, 4, 0, 4)
        content.addView(t)
        return t
    }

    private fun addSubTitle(s: String) { content.addView(text(s, 14, textColor, true)); addSpacer(4) }
    private fun addText(s: String, size: Int, color: Int) { content.addView(text(s, size, color, false)); addSpacer(7) }
    private fun addSpacer(n: Int) { content.addView(space(n)) }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(2, 2, 2, 2) }
    private fun space(h: Int) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = getDrawable(R.drawable.bg_card); setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = LinearLayout.LayoutParams(-1, -2) }
    private fun button(label: String) = Button(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE); background = getDrawable(R.drawable.bg_blue_button); isAllCaps = false; minHeight = dp(48) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun openAutoStartSettings() {
        val manufacturer = Build.MANUFACTURER.lowercase(Locale.getDefault())
        val intents = mutableListOf<Intent>()
        if (manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")) {
            intents.add(Intent("miui.intent.action.OP_AUTO_START").setComponent(ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")))
        }
        if (manufacturer.contains("oppo") || manufacturer.contains("realme")) {
            intents.add(Intent().setComponent(ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")))
        }
        if (manufacturer.contains("huawei")) {
            intents.add(Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")))
        }
        intents.add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply { data = android.net.Uri.parse("package:$packageName") })
        for (intent in intents) {
            try {
                startActivity(intent)
                return
            } catch (_: Exception) { }
        }
        try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { }
    }

    private fun openBatterySettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = android.net.Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    private fun isBatteryOptimized(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        return !pm.isIgnoringBatteryOptimizations(packageName)
    }
}
