# Yape Voz Pro 2.6.2

Mejoras de esta versión:
- Mantiene la detección de Yape y notificaciones bancarias de 2.6.2.
- Mantiene selección de solo primer nombre / nombre y apellido.
- Mantiene código de seguridad opcional.
- La velocidad de voz guardada se aplica inmediatamente antes de cada anuncio.
- Nuevo botón Restablecer defecto (1.00×).
- La velocidad seleccionada permanece guardada al cerrar y abrir la aplicación.
- Nueva frase de aviso: "¡Pago recibido! [nombre] te yapeó [monto]. Código [código]."
- Pausas breves naturales mediante puntuación.
