package pe.pagovoz

import android.Manifest
import android.app.Dialog
import android.app.DatePickerDialog
import android.net.Uri
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.speech.tts.Voice
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences(PaymentNotificationListener.PREFS, MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var screen = 0
    private var permissionFlowBusy = false
    private var historyFilterDate: String? = null
    private val navButtons = mutableListOf<TextView>()

    private val purple = Color.rgb(101, 37, 194)
    private val purpleDark = Color.rgb(48, 14, 105)
    private val purpleSoft = Color.rgb(244, 238, 255)
    private val green = Color.rgb(17, 184, 105)
    private val greenDark = Color.rgb(17, 129, 75)
    private val lightBg = Color.rgb(247, 246, 251)
    private val lightText = Color.rgb(29, 27, 35)
    private val muted = Color.rgb(105, 100, 116)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        PaymentNotificationListener.syncDefaultVoices(this)
        window.decorView.postDelayed({ continuePermissionFlow() }, 500)
    }

    override fun onResume() {
        super.onResume()
        if (!permissionFlowBusy) window.decorView.postDelayed({ continuePermissionFlow() }, 350)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(lightBg)
        }

        if (screen == 0) {
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(18), dp(24), dp(18), dp(18))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(purple, purpleDark)
                ).apply {
                    cornerRadii = floatArrayOf(0f,0f,0f,0f,dp(26).toFloat(),dp(26).toFloat(),dp(26).toFloat(),dp(26).toFloat())
                }
            }

            header.addView(TextView(this).apply {
                text = "v${BuildConfig.VERSION_NAME}"
                textSize = 12f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.END
                setPadding(0, 0, dp(2), dp(2))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(20)))

            val logo = ImageView(this).apply {
                setImageResource(R.drawable.pago_voz_mark)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            header.addView(logo, LinearLayout.LayoutParams(dp(142), dp(142)).apply { topMargin = dp(2) })

            header.addView(TextView(this).apply {
                text = "Tu asistente de cobros"
                textSize = 17f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
            header.addView(TextView(this).apply {
                text = "Te anuncia tus pagos por voz"
                textSize = 13f
                setTextColor(Color.rgb(235, 225, 255))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(25)))

            root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(245)))
        } else {
            val strip = TextView(this).apply {
                text = if (screen == 1) "Configuración" else "Resumen"
                textSize = 20f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), 0, dp(20), 0)
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(purple, purpleDark)
                )
            }
            root.addView(strip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(7))
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
        }
        navButtons.clear()
        val navInicio = navButton("⌂\nInicio", 0)
        val navConfig = navButton("⚙\nConfiguración", 1)
        val navResumen = navButton("ⓘ\nResumen", 2)
        navButtons.add(navInicio)
        navButtons.add(navConfig)
        navButtons.add(navResumen)
        nav.addView(navInicio, LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(navConfig, LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(navResumen, LinearLayout.LayoutParams(0, dp(58), 1f))
        root.addView(nav)
        setContentView(root)
        show(screen)
    }

    private fun navButton(label: String, target: Int): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setOnClickListener { show(target) }
        setTextColor(if (screen == target) purple else muted)
    }

    private fun show(which: Int) {
        screen = which
        content.removeAllViews()
        navButtons.forEachIndexed { index, button ->
            button.setTextColor(if (index == screen) purple else muted)
        }
        when (which) { 0 -> home(); 1 -> settings(); else -> summary() }
    }

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(color)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(Color.WHITE, 18)
        elevation = dp(1).toFloat()
    }

    private fun title(text: String, size: Float = 27f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(lightText)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun subtitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(muted)
        setPadding(0, dp(3), 0, 0)
    }

    private fun gap(h: Int = 12) { content.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun home() {
        content.addView(title("Fuentes de pago", 20f))
        content.addView(subtitle("Activa o desactiva cada fuente por separado."))
        gap(12)

        val master = card()
        var readerStatusText: TextView? = null
        var readerStatusSubtitle: TextView? = null
        var readerStatusDot: TextView? = null
        val masterRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val masterTexts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        masterTexts.addView(TextView(this@MainActivity).apply {
            text = "Anunciar pagos"
            textSize = 17f
            setTextColor(lightText)
            setTypeface(typeface, Typeface.BOLD)
        })
        masterTexts.addView(TextView(this@MainActivity).apply {
            text = "Activa o pausa todos los anuncios"
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(2), 0, 0)
        })
        masterRow.addView(masterTexts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val masterSwitch = Switch(this)
        fun applyMaster(checked: Boolean) {
            masterSwitch.thumbTintList = ColorStateList.valueOf(if (checked) Color.WHITE else Color.rgb(230,228,233))
            masterSwitch.trackTintList = ColorStateList.valueOf(if (checked) green else Color.rgb(190,187,196))
        }
        val masterActive = prefs.getBoolean(PaymentNotificationListener.KEY_ENABLED, true)
        masterSwitch.isChecked = masterActive
        applyMaster(masterActive)
        masterSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(PaymentNotificationListener.KEY_ENABLED, checked).apply()
            applyMaster(checked)
            if (checked) PaymentWatchdogService.start(this@MainActivity) else PaymentWatchdogService.stop(this@MainActivity)
            updateReaderStatus(checked, readerStatusText, readerStatusSubtitle, readerStatusDot)
        }
        masterRow.addView(masterSwitch)
        master.addView(masterRow)
        content.addView(master)
        gap(12)

        if (prefs.getBoolean("show_home_yape", true)) {
            sourceCard("Yape", PaymentNotificationListener.KEY_YAPE_ENABLED, R.drawable.yape_logo, purple)
            gap(10)
        }
        if (prefs.getBoolean("show_home_falabella", true)) {
            sourceCard("Banco Falabella", PaymentNotificationListener.KEY_FALABELLA_ENABLED, R.drawable.banco_falabella_logo, green)
            gap(10)
        }
        financialApps().filter { app ->
            prefs.getBoolean("show_home_generic_${app.packageName}", false)
        }.forEach { app ->
            genericSourceCard(app)
            gap(10)
        }
        gap(14)
        val info = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val statusDot = TextView(this).apply {
            text = "●"
            textSize = 24f
            gravity = Gravity.CENTER
        }
        readerStatusDot = statusDot
        row.addView(statusDot, LinearLayout.LayoutParams(dp(36), dp(36)))
        val infoText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val statusText = TextView(this).apply {
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        }
        readerStatusText = statusText
        val statusSubtitle = subtitle("")
        readerStatusSubtitle = statusSubtitle
        infoText.addView(statusText)
        infoText.addView(statusSubtitle)
        row.addView(infoText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        info.addView(row)
        content.addView(info)
        updateReaderStatus(masterActive, statusText, statusSubtitle, statusDot)
    }

    private fun updateReaderStatus(
        masterActive: Boolean,
        statusText: TextView? = null,
        statusSubtitle: TextView? = null,
        statusDot: TextView? = null
    ) {
        // The general switch is the source of truth for the visible reader state.
        val textView = statusText ?: return
        val subtitleView = statusSubtitle ?: return
        val dotView = statusDot ?: return
        val active = masterActive
        textView.text = if (active) "Lector conectado" else "Lector desconectado"
        textView.setTextColor(if (active) greenDark else Color.BLACK)
        dotView.setTextColor(if (active) green else Color.BLACK)
        subtitleView.text = if (active) "Escuchando notificaciones de pagos" else "Anuncios de pagos desactivados"
    }

    private data class FinancialApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)

    private fun financialApps(): List<FinancialApp> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val launchables = try { packageManager.queryIntentActivities(launcherIntent, 0) } catch (_: Exception) { emptyList() }
        val keywords = listOf("banco", "bank", "bcp", "yape", "plin", "falabella", "interbank", "bbva", "scotiabank", "scotia", "banbif", "pichincha", "financiera", "caja", "oh!")
        return launchables.mapNotNull { ri ->
            val appInfo = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
            val label = try { packageManager.getApplicationLabel(appInfo).toString() } catch (_: Exception) { return@mapNotNull null }
            val pkg = appInfo.packageName
            if (pkg == packageName) return@mapNotNull null
            val labelNorm = label.lowercase(Locale.ROOT)
            val pkgNorm = pkg.lowercase(Locale.ROOT)
            if (keywords.none { labelNorm.contains(it) || pkgNorm.contains(it) }) return@mapNotNull null
            FinancialApp(label, pkg, appInfo.loadIcon(packageManager))
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.ROOT) }
    }

    private fun genericSourceCard(app: FinancialApp) {
        val key = PaymentNotificationListener.KEY_GENERIC_APP_ENABLED_PREFIX + app.packageName
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.CENTER_INSIDE }, LinearLayout.LayoutParams(dp(64), dp(64)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(8), 0) }
        val activeText = TextView(this).apply { textSize = 13f; setTypeface(typeface, Typeface.BOLD) }
        texts.addView(TextView(this).apply { text = app.label; textSize = 16f; setTextColor(lightText); setTypeface(typeface, Typeface.BOLD) })
        texts.addView(activeText)
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Switch(this).apply {
            isChecked = prefs.getBoolean(key, false)
            fun update(checked: Boolean) { activeText.text = if (checked) "Activo · formato inicial" else "Inactivo"; activeText.setTextColor(if (checked) greenDark else muted) }
            update(isChecked)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply(); update(checked) }
        })
        c.addView(row)
        content.addView(c)
    }

    private fun sourceCard(label: String, key: String, iconRes: Int, accent: Int) {
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val packageName = when (label) {
            "Yape" -> "com.bcp.innovacxion.yapeapp"
            "Banco Falabella" -> "per.bf.desa"
            else -> ""
        }
        row.addView(ImageView(this).apply {
            val installedIcon = try { packageManager.getApplicationIcon(packageName) } catch (_: Exception) { null }
            if (installedIcon != null) setImageDrawable(installedIcon) else setImageResource(iconRes)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(64), dp(64)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14),0,dp(8),0) }
        val status = TextView(this).apply { textSize = 13f; setTypeface(typeface, Typeface.BOLD) }
        texts.addView(TextView(this).apply {
            text = label; textSize = 17f
            setTextColor(lightText); setTypeface(typeface, Typeface.BOLD)
        })
        texts.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)))
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        fun applyState(checked: Boolean) {
            status.text = if (checked) "Activo" else "Inactivo"
            status.setTextColor(if (checked) green else muted)
            sw.thumbTintList = ColorStateList.valueOf(if (checked) Color.WHITE else Color.rgb(230,228,233))
            sw.trackTintList = ColorStateList.valueOf(if (checked) green else Color.rgb(190,187,196))
        }
        val active = prefs.getBoolean(key, true)
        sw.isChecked = active
        applyState(active)
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply(); applyState(checked) }
        row.addView(sw)
        c.addView(row)
        content.addView(c)
    }

    private fun settings() {
        sectionLabel("Voz")
        val audio = card()
        settingRow(audio, "🔊", "Volumen de notificaciones", "Controla el volumen de los anuncios") { showNotificationVolume() }
        divider(audio)
        settingRow(audio, "🔈", "Voz para Yape", voiceSummary(PaymentNotificationListener.KEY_YAPE_VOICE_NAME)) { showVoiceSelector("Yape", PaymentNotificationListener.KEY_YAPE_VOICE_NAME) }
        divider(audio)
        settingRow(audio, "🔈", "Voz para Banco Falabella", voiceSummary(PaymentNotificationListener.KEY_FALABELLA_VOICE_NAME)) { showVoiceSelector("Banco Falabella", PaymentNotificationListener.KEY_FALABELLA_VOICE_NAME) }
        divider(audio)
        settingRow(audio, "⚙", "Configuración TTS de Android", "Motor y voces instaladas en el teléfono") { openTtsSettings() }
        divider(audio)
        settingRow(audio, "👤", "Cómo pronunciar el nombre", nameModeSummary()) { showNameModeDialog() }
        content.addView(audio)

        gap(14)
        sectionLabel("Información del pago")
        val payment = card()
        switchRow(payment, "Monto", PaymentNotificationListener.KEY_READ_AMOUNT, true)
        divider(payment)
        switchRow(payment, "Código de seguridad", PaymentNotificationListener.KEY_READ_CODE, false)
        content.addView(payment)

        gap(14)
        sectionLabel("Notificaciones")
        val other = card()
        switchRow(other, "No molestar / Modo silencio", PaymentNotificationListener.KEY_RESPECT_SILENT, true)
        content.addView(other)

        gap(14)
        val permissions = card()
        settingRow(permissions, "🛡", "Permisos", "Configura todos los permisos necesarios") { showPermissions() }
        content.addView(permissions)

        gap(14)
        sectionLabel("Diagnóstico temporal")
        val diagnostic = card()
        val diagSwitch = Switch(this).apply {
            text = "Registrar funcionamiento de Pago Voz"
            textSize = 15f
            setTextColor(lightText)
            isChecked = DiagnosticLogger.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                DiagnosticLogger.setEnabled(this@MainActivity, checked)
                DiagnosticLogger.log(this@MainActivity, if (checked) "diagnostic_enabled" else "diagnostic_disabled")
            }
        }
        diagnostic.addView(diagSwitch)
        diagnostic.addView(TextView(this).apply {
            text = "Solo registra eventos técnicos. No guarda nombres, importes, códigos ni textos de notificaciones."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(4), 0, dp(8))
        })
        val diagButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        diagButtons.addView(actionButton("Compartir diagnóstico") { shareDiagnostic() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        diagButtons.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        diagButtons.addView(actionButton("Borrar") { confirmClearDiagnostic() }, LinearLayout.LayoutParams(0, dp(48), 0.55f))
        diagnostic.addView(diagButtons)
        content.addView(diagnostic)

        gap(14)
        sectionLabel("Aplicaciones visibles en Inicio")
        val visibleApps = card()
        visibleApps.addView(TextView(this).apply {
            text = "Selecciona qué aplicaciones quieres mostrar en Inicio. Yape y Falabella están preparadas; otras aplicaciones detectadas usan una regla inicial basada en notificaciones de transferencias y deberán probarse cuando tengas oportunidad."
            textSize = 13f; setTextColor(muted); setPadding(0, 0, 0, dp(8))
        })
        fun visibleSwitch(label: String, key: String) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            row.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(lightText) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Switch(this).apply {
                isChecked = prefs.getBoolean(key, true)
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() }
            })
            visibleApps.addView(row)
        }
        visibleSwitch("Yape", "show_home_yape")
        divider(visibleApps)
        visibleSwitch("Banco Falabella", "show_home_falabella")
        content.addView(visibleApps)

        gap(14)
        sectionLabel("Aplicaciones financieras instaladas")
        val installedApps = card()
        val detected = financialApps().filter { it.packageName != "com.bcp.innovacxion.yapeapp" && it.packageName != "per.bf.desa" }
        if (detected.isEmpty()) {
            installedApps.addView(TextView(this).apply {
                text = "No se detectaron otras aplicaciones financieras por su nombre. Si instalas una, esta lista se actualizará al volver a Configuración."
                textSize = 13f; setTextColor(muted)
            })
        } else {
            detected.forEach { app ->
                val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(7), 0, dp(7)) }
                row.addView(ImageView(this).apply { setImageDrawable(app.icon); scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(38), dp(38)))
                row.addView(TextView(this).apply {
                    text = app.label + "\nReconocimiento inicial de transferencias"
                    textSize = 13f; setTextColor(lightText); setPadding(dp(10), 0, dp(8), 0)
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(Switch(this).apply {
                    isChecked = prefs.getBoolean("show_home_generic_${app.packageName}", false)
                    setOnCheckedChangeListener { _, checked ->
                        prefs.edit().putBoolean("show_home_generic_${app.packageName}", checked).apply()
                        Toast.makeText(this@MainActivity, if (checked) "Se mostrará en Inicio. Activa sus anuncios desde su tarjeta." else "Se ocultará de Inicio.", Toast.LENGTH_SHORT).show()
                    }
                })
                installedApps.addView(row)
            }
            installedApps.addView(TextView(this).apply {
                text = "Nota: la detección por nombre puede no encontrar algunas apps o incluir una que no sea bancaria. Las aplicaciones nuevas solo anunciarán notificaciones que coincidan con el formato inicial de transferencias."
                textSize = 11f; setTextColor(muted); setPadding(0, dp(6), 0, 0)
            })
        }
        content.addView(installedApps)

        gap(14)
        sectionLabel("Probar voces")
        val testYape = Button(this).apply {
            text = "▶  Probar voz de Yape"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            isAllCaps = false
            background = rounded(purple, 18)
            setOnClickListener { PaymentNotificationListener.testSpeech(this@MainActivity, "Yape") }
        }
        content.addView(testYape, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        gap(8)
        val testFalabella = Button(this).apply {
            text = "▶  Probar voz de Banco Falabella"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            isAllCaps = false
            background = rounded(greenDark, 18)
            setOnClickListener { PaymentNotificationListener.testSpeech(this@MainActivity, "Banco Falabella") }
        }
        content.addView(testFalabella, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
    }

    private fun sectionLabel(text: String) {
        content.addView(TextView(this).apply {
            this.text = text; textSize = 18f
            setTextColor(lightText)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(8))
        })
    }

    private fun settingRow(parent: LinearLayout, icon: String, label: String, sub: String, click: () -> Unit) {
        parent.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(3))
            setOnClickListener { click() }
            addView(TextView(this@MainActivity).apply { text = icon; textSize = 23f; gravity = Gravity.CENTER; setTextColor(purple) }, LinearLayout.LayoutParams(dp(42), dp(58)))
            val box = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            box.addView(TextView(this@MainActivity).apply { text = label; textSize = 15f; setTextColor(lightText); setTypeface(typeface, Typeface.BOLD) })
            box.addView(TextView(this@MainActivity).apply { text = sub; textSize = 12f; setTextColor(muted); setPadding(0, dp(2), 0, 0) })
            addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(this@MainActivity).apply { text = "›"; textSize = 28f; setTextColor(muted); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(30), dp(58)))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))
    }

    private fun switchRow(parent: LinearLayout, label: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        val text = TextView(this).apply { text = label; textSize = 15f; gravity = Gravity.CENTER_VERTICAL; setTypeface(typeface, Typeface.BOLD) }
        row.addView(text, LinearLayout.LayoutParams(0, dp(50), 1f))
        val sw = Switch(this)
        fun update(checked: Boolean) {
            text.setTextColor(if (checked) purple else muted)
            sw.thumbTintList = ColorStateList.valueOf(if (checked) Color.WHITE else Color.rgb(230,228,233))
            sw.trackTintList = ColorStateList.valueOf(if (checked) purple else Color.rgb(190,187,196))
        }
        val checked = prefs.getBoolean(key, default)
        sw.isChecked = checked; update(checked)
        sw.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply(); update(v) }
        row.addView(sw)
        parent.addView(row)
    }

    private fun divider(parent: LinearLayout) { parent.addView(View(this).apply { setBackgroundColor(Color.rgb(232,228,238)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))) }

    private fun nameModeSummary(): String = if (prefs.getString(PaymentNotificationListener.KEY_NAME_MODE, PaymentNotificationListener.NAME_FIRST) == PaymentNotificationListener.NAME_FULL) "Nombre y apellido" else "Solo nombre"

    private fun voiceSummary(key: String): String {
        val name = prefs.getString(key, null)
        return if (name.isNullOrBlank()) "Voz predeterminada" else name
    }

    private fun showVoiceSelector(source: String, key: String) {
        PaymentNotificationListener.loadAvailableSpanishVoices(this) { voices ->
            runOnUiThread {
                if (voices.isEmpty()) {
                    Toast.makeText(this, "No se encontraron voces en español instaladas.", Toast.LENGTH_LONG).show()
                    return@runOnUiThread
                }
                val labels = voices.map { voice ->
                    val locale = voice.locale.toLanguageTag()
                    "${voice.name} — $locale"
                }.toTypedArray()
                val saved = prefs.getString(key, null)
                val checked = voices.indexOfFirst { it.name == saved }.let { if (it >= 0) it else 0 }
                showChoiceDialog("Voz para $source", labels, checked) { which ->
                    prefs.edit()
                        .putString(key, voices[which].name)
                        .apply()
                    show(1)
                }
            }
        }
    }

    private fun showNameModeDialog() {
        val values = arrayOf("Solo nombre", "Nombre y apellido")
        val checked = if (prefs.getString(PaymentNotificationListener.KEY_NAME_MODE, PaymentNotificationListener.NAME_FIRST) == PaymentNotificationListener.NAME_FULL) 1 else 0
        showChoiceDialog("Cómo pronunciar el nombre", values, checked) { which ->
            prefs.edit().putString(PaymentNotificationListener.KEY_NAME_MODE, if (which == 1) PaymentNotificationListener.NAME_FULL else PaymentNotificationListener.NAME_FIRST).apply()
            show(1)
        }
    }

    private fun showNotificationVolume() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_NOTIFICATION)
        val current = audio.getStreamVolume(android.media.AudioManager.STREAM_NOTIFICATION)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(4)) }
        val value = TextView(this).apply { text = "${current * 100 / max}%"; gravity = Gravity.CENTER; textSize = 16f; setTextColor(purple); setTypeface(typeface, Typeface.BOLD) }
        val bar = SeekBar(this).apply { this.max = max; this.progress = current }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) audio.setStreamVolume(android.media.AudioManager.STREAM_NOTIFICATION, p, 0); value.text = "${p * 100 / max}%" }
            override fun onStartTrackingTouch(s: SeekBar?) = Unit
            override fun onStopTrackingTouch(s: SeekBar?) = Unit
        })
        box.addView(value); box.addView(bar)
        showCustomDialog("Volumen de notificaciones", box, "Listo", null)
    }

    private fun showPermissions() {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 22)
            setPadding(dp(20), dp(18), dp(20), dp(14))
        }
        box.addView(TextView(this).apply {
            text = "Permisos"
            textSize = 19f
            setTextColor(Color.BLACK)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(2), dp(2), dp(10))
        })

        val items = listOf(
            Triple("Acceso a notificaciones", isNotificationListenerEnabled()) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            Triple("Batería sin restricciones", isBatteryUnrestricted()) { requestBatteryOptimization() },
            Triple("Autoencendido / inicio automático", prefs.getBoolean("autostart_checked", false)) { openAutoStart() },
            Triple("Mostrar notificaciones", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) { requestNotificationPermission() }
        )

        items.forEach { (label, active, action) ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
                setOnClickListener { dialog.dismiss(); action() }
            }
            row.addView(TextView(this).apply {
                text = "●"
                textSize = 18f
                setTextColor(if (active) green else Color.rgb(185,181,192))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(34), dp(50)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 15f
                setTextColor(Color.BLACK)
                setTypeface(typeface, Typeface.BOLD)
            })
            texts.addView(TextView(this@MainActivity).apply {
                text = if (active) "Activo" else "Pendiente"
                textSize = 12f
                setTextColor(if (active) greenDark else muted)
            })
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply { text = "›"; textSize = 26f; setTextColor(muted); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(28), dp(50)))
            box.addView(row)
        }

        val close = Button(this).apply {
            text = "Cerrar"
            isAllCaps = false
            textSize = 14f
            setTextColor(purple)
            setTypeface(typeface, Typeface.BOLD)
            background = rounded(Color.rgb(244, 238, 255), 14)
            setOnClickListener { dialog.dismiss() }
        }
        box.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun openTtsSettings() {
        val actions = listOf(
            "com.android.settings.TTS_SETTINGS",
            "android.settings.TEXT_TO_SPEECH_SETTINGS",
            "android.settings.TTS_SETTINGS"
        )
        for (action in actions) {
            try {
                val intent = Intent(action)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: Exception) { }
        }
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: Exception) {
        }
    }

    private fun summary() {
        content.addView(title("Historial de pagos", 22f))
        gap(10)
        val summary = PaymentNotificationListener.getTodaySummary(this)
        val stat = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stat.addView(statCard("${summary.first}", "Pagos hoy", purple), LinearLayout.LayoutParams(0, dp(108), 1f))
        stat.addView(Space(this), LinearLayout.LayoutParams(dp(16), 1))
        stat.addView(statCard(formatCents(summary.second), "Total hoy", green), LinearLayout.LayoutParams(0, dp(108), 1f))
        content.addView(stat)
        gap(14)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(actionButton("Resetear contador") { confirmResetCounter() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        controls.addView(actionButton("Borrar historial") { confirmClearHistory() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(controls)
        gap(10)
        val filterControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        filterControls.addView(actionButton(if (historyFilterDate == null) "Elegir fecha" else "Fecha: ${historyFilterDate!!.replace('-', '/')}") { showHistoryDatePicker() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        filterControls.addView(Space(this), LinearLayout.LayoutParams(dp(8), 1))
        filterControls.addView(actionButton("Ver todos") { historyFilterDate = null; show(2) }, LinearLayout.LayoutParams(0, dp(46), 0.7f))
        content.addView(filterControls)
        gap(12)

        val allHistory = readHistory()
        val history = JSONArray()
        val keyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        for (i in 0 until allHistory.length()) {
            val obj = allHistory.optJSONObject(i) ?: continue
            val ts = obj.optLong("timestamp", 0L)
            if (historyFilterDate == null || keyFormat.format(Date(ts)) == historyFilterDate) history.put(obj)
        }
        if (history.length() == 0) {
            val empty = card()
            empty.addView(TextView(this).apply {
                text = if (historyFilterDate == null) "Todavía no hay pagos registrados." else "No hay pagos registrados para esa fecha."
                textSize = 15f; setTextColor(muted); gravity = Gravity.CENTER
                setPadding(0, dp(20), 0, dp(20))
            })
            content.addView(empty)
            return
        }
        val dayFormat = SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy", Locale("es", "PE"))
        var lastDay = ""
        for (i in 0 until history.length()) {
            val obj = history.optJSONObject(i) ?: continue
            val timestamp = obj.optLong("timestamp", 0L)
            val day = dayFormat.format(Date(timestamp)).replaceFirstChar { it.uppercase(Locale("es", "PE")) }
            if (day != lastDay) {
                content.addView(TextView(this).apply {
                    text = day; textSize = 15f; setTextColor(lightText); setTypeface(typeface, Typeface.BOLD)
                    setPadding(dp(2), dp(8), 0, dp(7))
                })
                lastDay = day
            }
            content.addView(historyRow(obj)); gap(7)
        }
    }

    private fun showHistoryDatePicker() {
        val calendar = java.util.Calendar.getInstance()
        historyFilterDate?.let { saved ->
            try { val parts = saved.split("-"); calendar.set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt()) } catch (_: Exception) { }
        }
        DatePickerDialog(this, { _, year, month, day ->
            historyFilterDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
            show(2)
        }, calendar.get(java.util.Calendar.YEAR), calendar.get(java.util.Calendar.MONTH), calendar.get(java.util.Calendar.DAY_OF_MONTH)).show()
    }

    private fun shareDiagnostic() {
        val file = DiagnosticLogger.file(this)
        if (!file.exists() || file.length() == 0L) {
            showCustomDialog("Diagnóstico vacío", TextView(this).apply { text = "Activa el diagnóstico y reproduce el problema para registrar eventos técnicos."; setTextColor(Color.BLACK); textSize = 15f; setPadding(dp(20), dp(12), dp(20), dp(12)) }, "Cerrar", null)
            return
        }
        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            startActivity(Intent.createChooser(send, "Compartir diagnóstico de Pago Voz"))
        } catch (_: Exception) {
            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, file.readText()) }
            startActivity(Intent.createChooser(send, "Compartir diagnóstico de Pago Voz"))
        }
    }

    private fun confirmClearDiagnostic() {
        showCustomDialog("Borrar diagnóstico", TextView(this).apply { text = "¿Quieres borrar los registros técnicos? No se borrará el historial de pagos."; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(18), dp(22), dp(8)) }, "Borrar") {
            DiagnosticLogger.clear(this)
            Toast.makeText(this, "Diagnóstico borrado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun actionButton(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); background = rounded(purple, 16); setOnClickListener { click() }
    }

    private fun statCard(value: String, label: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(accent, 18)
        addView(TextView(this@MainActivity).apply { text = value; textSize = 22f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER })
        addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
    }

    private fun historyRow(obj: org.json.JSONObject): LinearLayout {
        val source = obj.optString("source", "Yape")
        val amount = formatAmount(obj.optLong("soles", 0), obj.optInt("cents", 0))
        val name = obj.optString("name", "").ifBlank { "Sin nombre" }
        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(obj.optLong("timestamp", 0)))
        val accent = if (source == "Banco Falabella") green else purple
        val c = card().apply { setPadding(dp(14), dp(12), dp(14), dp(12)) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }

        val nameBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        nameBox.addView(TextView(this).apply {
            text = name
            textSize = 15f
            setTextColor(lightText)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        row.addView(nameBox, LinearLayout.LayoutParams(0, dp(50), 1f))

        row.addView(TextView(this).apply {
            text = amount
            textSize = 15f
            setTextColor(lightText)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, dp(50), 1f))

        row.addView(TextView(this).apply {
            text = time
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
        }, LinearLayout.LayoutParams(0, dp(50), 0.55f))

        row.setOnClickListener { showPaymentDetail(obj) }
        c.addView(row)
        return c
    }

    private fun showPaymentDetail(obj: org.json.JSONObject) {
        val source = obj.optString("source", "Yape")
        val title = obj.optString("notification_title", "")
        val original = obj.optString("notification_content", "").trim()
        val amount = formatAmount(obj.optLong("soles", 0), obj.optInt("cents", 0))
        val name = obj.optString("name", "").ifBlank { "Sin nombre" }
        val code = obj.optString("code", "")
        val time = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(obj.optLong("timestamp", 0)))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(4), dp(22), dp(4))
        }

        box.addView(TextView(this).apply {
            text = "Fecha: $time"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(10))
        })

        if (original.isNotBlank()) {
            box.addView(TextView(this).apply {
                text = "Contenido original de la notificación"
                textSize = 15f
                setTextColor(lightText)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(2), 0, dp(6))
            })
            box.addView(TextView(this).apply {
                text = original
                textSize = 15f
                setTextColor(Color.BLACK)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                background = rounded(Color.rgb(247, 246, 251), 12)
            })
        } else {
            // Pagos antiguos registrados antes de guardar el contenido original.
            val fallback = "Monto: $amount\nPagador: $name" +
                (if (code.isNotBlank()) "\nCódigo de seguridad: $code" else "")
            box.addView(TextView(this).apply {
                text = fallback
                textSize = 15f
                setTextColor(Color.BLACK)
                setPadding(0, dp(8), 0, dp(8))
            })
        }

        showCustomDialog(source, box, "Cerrar", null)
    }

    private fun confirmResetCounter() {
        showCustomDialog("Resetear contador", TextView(this).apply { text = "¿Quieres reiniciar el contador de pagos de hoy? El historial se conservará."; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(18), dp(22), dp(8)) }, "Resetear") {
            prefs.edit().putLong(PaymentNotificationListener.KEY_COUNTER_RESET_AT, System.currentTimeMillis()).apply()
            DiagnosticLogger.log(this, "counter_reset")
            show(2)
        }
    }

    private fun confirmClearHistory() {
        showCustomDialog("Borrar historial", TextView(this).apply { text = "¿Seguro que quieres borrar todo el historial de pagos? Esta acción no se puede deshacer."; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(18), dp(22), dp(8)) }, "Borrar") {
            prefs.edit().putString(PaymentNotificationListener.KEY_PAYMENT_HISTORY, "[]").putLong(PaymentNotificationListener.KEY_COUNTER_RESET_AT, 0L).apply()
            DiagnosticLogger.log(this, "history_cleared")
            show(2)
        }
    }

    private fun readHistory(): JSONArray = try { JSONArray(prefs.getString(PaymentNotificationListener.KEY_PAYMENT_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun formatAmount(soles: Long, cents: Int): String = "S/ ${soles}.${cents.toString().padStart(2, '0')}"
    private fun formatCents(cents: Long): String = formatAmount(cents / 100L, (cents % 100L).toInt())

    private fun showCustomDialog(title: String, body: View, positive: String, onPositive: (() -> Unit)?) {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 22); setPadding(dp(20), dp(18), dp(20), dp(12)) }
        box.addView(TextView(this).apply { text = title; textSize = 19f; setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), dp(2), dp(2), dp(10)) })
        box.addView(body)
        val button = Button(this).apply { text = positive; isAllCaps = false; textSize = 14f; setTextColor(purple); setTypeface(typeface, Typeface.BOLD); background = rounded(Color.rgb(244,238,255), 14); setOnClickListener { dialog.dismiss(); onPositive?.invoke() } }
        box.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showChoiceDialog(title: String, values: Array<String>, checked: Int, onSelected: (Int) -> Unit) {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 22); setPadding(dp(20), dp(18), dp(20), dp(12)) }
        box.addView(TextView(this).apply { text = title; textSize = 19f; setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), dp(2), dp(2), dp(10)) })
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        values.forEachIndexed { index, value ->
            val rb = RadioButton(this).apply { text = value; textSize = 15f; setTextColor(Color.BLACK); isChecked = index == checked; setPadding(0, dp(8), 0, dp(8)) }
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { _, id ->
            val index = group.indexOfChild(group.findViewById(id)); if (index >= 0) { dialog.dismiss(); onSelected(index) }
        }
        box.addView(group)
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun continuePermissionFlow() {
        if (permissionFlowBusy) return

        // En el primer inicio mostramos la ruta completa de configuración.
        // Si alguno ya está concedido, se salta automáticamente y continúa con el siguiente.
        if (!isNotificationListenerEnabled()) {
            showPermissionStep("1 de 4 · Acceso a notificaciones", "Pago Voz necesita este acceso para detectar los pagos de Yape y Banco Falabella.", "Abrir configuración") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            showPermissionStep("2 de 4 · Mostrar notificaciones", "Permite las notificaciones de Pago Voz para mantener visible el servicio que escucha los pagos.", "Permitir") { requestNotificationPermission() }
            return
        }
        if (!isBatteryUnrestricted()) {
            showPermissionStep("3 de 4 · Batería sin restricciones", "Permite que Pago Voz siga funcionando en segundo plano para no perder pagos.", "Configurar") { requestBatteryOptimization() }
            return
        }
        if (isXiaomiFamily() && !prefs.getBoolean("autostart_checked", false)) {
            showPermissionStep("4 de 4 · Autoencendido", "En Xiaomi, Redmi o POCO activa el inicio automático para que el lector pueda volver a funcionar después de reiniciar el teléfono.", "Abrir configuración") {
                prefs.edit().putBoolean("autostart_checked", true).apply(); openAutoStart()
            }
            return
        }
        prefs.edit().putBoolean("setup_completed", true).apply()
        PaymentWatchdogService.start(this)
    }

    private fun showPermissionStep(title: String, message: String, button: String, action: () -> Unit) {
        permissionFlowBusy = true
        val body = TextView(this).apply { text = message; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(8), dp(22), dp(10)) }
        showCustomDialog(title, body, button) { permissionFlowBusy = false; action() }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    private fun isBatteryUnrestricted(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) pm.isIgnoringBatteryOptimizations(packageName) else true
    }

    private fun requestBatteryOptimization() {
        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
    }

    private fun isXiaomiFamily(): Boolean {
        val m = Build.MANUFACTURER.lowercase(Locale.ROOT)
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
    }

    private fun openAutoStart() {
        val i = Intent().apply { component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") }
        try { if (i.resolveActivity(packageManager) != null) { startActivity(i); return } } catch (_: Exception) { }
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }
}
