plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pe.yapevoz"
    compileSdk = 35

    defaultConfig {
        applicationId = "pe.yapevoz"
        minSdk = 26
        targetSdk = 35
        versionCode = 35
        versionName = "2.7.6"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
