package pe.pagovoz

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.text.Normalizer
import java.util.Locale

class PaymentNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pendingSpeech: String? = null
    private var lastNotificationKey: String? = null

    override fun onCreate() {
        super.onCreate()
        setConnected(this, false)
        initializeTts()
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        setConnected(this, true)
    }

    override fun onListenerDisconnected() {
        setConnected(this, false)
        try {
            requestRebind(ComponentName(this, PaymentNotificationListener::class.java))
        } catch (_: Exception) {
        }
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        setConnected(this, false)
        ttsReady = false
        pendingSpeech = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val source = when (sbn.packageName) {
            YAPE_PACKAGE -> "Yape"
            FALABELLA_PACKAGE -> "Banco Falabella"
            else -> return
        }
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val sourceEnabled = if (source == "Yape") prefs.getBoolean(KEY_YAPE_ENABLED, true) else prefs.getBoolean(KEY_FALABELLA_ENABLED, true)
        if (!sourceEnabled || !prefs.getBoolean(KEY_ENABLED, true)) return
        if (prefs.getBoolean(KEY_SKIP_CALLS, true) && isInCall()) return

        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val titleBig = extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val infoText = extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString().orEmpty()
        val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.map { it.toString() }.orEmpty()
        val fields = listOf(titleBig, bigText, text, subText, infoText)
            .plus(textLines)
            .filter { it.isNotBlank() }
            .distinct()
        val rawParts = mutableListOf<String>()
        if (title.isNotBlank()) rawParts += title
        rawParts += fields
        val raw = rawParts.distinct().joinToString(". ")
        if (raw.isBlank()) return
        val fullNotification = buildFullNotification(title, fields)
        val notificationKey = sbn.key + "|" + fullNotification
        if (notificationKey == lastNotificationKey) return

        val result = if (source == "Yape") parseYape(raw, prefs) else parseFalabella(raw, prefs)
        if (result == null) return

        val phrase = buildSourcePhrase(source, result.speechName, result.amount, result.code, prefs)
        // No introducimos una espera artificial: cada notificación válida se
        // procesa en cuanto Android la entrega al listener.
        lastNotificationKey = notificationKey

        recordPayment(
            context = this,
            amount = result.amount,
            name = result.historyName,
            source = source,
            code = result.code,
            notificationTitle = title,
            notificationContent = fullNotification
        )
        PaymentWatchdogService.updateNow(this)

        // Registrar/contabilizar el pago es independiente del estado de
        // silencio o No molestar. Solo la locución se bloquea cuando la
        // opción "No molestar / Modo silencio" está activada y el teléfono
        // está realmente en silencio/DND.
        currentSpeechSource = source
        val respectSilent = prefs.getBoolean(KEY_RESPECT_SILENT, true)
        val shouldSpeak = !respectSilent || !isSilentOrDnd()
        if (shouldSpeak) {
            forceSpeechThroughSilentModes = !respectSilent
            speak(phrase)
        }
        forceSpeechThroughSilentModes = false
    }

    private fun buildFullNotification(title: String, fields: List<String>): String {
        val parts = mutableListOf<String>()
        if (title.isNotBlank()) parts += title
        parts += fields
        return parts.distinct().joinToString("\n")
    }

    private fun parseYape(raw: String, prefs: android.content.SharedPreferences): ParsedPayment? {
        val cleaned = cleanNotificationText(raw)
        val amount = extractAmount(cleaned) ?: return null
        if (!looksLikePayment(cleaned)) return null
        val historyName = extractSenderName(cleaned)
        val speechName = historyName?.let { formatName(it, prefs.getString(KEY_NAME_MODE, NAME_FIRST) ?: NAME_FIRST) }
        val code = if (prefs.getBoolean(KEY_READ_CODE, false)) extractSecurityCode(raw) else null
        return ParsedPayment(amount, speechName, historyName, code)
    }

    private fun parseFalabella(raw: String, prefs: android.content.SharedPreferences): ParsedPayment? {
        val n = normalize(raw)

        // Falabella también publica notificaciones de compras/pagos que salen
        // de nuestra propia cuenta. Solo aceptamos el patrón de dinero recibido.
        val outgoingWords = listOf(
            "realizaste un pago", "realizaste el pago", "has realizado un pago",
            "realizaste una operacion", "has realizado una operacion",
            "compra con tu tarjeta", "compra realizada", "pagaste",
            "pago realizado", "operacion realizada"
        )
        if (outgoingWords.any { n.contains(normalize(it)) }) return null

        val incoming = n.contains("recibiste") ||
            n.contains("te transfirio") ||
            n.contains("te transfirieron")
        if (!incoming) return null

        val amount = extractAmount(raw) ?: return null
        val historyName = extractFalabellaSenderName(raw)
        val speechName = historyName?.let {
            formatName(it, prefs.getString(KEY_NAME_MODE, NAME_FIRST) ?: NAME_FIRST)
        }
        return ParsedPayment(amount, speechName, historyName, null)
    }

    private fun extractFalabellaSenderName(s: String): String? {
        // Formato real observado: "Nombre Apellido... te transfirió S/ 1.00".
        val patterns = listOf(
            Regex("""(?i)([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,80}?)\s+te\s+transf(?:irió|irio)\s+S\s*/"""),
            Regex("""(?i)([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,80}?)\s+te\s+transfirieron\s+S\s*/""")
        )
        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val name = match.groupValues[1]
                .trim()
                .replace(Regex("\\s+"), " ")
                .trim('.', ',', ':', ';', '-')
            if (isPlausibleName(name)) return name
        }
        return null
    }

    private fun buildSourcePhrase(source: String, name: String?, amount: Amount, code: String?, prefs: android.content.SharedPreferences): String {
        val amountText = if (prefs.getBoolean(KEY_READ_AMOUNT, true)) amountToSpanish(amount) else ""
        val secondPart = when {
            source == "Yape" && !name.isNullOrBlank() && amountText.isNotBlank() -> "$name te yapeó $amountText"
            source == "Yape" && amountText.isNotBlank() -> "Recibiste un Yape $amountText"
            source == "Banco Falabella" && !name.isNullOrBlank() && amountText.isNotBlank() -> "$name te transfirió $amountText"
            source == "Banco Falabella" && amountText.isNotBlank() -> "Te transfirieron $amountText"
            else -> "Pago de $source"
        }
        val withCode = if (source == "Yape" && !code.isNullOrBlank()) "$secondPart. Código, $code" else secondPart
        return "Pago recibido|$withCode"
    }

    private val speechHandler = Handler(Looper.getMainLooper())
    private val speechPauseMs = 450L

    /**
     * Inicializa/reinicializa el motor TTS de forma segura. Esto es importante
     * cuando el proveedor de voces fue detenido por Android: la instancia vieja
     * puede quedar sin conexión aunque Pago Voz siga recibiendo notificaciones.
     */
    private fun initializeTts(onReadySpeech: String? = null) {
        pendingSpeech = onReadySpeech
        ttsReady = false

        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null

        try {
            lateinit var newTts: TextToSpeech
            newTts = TextToSpeech(this) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    tts = newTts
                    ttsReady = true
                    configureTts(newTts, currentSpeechSource)
                    val pending = pendingSpeech
                    pendingSpeech = null
                    if (!pending.isNullOrBlank()) {
                        speakNow(newTts, pending)
                    }
                } else {
                    ttsReady = false
                }
            }
            tts = newTts
        } catch (_: Exception) {
            ttsReady = false
            tts = null
        }
    }

    private fun speak(text: String) {
        if (text.isBlank()) return

        val engine = tts
        if (engine == null || !ttsReady) {
            initializeTts(text)
            return
        }

        configureTts(engine, currentSpeechSource)
        speakNow(engine, text)
    }

    private fun speakNow(engine: TextToSpeech, text: String) {
        speechHandler.removeCallbacksAndMessages(null)
        try {
            engine.stop()
        } catch (_: Exception) {
        }

        val parts = text.split('|').map { it.trim() }.filter { it.isNotBlank() }
        if (parts.isEmpty()) return

        val firstResult = try {
            engine.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, "pago_voz_0")
        } catch (_: Exception) {
            TextToSpeech.ERROR
        }

        if (firstResult == TextToSpeech.ERROR) {
            initializeTts(text)
            return
        }

        if (parts.size > 1) {
            speechHandler.postDelayed({
                if (tts === engine && ttsReady) {
                    try {
                        engine.speak(parts.drop(1).joinToString(" "), TextToSpeech.QUEUE_ADD, null, "pago_voz_1")
                    } catch (_: Exception) {
                        initializeTts()
                    }
                }
            }, speechPauseMs)
        }
    }

    private var currentSpeechSource: String = "Yape"
    private var forceSpeechThroughSilentModes: Boolean = false

    private fun configureTts(engine: TextToSpeech?, source: String = currentSpeechSource) {
        engine ?: return

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedVoiceName = if (source == "Banco Falabella") {
            prefs.getString(KEY_FALABELLA_VOICE_NAME, null)
        } else {
            prefs.getString(KEY_YAPE_VOICE_NAME, null)
        }
        val availableVoices = engine.voices.orEmpty()

        val currentDefault = engine.defaultVoice
        val selectedVoice = if (!savedVoiceName.isNullOrBlank()) {
            availableVoices.firstOrNull { it.name == savedVoiceName } ?: currentDefault
        } else {
            currentDefault
        }

        if (selectedVoice != null) {
            try {
                engine.voice = selectedVoice
            } catch (_: Exception) {
                engine.setLanguage(Locale("es", "PE"))
            }
        } else {
            engine.setLanguage(Locale("es", "PE"))
        }

        engine.setAudioAttributes(
            AudioAttributes.Builder()
                // En modo normal mantenemos el canal de notificaciones.
                // Si el usuario desactiva "No molestar / Modo silencio",
                // usamos uso multimedia para que una política DND no suprima
                // la locución solicitada.
                .setUsage(
                    if (forceSpeechThroughSilentModes) AudioAttributes.USAGE_MEDIA
                    else AudioAttributes.USAGE_NOTIFICATION
                )
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }

    private fun looksLikePayment(s: String): Boolean {
        val n = normalize(s)
        val paymentWords = listOf(
            "te envio", "te envió", "te yapeo", "te yapeó",
            "te hizo un yape", "te hizo un pago",
            "recibiste", "confirmacion de pago", "confirmación de pago",
            "pago por"
        )
        return paymentWords.any { n.contains(normalize(it)) }
    }

    private fun extractAmount(s: String): Amount? {
        val mixedPattern = Regex("""(?i)\b([0-9]+)\s*soles?\s+(?:con\s+)?([0-9]{1,2})(?:\s*c[eé]ntimos?)?\b""")
        mixedPattern.find(s)?.let { match ->
            val soles = match.groupValues[1].toLongOrNull()
            val cents = match.groupValues[2].toIntOrNull()
            if (soles != null && cents != null && cents in 1..99) return Amount(soles, cents)
        }

        val centPatterns = listOf(
            Regex("""(?i)\b(?:por\s+)?([0-9]+)\s*c[eé]ntimos?\b"""),
            Regex("""(?i)\b(?:por\s+)?s\s*/\s*0[.,]([0-9]{1,2})\b""")
        )
        for (pattern in centPatterns) {
            val match = pattern.find(s) ?: continue
            val cents = if (pattern.pattern.contains("s\\s*/")) {
                (match.groupValues[1] + "00").take(2).toIntOrNull() ?: 0
            } else {
                match.groupValues[1].toIntOrNull() ?: 0
            }
            if (cents in 1..99) return Amount(0L, cents)
        }

        val patterns = listOf(
            Regex("""(?i)\bs\s*/\s*([0-9]+(?:[.,][0-9]{1,2})?)"""),
            Regex("""(?i)\b([0-9]+(?:[.,][0-9]{1,2})?)\s*(?:soles?|s/)\b"""),
            Regex("""(?i)\bpor\s+(?:s\s*/\s*)?([0-9]+(?:[.,][0-9]{1,2})?)\b""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val value = match.groupValues[1].replace(',', '.')
            val parts = value.split('.')
            val soles = parts[0].toLongOrNull() ?: continue
            val cents = if (parts.size > 1) {
                (parts[1] + "00").take(2).toIntOrNull() ?: 0
            } else 0
            if (cents !in 0..99) continue
            return Amount(soles, cents)
        }
        return null
    }

    private fun extractSenderName(s: String): String? {
        // El nombre siempre se extrae dinámicamente de la notificación.
        val patterns = listOf(
            // En Yape, el título puede ser "Confirmación de pago" y el nombre
            // viene en el siguiente campo. Buscamos el nombre después del
            // separador de la notificación para no confundir el título con el pagador.
            Regex("""(?i)[.!?]\s*([A-Za-zÁÉÍÓÚáéíóúÑñÜü][A-Za-zÁÉÍÓÚáéíóúÑñÜü .\'-]{1,59}?)[*]?\s+te\s+(?:envio|envió|yapeo|yapeó)\b"""),
            Regex("""(?i)^\s*([A-Za-zÁÉÍÓÚáéíóúÑñÜü][A-Za-zÁÉÍÓÚáéíóúÑñÜü .\'-]{1,59}?)[*]?\s+te\s+(?:envio|envió|yapeo|yapeó)\b"""),
            Regex("""(?i)(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .\'-]{2,60}?)[*]?\s+(?=por\b|s\s*/|soles?\b)"""),
            Regex("""(?i)(?:recibiste|recibio|recibió)\s+(?:un\s+)?(?:yape|pago)?\s*(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .\'-]{2,60}?)[*]?\s+(?=por\b|s\s*/|soles?\b)""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val name = match.groupValues[1]
                .replace("*", "")
                .trim()
                .replace(Regex("""\s+"""), " ")
                .trim('.', ',', ':', ';', '-')
            if (isPlausibleName(name)) return name
        }
        return null
    }

    private fun isPlausibleName(name: String): Boolean {
        if (name.length !in 2..60) return false
        val words = name.split(Regex("""\s+""")).filter { it.length >= 2 }
        if (words.isEmpty()) return false
        val blocked = setOf("yape", "pago", "dinero", "tu", "un", "una", "el", "la", "te", "confirmacion")
        return normalize(name) !in blocked
    }

    /**
     * Convierte el nombre que entrega la notificación en la forma que debe
     * anunciarse. Algunas entidades muestran nombres como:
     *   María Nieves Rondo Rivera
     * y otras pueden mostrarlos como:
     *   Rondo Rivera María Nieves
     *
     * Para no romper el comportamiento anterior, primero intentamos detectar
     * un nombre de pila conocido y, si no podemos determinar el orden con
     * suficiente confianza, usamos el primer nombre como antes.
     */
    private fun formatName(name: String, mode: String): String {
        val parts = name.split(Regex("""\s+""")).filter { it.isNotBlank() }
            .map { it.trim('.', ',', ':', ';', '-') }
            .filter { it.isNotBlank() }
        if (parts.isEmpty()) return name
        if (parts.size == 1) return parts.first()

        val givenNameIndexes = parts.mapIndexedNotNull { index, part ->
            if (isCommonGivenName(part)) index else null
        }

        // Formato normal: el primer token ya es un nombre de pila.
        if (givenNameIndexes.firstOrNull() == 0) {
            if (mode != NAME_FULL) return parts[0]
            // Si hay dos nombres de pila, el primer apellido es el token
            // inmediatamente posterior al bloque de nombres de pila.
            val firstSurnameIndex = if (parts.size >= 4) 2 else 1
            return if (firstSurnameIndex < parts.size) {
                "${parts[0]} ${parts[firstSurnameIndex]}"
            } else {
                parts[0]
            }
        }

        // Formato invertido: apellidos primero y luego nombres de pila.
        // Ej.: Rondo Rivera María Nieves -> María / María Rondo.
        val reversedGivenIndex = givenNameIndexes.firstOrNull { it >= 2 }
        if (reversedGivenIndex != null) {
            val firstGiven = parts[reversedGivenIndex]
            if (mode != NAME_FULL) return firstGiven
            return "${firstGiven} ${parts[0]}"
        }

        // Respaldo conservador para formatos que no podemos identificar.
        if (mode != NAME_FULL) return parts.first()
        return if (parts.size > 1) "${parts[0]} ${parts[1]}" else parts[0]
    }

    private fun isCommonGivenName(value: String): Boolean {
        val n = normalize(value)
        return n in COMMON_GIVEN_NAMES
    }

    private val COMMON_GIVEN_NAMES = setOf(
        "aaron", "abigail", "adriana", "agustin", "alejandra", "alejandro",
        "alex", "alexandra", "alfredo", "alicia", "amanda", "ana", "andrea",
        "angel", "angela", "angeles", "antonella", "antonio", "arturo", "beatriz",
        "benjamin", "brenda", "bruno", "camila", "carlos", "carla", "carmen", "danica",
        "carolina", "catalina", "cesar", "claudia", "cristian", "cristina",
        "daniela", "daniel", "david", "diana", "diego", "edgar", "eduardo",
        "elena", "elias", "elizabeth", "emilia", "emmanuel", "enrique", "erick",
        "estefania", "fabian", "fatima", "felipe", "fernanda", "fernando",
        "francisco", "gabriela", "gabriel", "gerardo", "gladys", "gloria",
        "gonzalo", "guadalupe", "hector", "helena", "hugo", "ignacio", "isabel",
        "isabella", "ivan", "jaime", "javier", "jean", "jesus", "jimena", "joel",
        "jorge", "jose", "josefina", "juan", "julia", "juliana", "karina", "kevin",
        "laura", "leonardo", "leslie", "liliana", "lorena", "lucas", "lucia",
        "luisa", "manuel", "manuela", "marco", "marcos", "maria", "mariana",
        "maribel", "mariela", "marisol", "mario", "martin", "mateo", "matias", "mabel",
        "maximo", "melanie", "melissa", "miguel", "milagros", "monica", "natalia",
        "nataly", "nicolas", "nieves", "noelia", "norma", "oscar", "pablo", "paola",
        "patricia", "pedro", "rafael", "raul", "rebecca", "ricardo", "roberto",
        "rosa", "rosario", "ruben", "sabrina", "samuel", "sandra", "santiago",
        "sebastian", "sergio", "silvia", "sofia", "sonia", "susana", "tania",
        "tatiana", "thalia", "valentina", "vanessa", "veronica", "victor", "victoria",
        "ximena", "yessica", "yolanda", "zacarias"
    )

    private fun cleanNotificationText(s: String): String {
        var x = s
        // Eliminamos el código de seguridad antes de buscar nombre/monto.
        x = x.replace(
            Regex("""(?i)(?:el\s+)?c[oó]d\.?\s*(?:de\s+)?seguridad\s*(?:es\s*)?[:]?\s*[A-Z0-9-]+"""),
            ""
        )
        x = x.replace(
            Regex("""(?i)(?:codigo|código|cod\.)\s*(?:de\s+)?(?:seguridad|verificacion|verificación)?\s*(?:es\s*)?[:]?\s*[A-Z0-9-]+"""),
            ""
        )
        x = x.replace(
            Regex("""(?i)(?:clave|pin|otp)\s*(?:es\s*)?[:]?\s*[A-Z0-9-]+"""),
            ""
        )
        return x.replace(Regex("""\s+"""), " ").trim()
    }

    private fun extractSecurityCode(s: String): String? {
        // Acepta "cód. de seguridad es: 725", "código de seguridad: 725",
        // "codigo seguridad 725", "clave 725", etc.
        val patterns = listOf(
            Regex("""(?i)(?:el\s+)?c[oó]d\.?\s*(?:de\s+)?seguridad\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b"""),
            Regex("""(?i)(?:codigo|código|cod\.)\s*(?:de\s+)?(?:seguridad|verificacion|verificación)?\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b"""),
            Regex("""(?i)(?:clave|pin|otp)\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b"""),
            Regex("""(?i)seguridad\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b""")
        )
        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            return match.groupValues[1]
        }
        return null
    }

    private fun buildPhrase(name: String?, amount: Amount, code: String?): String {
        val amountText = amountToSpanish(amount)
        val base = if (!name.isNullOrBlank()) {
            "Recibiste un Yape de $name por $amountText"
        } else {
            "Recibiste un Yape por $amountText"
        }

        // El punto genera una pausa clara antes del código.
        return if (!code.isNullOrBlank()) {
            "$base. Con código $code."
        } else {
            "$base."
        }
    }

    private fun amountToSpanish(amount: Amount): String {
        val solesText = numberToSpanishForSoles(amount.soles)
        return when {
            amount.soles == 0L && amount.cents > 0 -> "${centsToSpanish(amount.cents)} céntimos"
            amount.soles == 1L && amount.cents == 0 -> "un sol"
            amount.cents == 0 -> "$solesText soles"
            amount.soles == 1L -> "un sol ${amount.cents.toString().padStart(2, '0')}"
            else -> "$solesText soles ${amount.cents.toString().padStart(2, '0')}"
        }
    }

    private fun centsToSpanish(cents: Int): String {
        return when (cents) {
            1 -> "un"
            2 -> "dos"
            3 -> "tres"
            4 -> "cuatro"
            5 -> "cinco"
            6 -> "seis"
            7 -> "siete"
            8 -> "ocho"
            9 -> "nueve"
            10 -> "diez"
            11 -> "once"
            12 -> "doce"
            13 -> "trece"
            14 -> "catorce"
            15 -> "quince"
            16 -> "dieciséis"
            17 -> "diecisiete"
            18 -> "dieciocho"
            19 -> "diecinueve"
            20 -> "veinte"
            21 -> "veintiún"
            22 -> "veintidós"
            23 -> "veintitrés"
            24 -> "veinticuatro"
            25 -> "veinticinco"
            26 -> "veintiséis"
            27 -> "veintisiete"
            28 -> "veintiocho"
            29 -> "veintinueve"
            30 -> "treinta"
            40 -> "cuarenta"
            50 -> "cincuenta"
            60 -> "sesenta"
            70 -> "setenta"
            80 -> "ochenta"
            90 -> "noventa"
            else -> {
                val tens = (cents / 10) * 10
                val units = cents % 10
                "${centsToSpanish(tens)} y ${centsToSpanish(units)}"
            }
        }
    }

    private fun numberToSpanish(n: Long): String {
        if (n == 0L) return "cero"
        if (n in 1..999_999) return numberUnderMillion(n)
        return n.toString()
    }

    private fun numberToSpanishForSoles(n: Long): String {
        val text = numberToSpanish(n)
        return when {
            text == "uno" -> "un"
            text.endsWith(" veintiuno") -> text.removeSuffix("veintiuno") + "veintiún"
            text == "veintiuno" -> "veintiún"
            text.endsWith(" y uno") -> text.removeSuffix("y uno") + "y un"
            text.endsWith(" uno") -> text.removeSuffix("uno") + "un"
            else -> text
        }
    }

    private fun numberUnderMillion(n: Long): String {
        if (n < 1000) return underThousand(n)
        val thousands = n / 1000
        val rest = n % 1000
        val prefix = if (thousands == 1L) "mil" else "${underThousand(thousands)} mil"
        return if (rest == 0L) prefix else "$prefix ${underThousand(rest)}"
    }

    private fun underThousand(n: Long): String {
        val ones = arrayOf("cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve")
        val teens = arrayOf("diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve")
        val tens = arrayOf("", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa")
        val hundreds = arrayOf("", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos")

        if (n < 10) return ones[n.toInt()]
        if (n < 20) return teens[(n - 10).toInt()]
        if (n == 20L) return "veinte"
        if (n < 30) return "veinti" + ones[(n - 20).toInt()]
        if (n < 100) {
            val t = (n / 10).toInt()
            val u = (n % 10).toInt()
            return if (u == 0) tens[t] else "${tens[t]} y ${ones[u]}"
        }
        if (n == 100L) return "cien"
        val h = (n / 100).toInt()
        val rest = n % 100
        return if (rest == 0L) hundreds[h] else "${hundreds[h]} ${underThousand(rest)}"
    }

    private fun isSilentOrDnd(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: SecurityException) {
            false
        }
    }

    private fun isInCall(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return audio.mode == AudioManager.MODE_IN_CALL ||
            audio.mode == AudioManager.MODE_IN_COMMUNICATION
    }

    private fun normalize(s: String): String {
        return Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("""\p{M}+"""), "")
    }

    companion object {
        const val YAPE_PACKAGE = "com.bcp.innovacxion.yapeapp"
        const val FALABELLA_PACKAGE = "per.bf.desa"
        const val KEY_YAPE_ENABLED = "yape_enabled"
        const val KEY_FALABELLA_ENABLED = "falabella_enabled"
        const val KEY_READ_AMOUNT = "read_amount"
        const val PREFS = "app"
        const val KEY_ENABLED = "enabled"
        const val KEY_NAME_MODE = "name_mode"
        const val KEY_READ_CODE = "read_security_code"
        const val KEY_SKIP_CALLS = "skip_calls"
        const val KEY_RESPECT_SILENT = "respect_silent"
        const val NAME_FIRST = "first"
        const val NAME_FULL = "full"
        const val KEY_LISTENER_CONNECTED = "listener_connected"
        const val KEY_WATCHDOG_RUNNING = "watchdog_running"
        const val KEY_VOICE_NAME = "voice_name"
        const val KEY_VOICE_LOCALE = "voice_locale"
        const val KEY_YAPE_VOICE_NAME = "yape_voice_name"
        const val KEY_FALABELLA_VOICE_NAME = "falabella_voice_name"
        const val KEY_PAYMENT_HISTORY = "payment_history"
        const val KEY_COUNTER_RESET_AT = "counter_reset_at"
        private const val MAX_HISTORY_ITEMS = 500

        fun isConnected(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_LISTENER_CONNECTED, false)

        private fun setConnected(context: Context, connected: Boolean) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_LISTENER_CONNECTED, connected).apply()
        }

        fun loadAvailableSpanishVoices(context: Context, callback: (List<Voice>) -> Unit) {
            lateinit var voiceTts: TextToSpeech
            voiceTts = TextToSpeech(context) { result ->
                val voices = if (result == TextToSpeech.SUCCESS) {
                    voiceTts.voices.orEmpty()
                        .filter { it.locale.language.equals("es", ignoreCase = true) }
                        .sortedBy { it.name.lowercase(Locale.ROOT) }
                } else {
                    emptyList()
                }
                callback(voices)
                voiceTts.shutdown()
            }
        }

        fun testSpeech(context: Context, source: String) {
            lateinit var testTts: TextToSpeech
            testTts = TextToSpeech(context) { result ->
                if (result != TextToSpeech.SUCCESS) {
                    testTts.shutdown()
                    return@TextToSpeech
                }

                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val key = if (source == "Banco Falabella") KEY_FALABELLA_VOICE_NAME else KEY_YAPE_VOICE_NAME
                val savedVoiceName = prefs.getString(key, null)
                val availableVoices = testTts.voices.orEmpty()
                val selectedVoice = if (!savedVoiceName.isNullOrBlank()) {
                    availableVoices.firstOrNull { it.name == savedVoiceName } ?: testTts.defaultVoice
                } else {
                    testTts.defaultVoice
                }

                try {
                    if (selectedVoice != null) testTts.voice = selectedVoice
                } catch (_: Exception) {
                    testTts.setLanguage(Locale("es", "PE"))
                }

                // La prueba manual debe funcionar aunque el teléfono esté
                // en No molestar. Por eso no usa el canal de notificaciones
                // que DND puede silenciar. Los pagos reales siguen usando
                // notificaciones cuando la opción de respeto está activada.
                testTts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                testTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { testTts.shutdown() }
                    override fun onError(utteranceId: String?) { testTts.shutdown() }
                })
                testTts.speak(
                    if (source == "Banco Falabella") "Prueba de voz de Banco Falabella." else "Prueba de voz de Yape.",
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "test"
                )
            }
        }

        fun syncDefaultVoices(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            lateinit var syncTts: TextToSpeech
            syncTts = TextToSpeech(context) { result ->
                if (result != TextToSpeech.SUCCESS) {
                    syncTts.shutdown()
                    return@TextToSpeech
                }
                val defaultName = syncTts.defaultVoice?.name
                val oldSelected = prefs.getString(KEY_VOICE_NAME, null)
                val fallback = oldSelected ?: defaultName
                if (!fallback.isNullOrBlank()) {
                    val editor = prefs.edit()
                    if (prefs.getString(KEY_YAPE_VOICE_NAME, null).isNullOrBlank()) editor.putString(KEY_YAPE_VOICE_NAME, fallback)
                    if (prefs.getString(KEY_FALABELLA_VOICE_NAME, null).isNullOrBlank()) editor.putString(KEY_FALABELLA_VOICE_NAME, fallback)
                    editor.apply()
                }
                syncTts.shutdown()
            }
        }

        private fun recordPayment(
            context: Context,
            amount: Amount,
            name: String?,
            source: String = "Yape",
            code: String? = null,
            notificationTitle: String = "",
            notificationContent: String = ""
        ) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existing = try { JSONArray(prefs.getString(KEY_PAYMENT_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
            val item = JSONObject().apply {
                put("timestamp", System.currentTimeMillis())
                put("soles", amount.soles)
                put("cents", amount.cents)
                put("name", name ?: "")
                put("source", source)
                put("code", code ?: "")
                put("notification_title", notificationTitle)
                put("notification_content", notificationContent)
            }
            val updated = JSONArray()
            val startIndex = maxOf(0, existing.length() - MAX_HISTORY_ITEMS + 1)
            updated.put(item)
            for (i in startIndex until existing.length()) updated.put(existing.optJSONObject(i))
            prefs.edit().putString(KEY_PAYMENT_HISTORY, updated.toString()).apply()
        }

        fun getTodayYapeCount(context: Context): Int {
            val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date())
            val array = readHistory(context)
            var count = 0
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date(obj.optLong("timestamp", 0L)))
                if (date == today && obj.optString("source", "Yape") == "Yape") count++
            }
            return count
        }

        fun getTodayYapeSummary(context: Context): Pair<Int, Long> = getTodaySummary(context)

        fun getAllTimeSummary(context: Context): Pair<Int, Long> {
            val array = readHistory(context)
            var count = 0
            var cents = 0L
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                count++
                cents += obj.optLong("soles", 0L) * 100L + obj.optInt("cents", 0)
            }
            return count to cents
        }

        fun getTodaySummary(context: Context): Pair<Int, Long> {
            val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date())
            val array = readHistory(context)
            var count = 0
            var cents = 0L
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date(obj.optLong("timestamp", 0L)))
                if (date == today) {
                    count++
                    cents += obj.optLong("soles", 0L) * 100L + obj.optInt("cents", 0)
                }
            }
            return count to cents
        }

        fun getHistoryText(context: Context): String {
            val array = readHistory(context)
            if (array.length() == 0) return "No hay pagos registrados todavía."
            val format = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
            val lines = mutableListOf<String>()
            for (i in array.length() - 1 downTo 0) {
                val obj = array.optJSONObject(i) ?: continue
                val ts = obj.optLong("timestamp", 0L)
                val name = obj.optString("name", "").trim().ifBlank { "Sin nombre" }
                val soles = obj.optLong("soles", 0L)
                val cents = obj.optInt("cents", 0)
                val source = obj.optString("source", "Yape")
                val code = obj.optString("code", "").trim()
                val codeText = if (code.isNotBlank()) "  •  Código $code" else ""
                lines += "${format.format(java.util.Date(ts))}  •  $source  •  $name  •  S/ ${soles}.${cents.toString().padStart(2, '0')}$codeText"
                if (lines.size >= 12) break
            }
            return lines.joinToString("\n")
        }

        private fun readHistory(context: Context): JSONArray {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PAYMENT_HISTORY, "[]") ?: "[]"
            return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        }
    }

    private data class ParsedPayment(
        val amount: Amount,
        val speechName: String?,
        val historyName: String?,
        val code: String?
    )

    private data class Amount(val soles: Long, val cents: Int)
}
