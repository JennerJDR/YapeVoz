# Firma permanente de Pago Voz

La versión 1.2.5 usa `signing/pagovoz-release.jks` con alias `pagovoz`.

IMPORTANTE:
- Conservar siempre la carpeta `signing/`.
- No regenerar ni reemplazar el `.jks`.
- Mantener el mismo `applicationId`: `pe.pagovoz`.
- Las futuras versiones deben firmarse con esta misma clave para poder instalarse como actualización.
- El contenido de `signing/` es CONFIDENCIAL.
