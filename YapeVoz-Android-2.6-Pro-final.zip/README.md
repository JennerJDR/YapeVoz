# Yape Voz Pro 2.0

Aplicación Android que escucha únicamente las notificaciones de Yape y anuncia en voz alta los pagos recibidos.

## Novedades 2.0
- Protección en segundo plano mediante un servicio en primer plano de uso especial.
- Detección real de conexión del NotificationListenerService.
- Reconexión automática cuando Android desconecta el lector.
- Botón “Reactivar servicio” sin necesidad de reiniciar el teléfono.
- Al abrir la aplicación se vuelve a comprobar el estado real.
- Inicio automático de la protección después de reiniciar o actualizar la aplicación, si Yape Voz estaba activado.
- Mantiene las funciones de 1.6: lectura de nombre, monto, código de seguridad opcional, llamadas, silencio/DND y configuración de voz.

## Importante
Android y el fabricante del teléfono pueden imponer restricciones adicionales. La versión 2.0 reduce mucho la posibilidad de que el lector quede desconectado, pero ninguna aplicación de terceros puede garantizar que el sistema nunca la detenga. Por eso la app muestra el estado real y permite reactivar el servicio.


## Versión 2.2
Sincroniza la voz del lector con la voz seleccionada en la configuración de Texto a voz de Android, incluso si el servicio se inició antes del cambio.


Versión 2.2: interfaz reorganizada, acceso a inicio automático en Xiaomi y registro local de Yapes recibidos con resumen diario e historial reciente.


Versión 2.6: conserva las funciones de 2.5 (frase "[nombre] te yapeó [monto]", selector de primer nombre/nombre y apellido, código opcional, velocidad 0.80x-1.30x, historial y protección) y mejora la detección de notificaciones de Yape generadas desde bancos, incluyendo Scotiabank.
