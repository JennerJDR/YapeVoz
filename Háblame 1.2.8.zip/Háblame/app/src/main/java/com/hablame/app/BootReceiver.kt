package com.hablame.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != Intent.ACTION_LOCKED_BOOT_COMPLETED) return
        if (!Prefs.getBool(context, "service_enabled", true)) return
        if (!Prefs.getBool(context, "auto_background", true)) return

        val pending = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                // Give Android a moment to finish restoring system services after boot.
                Thread.sleep(1800L)
                HablameNotificationListener.requestRebind(app)
                try { TtsEngine.ensureCurrentEngine(app) } catch (_: Exception) { }
            } finally {
                pending.finish()
            }
        }.start()
    }
}
