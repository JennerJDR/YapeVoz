# Háblame 1.2.6

Proyecto Android de Háblame, paquete `com.hablame.app`.

Esta es una compilación de diagnóstico basada en la versión 1.2.5. Conserva el flujo de notificaciones existente y agrega un registro temporal del ciclo de vida de notificaciones de WhatsApp para averiguar qué señales entrega Android al editar o eliminar mensajes. El registro no guarda los textos ni nombres: solo guarda metadatos, longitudes y huellas de texto.

También amplía el control de velocidad de lectura a 0,3×–2,5×, incorpora control de tono de voz (0,5×–2,0×), botones para restablecer ambos valores y cancelación de repeticiones de llamada al contestar/finalizar.

Para generar el APK, sube `Háblame 1.2.6.zip` a la raíz del repositorio y copia el contenido de `.github/workflows/build.yml` en el archivo `.github/workflows/build.yml` del repositorio. Ejecuta GitHub Actions y descarga el artefacto `Hablame-APK-1.2.6`.

Importante: esta compilación recopila datos de diagnóstico; no se presenta como una solución definitiva para los avisos de edición/eliminación hasta revisar lo que WhatsApp expone realmente en el dispositivo.
