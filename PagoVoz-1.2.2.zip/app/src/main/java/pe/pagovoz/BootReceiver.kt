package pe.pagovoz

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences(PaymentNotificationListener.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(PaymentNotificationListener.KEY_ENABLED, true)) {
            PaymentWatchdogService.start(context)
        }
    }
}
