package pe.yapevoz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.graphics.BitmapFactory
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import java.util.Locale
import androidx.core.app.NotificationCompat

/**
 * Servicio en primer plano de vigilancia.
 * Mantiene el proceso de Yape Voz activo y pide a Android que vuelva a enlazar
 * el NotificationListener cuando se desconecta.
 */
class YapeWatchdogService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val checkRunnable = object : Runnable {
        override fun run() {
            checkListener()
            handler.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        setRunning(this, true)
        createChannel()
        startAsForeground()
        handler.post(checkRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        checkListener()
        return START_STICKY
    }

    override fun onDestroy() {
        setRunning(this, false)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun checkListener() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)) {
            stopSelf()
            return
        }

        val hasAccess = isNotificationListenerEnabled()
        val connected = YapeNotificationListener.isConnected(this)
        if (hasAccess && !connected) {
            // La reconexión se solicita desde el propio NotificationListenerService
            // en onListenerDisconnected(). Aquí solo vigilamos y mostramos el estado,
            // evitando llamar a la API desde un componente que no es el listener.
        }

        updateNotification(hasAccess, connected)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun startAsForeground() {
        val notification = buildNotification(
            access = isNotificationListenerEnabled(),
            connected = YapeNotificationListener.isConnected(this)
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(access: Boolean, connected: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(access, connected))
    }

    private fun buildNotification(access: Boolean, connected: Boolean): Notification {
        val summary = YapeNotificationListener.getTodaySummary(this)
        val count = summary.first
        val total = String.format(Locale.US, "S/ %.2f", summary.second / 100.0)
        val yapeLabel = if (count == 1) "Yapeo" else "Yapeos"
        val content = "$count $yapeLabel • Total: $total"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_yapevoz)
            .setLargeIcon(BitmapFactory.decodeResource(resources, R.drawable.yape_voz_icon))
            .setContentTitle("Yape Voz Pro")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Yape Voz - servicio activo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mantiene activo el lector de notificaciones de Yape Voz."
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "yape_voz_watchdog"
        private const val NOTIFICATION_ID = 2001
        private const val CHECK_INTERVAL_MS = 60_000L

        private fun setRunning(context: Context, running: Boolean) {
            context.getSharedPreferences(YapeNotificationListener.PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(YapeNotificationListener.KEY_WATCHDOG_RUNNING, running).apply()
        }

        fun isRunning(context: Context): Boolean =
            context.getSharedPreferences(YapeNotificationListener.PREFS, Context.MODE_PRIVATE)
                .getBoolean(YapeNotificationListener.KEY_WATCHDOG_RUNNING, false)

        fun start(context: Context) {
            val intent = Intent(context, YapeWatchdogService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
                // Si el sistema no permite iniciarlo en ese momento,
                // la próxima apertura de la app volverá a intentarlo.
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, YapeWatchdogService::class.java))
            } catch (_: Exception) {
            }
        }

        fun refresh(context: Context) {
            try {
                val service = context as? YapeWatchdogService
                if (service != null) {
                    service.updateNotification(
                        service.isNotificationListenerEnabled(),
                        YapeNotificationListener.isConnected(service)
                    )
                    return
                }
                val manager = context.getSystemService(NotificationManager::class.java)
                val summary = YapeNotificationListener.getTodaySummary(context)
                val count = summary.first
                val total = String.format(Locale.US, "S/ %.2f", summary.second / 100.0)
                val label = if (count == 1) "Yapeo" else "Yapeos"
                val content = "$count $label • Total: $total"
                manager.notify(
                    NOTIFICATION_ID,
                    NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_notification_yapevoz)
                        .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.yape_voz_icon))
                        .setContentTitle("Yape Voz Pro")
                        .setContentText(content)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                        .setOngoing(true)
                        .setCategory(NotificationCompat.CATEGORY_SERVICE)
                        .setPriority(NotificationCompat.PRIORITY_LOW)
                        .setOnlyAlertOnce(true)
                        .setShowWhen(false)
                        .build()
                )
            } catch (_: Exception) {
            }
        }
    }
}
