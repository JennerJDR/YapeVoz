import java.util.Base64

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val permanentKeystoreBase64 = System.getenv("HABLAME_KEYSTORE_BASE64")
val permanentKeystoreFile = layout.projectDirectory.file(".gradle/signing/hablame-release.jks").asFile
val usePermanentSigning = !permanentKeystoreBase64.isNullOrBlank()

if (usePermanentSigning) {
    permanentKeystoreFile.parentFile.mkdirs()
    permanentKeystoreFile.writeBytes(
        Base64.getDecoder().decode(permanentKeystoreBase64)
    )
}

android {
    namespace = "com.hablame.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hablame.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 62
        versionName = "1.5.8"
    }

    signingConfigs {
        create("permanentRelease") {
            if (usePermanentSigning) {
                storeFile = permanentKeystoreFile
                storePassword = System.getenv("HABLAME_KEYSTORE_PASSWORD") ?: ""
                keyAlias = System.getenv("HABLAME_KEY_ALIAS") ?: "hablame"
                keyPassword = System.getenv("HABLAME_KEY_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            // Si se configuró la clave permanente en GitHub Secrets, conservar la
            // firma entre versiones para instalar 1.4.3 encima de versiones anteriores. Si no,
            // usar debug para permitir una compilación de prueba.
            signingConfig = if (usePermanentSigning) {
                signingConfigs.getByName("permanentRelease")
            } else {
                signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
