package pe.yapevoz

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var screenFlipper: ViewFlipper
    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var nameModeSpinner: Spinner
    private lateinit var codeSwitch: Switch
    private lateinit var callsSwitch: Switch
    private lateinit var silentSwitch: Switch
    private lateinit var todayCount: TextView
    private lateinit var todayTotal: TextView
    private lateinit var historyText: TextView

    private lateinit var navInicio: Button
    private lateinit var navVoz: Button
    private lateinit var navLectura: Button
    private lateinit var navAjustes: Button

    private val statusHandler = Handler(Looper.getMainLooper())
    private val statusRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            updateStats()
            statusHandler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        screenFlipper = findViewById(R.id.screenFlipper)
        status = findViewById(R.id.status)
        enabledSwitch = findViewById(R.id.enabledSwitch)
        nameModeSpinner = findViewById(R.id.nameModeSpinner)
        codeSwitch = findViewById(R.id.codeSwitch)
        callsSwitch = findViewById(R.id.callsSwitch)
        silentSwitch = findViewById(R.id.silentSwitch)
        todayCount = findViewById(R.id.todayCount)
        todayTotal = findViewById(R.id.todayTotal)
        historyText = findViewById(R.id.historyText)

        val root = findViewById<View>(R.id.root)
        val initialTop = root.paddingTop
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(view.paddingLeft, initialTop + bars.top, view.paddingRight, initialBottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        navInicio = findViewById(R.id.navInicio)
        navVoz = findViewById(R.id.navVoz)
        navLectura = findViewById(R.id.navLectura)
        navAjustes = findViewById(R.id.navAjustes)

        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)

        val modes = listOf("Solo primer nombre", "Nombre y apellido")
        nameModeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modes
        )

        val savedMode = prefs.getString(
            YapeNotificationListener.KEY_NAME_MODE,
            YapeNotificationListener.NAME_FIRST
        ) ?: YapeNotificationListener.NAME_FIRST

        nameModeSpinner.setSelection(
            if (savedMode == YapeNotificationListener.NAME_FULL) 1 else 0
        )

        nameModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val value = if (position == 1) {
                    YapeNotificationListener.NAME_FULL
                } else {
                    YapeNotificationListener.NAME_FIRST
                }
                prefs.edit().putString(YapeNotificationListener.KEY_NAME_MODE, value).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        enabledSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)
        codeSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_READ_CODE, false)
        callsSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
        silentSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)

        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_ENABLED, checked).apply()
            if (checked) {
                startProtection()
            } else {
                YapeWatchdogService.stop(this)
            }
            updateStatus()
        }

        codeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_READ_CODE, checked).apply()
        }

        callsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, checked).apply()
        }

        silentSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, checked).apply()
        }

        findViewById<Button>(R.id.testButtonVoice).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }

        findViewById<Button>(R.id.reactivateButton).setOnClickListener {
            reactivateService()
        }

        findViewById<Button>(R.id.notificationsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.autostartButton).setOnClickListener {
            openAutoStartSettings()
        }

        findViewById<Button>(R.id.voiceSettingsButton).setOnClickListener {
            openTtsSettings()
        }

        setupNavigation()
        showScreen(0)
        startProtection()
        updateStatus()
        updateStats()
    }

    override fun onResume() {
        super.onResume()
        startProtection()
        YapeNotificationListener.syncDefaultVoice(this)
        updateStatus()
        updateStats()
        statusHandler.removeCallbacks(statusRunnable)
        statusHandler.postDelayed(statusRunnable, 1000L)
    }

    override fun onPause() {
        statusHandler.removeCallbacks(statusRunnable)
        super.onPause()
    }

    private fun openAutoStartSettings() {
        // Xiaomi/Redmi/POCO: abre directamente la pantalla de
        // "Autoencendido" (Autostart) de Seguridad. Xiaomi expone
        // esta pantalla mediante SecurityCenter; el usuario debe
        // activar manualmente Yape Voz.
        val xiaomiIntent = Intent().apply {
            component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
        }
        try {
            if (xiaomiIntent.resolveActivity(packageManager) != null) {
                startActivity(xiaomiIntent)
                return
            }
        } catch (_: Exception) {}

        // Algunas versiones de HyperOS exponen una acción propia.
        val hyperOsIntent = Intent("miui.intent.action.OP_AUTO_START").apply {
            setPackage("com.miui.securitycenter")
            data = Uri.parse("package:$packageName")
        }
        try {
            if (hyperOsIntent.resolveActivity(packageManager) != null) {
                startActivity(hyperOsIntent)
                return
            }
        } catch (_: Exception) {}

        // Último recurso: información de la aplicación.
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        try {
            startActivity(appDetails)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updateStats() {
        val summary = YapeNotificationListener.getTodaySummary(this)
        todayCount.text = summary.first.toString()
        todayTotal.text = String.format(Locale.US, "S/ %.2f", summary.second / 100.0)
        historyText.text = YapeNotificationListener.getHistoryText(this)
    }

    private fun setupNavigation() {
        navInicio.setOnClickListener { showScreen(0) }
        navLectura.setOnClickListener { showScreen(1) }
        navVoz.setOnClickListener { showScreen(2) }
        navAjustes.setOnClickListener { showScreen(3) }
    }

    private fun showScreen(index: Int) {
        screenFlipper.displayedChild = index

        val selected = "#5B20D8"
        val normal = "#776F87"
        navInicio.setTextColor(if (index == 0) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navLectura.setTextColor(if (index == 1) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navVoz.setTextColor(if (index == 2) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navAjustes.setTextColor(if (index == 3) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))

        navInicio.setBackgroundResource(if (index == 0) R.drawable.bg_selected_nav else android.R.color.transparent)
        navLectura.setBackgroundResource(if (index == 1) R.drawable.bg_selected_nav else android.R.color.transparent)
        navVoz.setBackgroundResource(if (index == 2) R.drawable.bg_selected_nav else android.R.color.transparent)
        navAjustes.setBackgroundResource(if (index == 3) R.drawable.bg_selected_nav else android.R.color.transparent)
    }

    private fun openTtsSettings() {
        val intents = listOf(
            Intent("com.android.settings.TTS_SETTINGS").setPackage("com.android.settings"),
            Intent("android.settings.TTS_SETTINGS"),
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent("android.settings.TEXT_TO_SPEECH_SETTINGS")
        )

        for (intent in intents) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: ActivityNotFoundException) {
                // Intentar la siguiente opción.
            }
        }

        try {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun startProtection() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)) {
            YapeWatchdogService.start(this)
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun reactivateService() {
        if (!isNotificationListenerEnabled()) {
            Toast.makeText(
                this,
                "Activa primero el acceso a notificaciones de Yape Voz.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return
        }

        getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
            .edit().putBoolean(YapeNotificationListener.KEY_ENABLED, true).apply()
        enabledSwitch.isChecked = true
        YapeWatchdogService.start(this)

        Toast.makeText(this, "Servicio de Yape Voz reactivado.", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        val listenerAccess = isNotificationListenerEnabled()
        val connected = YapeNotificationListener.isConnected(this)
        val watchdog = YapeWatchdogService.isRunning(this)

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) == true

        status.text = buildString {
            append(if (connected) "✓ Escuchando notificaciones de Yape\n" else if (listenerAccess) "⚠ Acceso activo, pero el lector no está conectado\n" else "⚠ Falta acceso a notificaciones\n")
            append(if (watchdog) "✓ Protección en segundo plano activa\n" else "⚠ Protección en segundo plano detenida\n")
            append(if (batteryOk) "✓ Batería sin restricciones\n" else "⚠ Falta quitar restricción de batería\n")
            append(if (enabledSwitch.isChecked) "✓ Yape Voz está ACTIVADA" else "⏸ Yape Voz está PAUSADA")
        }
    }
}
