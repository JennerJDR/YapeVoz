package pe.yapevoz

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class YapeNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private val lastSpokenAt = AtomicLong(0L)
    private var lastNotificationKey: String? = null
    private val reconnectHandler = Handler(Looper.getMainLooper())
    private var reconnectAttempts = 0
    private val reconnectRunnable = object : Runnable {
        override fun run() {
            if (YapeNotificationListener.isConnected(this@YapeNotificationListener)) {
                reconnectAttempts = 0
                return
            }

            try {
                requestRebind(ComponentName(this@YapeNotificationListener, YapeNotificationListener::class.java))
            } catch (_: Exception) {
            }

            reconnectAttempts++
            if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                reconnectHandler.postDelayed(this, RECONNECT_DELAY_MS)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        setConnected(this, false)
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                configureTts(tts)
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        reconnectHandler.removeCallbacksAndMessages(null)
        reconnectAttempts = 0
        setConnected(this, true)
    }

    override fun onListenerDisconnected() {
        setConnected(this, false)
        reconnectHandler.removeCallbacksAndMessages(null)
        reconnectAttempts = 0
        reconnectHandler.postDelayed(reconnectRunnable, 2000L)
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        setConnected(this, false)
        reconnectHandler.removeCallbacksAndMessages(null)
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ENABLED, true)) return
        if (prefs.getBoolean(KEY_RESPECT_SILENT, true) && isSilentOrDnd()) return
        if (prefs.getBoolean(KEY_SKIP_CALLS, true) && isInCall()) return

        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val bigTitle = extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val infoText = extras.getCharSequence(Notification.EXTRA_INFO_TEXT)?.toString().orEmpty()

        // El título y el contenido son campos distintos en Android.
        // La notificación normal de Yape puede decir "Confirmación de Pago"
        // en el título y dejar en el contenido solamente:
        // "Alan Her* te envió un pago por S/ 3...".
        // Por eso NO exigimos que la palabra "Yape" aparezca dentro del contenido.
        val raw = listOf(bigText, text, subText, infoText)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(". ")

        if (raw.isBlank()) return

        val notificationKey = sbn.key + "|" + title + "|" + bigTitle + "|" + raw
        if (notificationKey == lastNotificationKey) return

        val cleaned = cleanNotificationText(raw)
        val amount = extractAmount(cleaned) ?: return
        if (!looksLikeYapePayment(sbn.packageName, cleaned)) return

        val sender = extractSenderName(cleaned)
        val nameMode = prefs.getString(KEY_NAME_MODE, NAME_FIRST) ?: NAME_FIRST
        val spokenName = sender?.let { formatName(it, nameMode, sbn.packageName) }

        // El código se extrae del texto ORIGINAL. Así no se pierde al limpiarlo.
        val code = if (prefs.getBoolean(KEY_READ_CODE, false)) {
            extractSecurityCode(raw)
        } else {
            null
        }

        val phrase = buildPhrase(spokenName, amount, code)

        val now = System.currentTimeMillis()
        if (now - lastSpokenAt.get() < 1200L) return

        lastSpokenAt.set(now)
        lastNotificationKey = notificationKey
        recordPayment(this, amount, spokenName)
        YapeWatchdogService.refresh(this)
        speak(phrase)
    }

    private fun speak(text: String) {
        val engine = tts ?: return
        // Android puede mantener una instancia de TTS creada antes de que el
        // usuario cambie la voz. Sincronizamos justo antes de cada anuncio.
        if (engine.isSpeaking) engine.stop()
        configureTts(engine)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val volume = prefs.getFloat(KEY_TTS_VOLUME, DEFAULT_TTS_VOLUME)
            .coerceIn(MIN_TTS_VOLUME, MAX_TTS_VOLUME)
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, "yape_payment")
    }

    private fun configureTts(engine: TextToSpeech?) {
        engine ?: return

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val savedVoiceName = prefs.getString(KEY_VOICE_NAME, null)
        val availableVoices = engine.voices.orEmpty()

        // La voz guardada por la aplicación tiene prioridad.
        // No debemos reemplazarla por la voz predeterminada del sistema al
        // llegar una notificación: ese era el motivo de que se escuchara otra voz.
        val currentDefault = engine.defaultVoice
        val selectedVoice = if (!savedVoiceName.isNullOrBlank()) {
            availableVoices.firstOrNull { it.name == savedVoiceName } ?: currentDefault
        } else {
            currentDefault
        }

        if (selectedVoice != null) {
            try {
                engine.voice = selectedVoice
            } catch (_: Exception) {
                engine.setLanguage(Locale("es", "PE"))
            }
        } else {
            engine.setLanguage(Locale("es", "PE"))
        }

        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }

    private fun looksLikeYapePayment(
        packageName: String,
        content: String
    ): Boolean {
        val normalizedContent = normalize(content)
        val hasPaymentPhrase = listOf(
            "te envio", "te envió", "te yapeo", "te yapeó",
            "te hizo un yape", "te hizo un pago",
            "recibiste", "confirmacion de pago", "confirmación de pago",
            "pago por"
        ).any { normalizedContent.contains(normalize(it)) }

        if (!hasPaymentPhrase) return false

        // Caso 1: notificación nativa de Yape.
        if (packageName == YAPE_PACKAGE) return true

        // Caso 2: notificación generada por un banco. Normalmente el banco
        // incluye "Yape!" en el contenido, aunque la aplicación emisora sea
        // BCP, Interbank, Scotiabank u otra.
        val hasYapeMarker = normalizedContent.contains("yape!") ||
            Regex("\\byape\\b").containsMatchIn(normalizedContent)

        // En la app oficial de Yape también puede aparecer "Confirmación de Pago"
        // solamente en el título; ese caso ya quedó cubierto por packageName.
        // Para otras aplicaciones exigimos el marcador Yape en el contenido para
        // evitar anunciar transferencias bancarias que no sean Yape.
        return hasYapeMarker
    }

    private fun extractAmount(s: String): Amount? {
        val patterns = listOf(
            Regex("""(?i)\bs\s*/\s*([0-9]+(?:[.,][0-9]{1,2})?)"""),
            Regex("""(?i)\b([0-9]+(?:[.,][0-9]{1,2})?)\s*(?:soles?|s/)\b"""),
            Regex("""(?i)\bpor\s+(?:s\s*/\s*)?([0-9]+(?:[.,][0-9]{1,2})?)\b""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val value = match.groupValues[1].replace(',', '.')
            val parts = value.split('.')
            val soles = parts[0].toLongOrNull() ?: continue
            val cents = if (parts.size > 1) {
                (parts[1] + "00").take(2).toIntOrNull() ?: 0
            } else 0
            if (cents !in 0..99) continue
            return Amount(soles, cents)
        }
        return null
    }

    private fun extractSenderName(s: String): String? {
        // Formato común de Yape/Interbank: "Yape! Nombre Apellido te envió..."
        // También acepta el formato del BCP: "Yape! APELLIDO1 APELLIDO2 NOMBRE1 NOMBRE2..."
        val yapePrefixPattern = Regex(
            """(?i)\bYape!\s*(.+?)\s+te\s+(?:envio|envió|yapeo|yapeó)\b"""
        )
        yapePrefixPattern.find(s)?.let { match ->
            val name = cleanName(match.groupValues[1])
            if (isPlausibleName(name)) return name
        }

        val patterns = listOf(
            Regex("""(?i)^\s*([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,80}?)[*]?\s+te\s+(?:envio|envió|yapeo|yapeó)\b"""),
            Regex("""(?i)(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,80}?)[*]?\s+(?=por\b|s\s*/|soles?\b)"""),
            Regex("""(?i)(?:recibiste|recibio|recibió)\s+(?:un\s+)?(?:yape|pago)?\s*(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,80}?)[*]?\s+(?=por\b|s\s*/|soles?\b)""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val name = cleanName(match.groupValues[1])
            if (isPlausibleName(name)) return name
        }
        return null
    }

    private fun cleanName(name: String): String {
        return name
            .replace("*", "")
            .trim()
            .replace(Regex("""\s+"""), " ")
            .trim('.', ',', ':', ';', '-')
    }

    private fun isPlausibleName(name: String): Boolean {
        if (name.length !in 2..60) return false
        val words = name.split(Regex("""\s+""")).filter { it.length >= 2 }
        if (words.isEmpty()) return false
        val blocked = setOf("yape", "pago", "dinero", "tu", "un", "una", "el", "la", "te", "confirmacion")
        return normalize(name) !in blocked
    }

    private fun formatName(name: String, mode: String, packageName: String): String {
        val cleaned = cleanName(name)
        val parts = cleaned.split(Regex("""\s+""")).filter { it.isNotBlank() }
            .map { it.trim('.', ',', ':', ';', '-') }
        if (parts.isEmpty()) return cleaned

        val uppercaseFormat = isMostlyUppercase(cleaned)

        // BCP suele enviar apellidos primero y en mayúsculas.
        // Solo aplicamos esta regla al paquete del BCP para no confundir
        // notificaciones de Scotiabank/Interbank que también pueden venir
        // completamente en mayúsculas.
        val isBcpBank = packageName == BCP_BANK_PACKAGE ||
            packageName.contains("bcp.bank", ignoreCase = true)

        if (isBcpBank && uppercaseFormat && parts.size >= 4) {
            val firstSurname = prettyNameWord(parts[0])
            val firstName = prettyNameWord(parts[2])
            return if (mode == NAME_FULL) "$firstName $firstSurname" else firstName
        }

        if (isBcpBank && uppercaseFormat && parts.size == 3) {
            val firstSurname = prettyNameWord(parts[0])
            val firstName = prettyNameWord(parts[2])
            return if (mode == NAME_FULL) "$firstName $firstSurname" else firstName
        }

        // Yape, Interbank, Scotiabank y otras notificaciones suelen enviar
        // nombres primero: Yasmit Noemi Mezones Garcia -> Yasmit / Yasmit Mezones
        if (parts.size >= 4) {
            val firstName = prettyNameWord(parts[0])
            val firstSurname = prettyNameWord(parts[2])
            return if (mode == NAME_FULL) {
                "$firstName $firstSurname"
            } else {
                firstName
            }
        }

        // Para nombres de tres palabras no podemos saber con certeza si hay
        // uno o dos nombres. Usamos el primer nombre y la última palabra como
        // apellido para mantener una salida corta y natural.
        if (parts.size == 3) {
            val firstName = prettyNameWord(parts[0])
            val firstSurname = prettyNameWord(parts[2])
            return if (mode == NAME_FULL) "$firstName $firstSurname" else firstName
        }

        val first = prettyNameWord(parts.first())
        return if (mode == NAME_FULL) {
            val second = parts.getOrNull(1)?.let { prettyNameWord(it) }
            listOfNotNull(first, second).joinToString(" ")
        } else {
            first
        }
    }

    private fun prettyNameWord(word: String): String {
        val lower = word.lowercase(Locale.getDefault())
        return lower.replaceFirstChar { char ->
            if (char.isLowerCase()) char.titlecase(Locale.getDefault()) else char.toString()
        }
    }

    private fun isMostlyUppercase(value: String): Boolean {
        val letters = value.filter { it.isLetter() }
        if (letters.length < 3) return false
        return letters.count { it.isUpperCase() }.toDouble() / letters.length >= 0.85
    }

    private fun cleanNotificationText(s: String): String {
        var x = s
        // Eliminamos el código de seguridad antes de buscar nombre/monto.
        x = x.replace(
            Regex("""(?i)(?:el\s+)?c[oó]d\.?\s*(?:de\s+)?seguridad\s*(?:es\s*)?[:]?\s*[A-Z0-9-]+"""),
            ""
        )
        x = x.replace(
            Regex("""(?i)(?:codigo|código|cod\.)\s*(?:de\s+)?(?:seguridad|verificacion|verificación)?\s*(?:es\s*)?[:]?\s*[A-Z0-9-]+"""),
            ""
        )
        x = x.replace(
            Regex("""(?i)(?:clave|pin|otp)\s*(?:es\s*)?[:]?\s*[A-Z0-9-]+"""),
            ""
        )
        return x.replace(Regex("""\s+"""), " ").trim()
    }

    private fun extractSecurityCode(s: String): String? {
        // Acepta "cód. de seguridad es: 725", "código de seguridad: 725",
        // "codigo seguridad 725", "clave 725", etc.
        val patterns = listOf(
            Regex("""(?i)(?:el\s+)?c[oó]d\.?\s*(?:de\s+)?seguridad\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b"""),
            Regex("""(?i)(?:codigo|código|cod\.)\s*(?:de\s+)?(?:seguridad|verificacion|verificación)?\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b"""),
            Regex("""(?i)(?:clave|pin|otp)\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b"""),
            Regex("""(?i)seguridad\s*(?:es\s*)?[:]?\s*([0-9]{3,8})\b""")
        )
        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            return match.groupValues[1]
        }
        return null
    }

    private fun buildPhrase(name: String?, amount: Amount, code: String?): String {
        val amountText = amountToSpanish(amount)
        val base = if (!name.isNullOrBlank()) {
            "¡Pago recibido! $name te yapeó $amountText."
        } else {
            "¡Pago recibido! Recibiste un Yape por $amountText."
        }

        // Los puntos producen pausas breves y naturales, sin silencios largos.
        return if (!code.isNullOrBlank()) {
            "$base Código $code."
        } else {
            base
        }
    }

    private fun amountToSpanish(amount: Amount): String {
        val solesText = numberToSpanish(amount.soles)
        return when {
            amount.soles == 0L && amount.cents > 0 -> "${centsToSpanish(amount.cents)} céntimos"
            amount.soles == 1L && amount.cents == 0 -> "un sol"
            amount.cents == 0 -> "$solesText soles"
            amount.soles == 1L -> "un sol con ${centsToSpanish(amount.cents)} céntimos"
            else -> "$solesText soles con ${centsToSpanish(amount.cents)} céntimos"
        }
    }

    private fun centsToSpanish(cents: Int): String {
        return when (cents) {
            1 -> "un"
            2 -> "dos"
            3 -> "tres"
            4 -> "cuatro"
            5 -> "cinco"
            6 -> "seis"
            7 -> "siete"
            8 -> "ocho"
            9 -> "nueve"
            10 -> "diez"
            11 -> "once"
            12 -> "doce"
            13 -> "trece"
            14 -> "catorce"
            15 -> "quince"
            16 -> "dieciséis"
            17 -> "diecisiete"
            18 -> "dieciocho"
            19 -> "diecinueve"
            20 -> "veinte"
            21 -> "veintiún"
            22 -> "veintidós"
            23 -> "veintitrés"
            24 -> "veinticuatro"
            25 -> "veinticinco"
            26 -> "veintiséis"
            27 -> "veintisiete"
            28 -> "veintiocho"
            29 -> "veintinueve"
            30 -> "treinta"
            40 -> "cuarenta"
            50 -> "cincuenta"
            60 -> "sesenta"
            70 -> "setenta"
            80 -> "ochenta"
            90 -> "noventa"
            else -> {
                val tens = (cents / 10) * 10
                val units = cents % 10
                "${centsToSpanish(tens)} y ${centsToSpanish(units)}"
            }
        }
    }

    private fun numberToSpanish(n: Long): String {
        if (n == 0L) return "cero"
        if (n in 1..999_999) return numberUnderMillion(n)
        return n.toString()
    }

    private fun numberUnderMillion(n: Long): String {
        if (n < 1000) return underThousand(n)
        val thousands = n / 1000
        val rest = n % 1000
        val prefix = if (thousands == 1L) "mil" else "${underThousand(thousands)} mil"
        return if (rest == 0L) prefix else "$prefix ${underThousand(rest)}"
    }

    private fun underThousand(n: Long): String {
        val ones = arrayOf("cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve")
        val teens = arrayOf("diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve")
        val tens = arrayOf("", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa")
        val hundreds = arrayOf("", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos")

        if (n < 10) return ones[n.toInt()]
        if (n < 20) return teens[(n - 10).toInt()]
        if (n == 20L) return "veinte"
        if (n < 30) return "veinti" + ones[(n - 20).toInt()]
        if (n < 100) {
            val t = (n / 10).toInt()
            val u = (n % 10).toInt()
            return if (u == 0) tens[t] else "${tens[t]} y ${ones[u]}"
        }
        if (n == 100L) return "cien"
        val h = (n / 100).toInt()
        val rest = n % 100
        return if (rest == 0L) hundreds[h] else "${hundreds[h]} ${underThousand(rest)}"
    }

    private fun isSilentOrDnd(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: SecurityException) {
            false
        }
    }

    private fun isInCall(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return audio.mode == AudioManager.MODE_IN_CALL ||
            audio.mode == AudioManager.MODE_IN_COMMUNICATION
    }

    private fun normalize(s: String): String {
        return Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("""\p{M}+"""), "")
    }

    companion object {
        const val YAPE_PACKAGE = "com.bcp.innovacxion.yapeapp"
        const val BCP_BANK_PACKAGE = "com.bcp.bank.bcp"
        const val PREFS = "app"
        const val KEY_ENABLED = "enabled"
        const val KEY_NAME_MODE = "name_mode"
        const val KEY_READ_CODE = "read_security_code"
        const val KEY_SKIP_CALLS = "skip_calls"
        const val KEY_RESPECT_SILENT = "respect_silent"
        const val NAME_FIRST = "first"
        const val NAME_FULL = "full"
        const val KEY_LISTENER_CONNECTED = "listener_connected"
        const val KEY_WATCHDOG_RUNNING = "watchdog_running"
        const val KEY_VOICE_NAME = "voice_name"
        const val KEY_VOICE_LOCALE = "voice_locale"
        const val KEY_PAYMENT_HISTORY = "payment_history"
        const val KEY_TTS_VOLUME = "tts_volume"
        const val DEFAULT_TTS_VOLUME = 1.0f
        const val MIN_TTS_VOLUME = 0.0f
        const val MAX_TTS_VOLUME = 1.0f
        private const val MAX_HISTORY_ITEMS = 500
        private const val RECONNECT_DELAY_MS = 5000L
        private const val MAX_RECONNECT_ATTEMPTS = 12

        fun isConnected(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_LISTENER_CONNECTED, false)

        private fun setConnected(context: Context, connected: Boolean) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_LISTENER_CONNECTED, connected).apply()
        }

        fun testSpeech(context: Context) {
            lateinit var testTts: TextToSpeech
            testTts = TextToSpeech(context) { result ->
                if (result != TextToSpeech.SUCCESS) {
                    testTts.shutdown()
                    return@TextToSpeech
                }

                val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val savedVoiceName = prefs.getString(KEY_VOICE_NAME, null)
                val availableVoices = testTts.voices.orEmpty()
                val selectedVoice = if (!savedVoiceName.isNullOrBlank()) {
                    availableVoices.firstOrNull { it.name == savedVoiceName } ?: testTts.defaultVoice
                } else {
                    testTts.defaultVoice
                }

                try {
                    if (selectedVoice != null) testTts.voice = selectedVoice
                } catch (_: Exception) {
                    testTts.setLanguage(Locale("es", "PE"))
                }

                val volume = prefs.getFloat(KEY_TTS_VOLUME, DEFAULT_TTS_VOLUME)
                    .coerceIn(MIN_TTS_VOLUME, MAX_TTS_VOLUME)

                testTts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                testTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { testTts.shutdown() }
                    override fun onError(utteranceId: String?) { testTts.shutdown() }
                })
                val params = Bundle().apply {
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume)
                }
                testTts.speak(
                    "Prueba de Yape Voz. El lector de pagos está funcionando.",
                    TextToSpeech.QUEUE_FLUSH,
                    params,
                    "test"
                )
            }
        }

        fun syncDefaultVoice(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!prefs.getString(KEY_VOICE_NAME, null).isNullOrBlank()) return

            lateinit var syncTts: TextToSpeech
            syncTts = TextToSpeech(context) { result ->
                if (result != TextToSpeech.SUCCESS) {
                    syncTts.shutdown()
                    return@TextToSpeech
                }
                syncTts.defaultVoice?.let { voice ->
                    prefs.edit()
                        .putString(KEY_VOICE_NAME, voice.name)
                        .putString(KEY_VOICE_LOCALE, voice.locale.toLanguageTag())
                        .apply()
                }
                syncTts.shutdown()
            }
        }

        private fun recordPayment(context: Context, amount: Amount, name: String?) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existing = try { JSONArray(prefs.getString(KEY_PAYMENT_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
            val item = JSONObject().apply {
                put("timestamp", System.currentTimeMillis())
                put("soles", amount.soles)
                put("cents", amount.cents)
                put("name", name ?: "")
            }
            val updated = JSONArray()
            updated.put(item)
            val start = maxOf(0, existing.length() - MAX_HISTORY_ITEMS + 1)
            for (i in start until existing.length()) updated.put(existing.optJSONObject(i))
            prefs.edit().putString(KEY_PAYMENT_HISTORY, updated.toString()).apply()
        }

        fun getTodaySummary(context: Context): Pair<Int, Long> {
            val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date())
            val array = readHistory(context)
            var count = 0
            var cents = 0L
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val date = SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date(obj.optLong("timestamp", 0L)))
                if (date == today) {
                    count++
                    cents += obj.optLong("soles", 0L) * 100L + obj.optInt("cents", 0)
                }
            }
            return count to cents
        }

        fun getHistoryText(context: Context): String {
            val array = readHistory(context)
            if (array.length() == 0) return "No hay Yapes registrados todavía."
            val format = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
            val lines = mutableListOf<String>()
            for (i in array.length() - 1 downTo 0) {
                val obj = array.optJSONObject(i) ?: continue
                val ts = obj.optLong("timestamp", 0L)
                val name = obj.optString("name", "").trim().ifBlank { "Sin nombre" }
                val soles = obj.optLong("soles", 0L)
                val cents = obj.optInt("cents", 0)
                lines += "${format.format(java.util.Date(ts))}  •  $name  •  S/ ${soles}.${cents.toString().padStart(2, '0')}"
                if (lines.size >= 12) break
            }
            return lines.joinToString("\n")
        }

        private fun readHistory(context: Context): JSONArray {
            val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PAYMENT_HISTORY, "[]") ?: "[]"
            return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
        }
    }

    private data class Amount(val soles: Long, val cents: Int)
}
