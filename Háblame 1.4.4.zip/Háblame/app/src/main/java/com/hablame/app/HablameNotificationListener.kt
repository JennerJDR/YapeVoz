package com.hablame.app

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.ComponentName
import android.content.pm.PackageManager
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.provider.ContactsContract
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class HablameNotificationListener : NotificationListenerService() {
    companion object {
        private val recent = ConcurrentHashMap<String, Long>()
        @Volatile private var connected = false

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(":").any {
                try { ComponentName.unflattenFromString(it) == ComponentName(context, HablameNotificationListener::class.java) }
                catch (_: Exception) { false }
            }
        }

        fun isConnected(): Boolean = connected

        fun requestRebind(context: Context) {
            try {
                if (isEnabled(context)) {
                    NotificationListenerService.requestRebind(ComponentName(context, HablameNotificationListener::class.java))
                }
            } catch (_: Exception) { }
        }

        fun updatePersistentNotification(context: Context) {
            if (!Prefs.getBool(context, "service_enabled", true) ||
                !Prefs.getBool(context, "permanent_notification", true) ||
                !isConnected()
            ) {
                cancelPersistentNotification(context)
                return
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "hablame_service"
            if (Build.VERSION.SDK_INT >= 26) {
                val channel = NotificationChannel(
                    channelId,
                    "Estado de Háblame",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Indica que Háblame está escuchando notificaciones"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(channel)
            }
            val intent = Intent(context, MainActivity::class.java)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            val pi = PendingIntent.getActivity(context, 1001, intent, flags)
            val builder = if (Build.VERSION.SDK_INT >= 26)
                Notification.Builder(context, channelId)
            else
                Notification.Builder(context)
            builder.setSmallIcon(R.drawable.ic_bell)
                .setContentTitle("Háblame está activo")
                .setContentText("Escuchando llamadas y notificaciones")
                .setOngoing(true)
                .setAutoCancel(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .setShowWhen(false)
            try { nm.notify(1001, builder.build()) } catch (_: Exception) { }
        }

        fun cancelPersistentNotification(context: Context) {
            try {
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .cancel(1001)
            } catch (_: Exception) { }
        }
    }
    private val worker: ExecutorService by lazy { Executors.newSingleThreadExecutor() }


    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
        if (Prefs.getBool(this, "service_enabled", true)) postServiceNotification() else cancelServiceNotification()
        try { TtsEngine.ensureCurrentEngine(applicationContext) } catch (_: Exception) { }
    }

    override fun onListenerDisconnected() {
        connected = false
        cancelServiceNotification()
        super.onListenerDisconnected()
    }

    private fun postServiceNotification() {
        updatePersistentNotification(applicationContext)
    }

    private fun cancelServiceNotification() {
        cancelPersistentNotification(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        // Keep the selected TTS engine initialized while the listener is alive,
        // so a locked-screen notification can be spoken without waiting for the UI.
        try { TtsEngine.ensureCurrentEngine(applicationContext) } catch (_: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.getBool(this, "service_enabled", true)) return
        if (sbn.packageName == packageName) return
        val app = applicationContext
        worker.execute {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Hablame:NotificationSpeech")
            try {
                wakeLock.acquire(60000L)
                processNotification(app, sbn)
            } catch (_: Exception) {
                // Never let one notification stop the listener worker.
            } finally {
                try { if (wakeLock.isHeld) wakeLock.release() } catch (_: Exception) { }
            }
        }
    }


    override fun onNotificationRemoved(sbn: StatusBarNotification, rankingMap: RankingMap, reason: Int) {
        super.onNotificationRemoved(sbn, rankingMap, reason)
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun processNotification(context: Context, sbn: StatusBarNotification) {
        if (!Prefs.getBool(context, "service_enabled", true)) return
        val pkg = sbn.packageName
        val knownKey = "app_$pkg"
        val detailedApps = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.facebook.katana",
            "com.zhiliaoapp.musically",
            "com.google.android.gm"
        )

        if (!Prefs.getBool(context, knownKey, pkg == "com.whatsapp")) return

        if (!canSpeak()) return
        val n = sbn.notification ?: return
        val isGroupSummaryNotification = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0

        val extras = n.extras ?: Bundle()

        // No anunciar controles/actualizaciones multimedia. WhatsApp puede
        // publicar y actualizar una notificación de reproducción mientras
        // se escucha una nota de voz. El NotificationListener recibe cada
        // actualización y, si la tratamos como un mensaje nuevo, Háblame
        // termina repitiendo “WhatsApp” durante toda la reproducción.
        if (n.category == Notification.CATEGORY_TRANSPORT ||
            extras.containsKey(Notification.EXTRA_MEDIA_SESSION) ||
            (pkg == "com.whatsapp" &&
                (n.flags and Notification.FLAG_ONGOING_EVENT) != 0)) return

        val title = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_TITLE))
        val titleBig = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_TITLE_BIG))
        val text = TextCleaner.speakableContent(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
        )
        val conversation = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))

        // Recuperamos también EXTRA_TEXT_LINES para notificaciones de
        // MessagingStyle y algunos formatos de WhatsApp que no ponen el
        // contenido principal en EXTRA_TEXT.
        val textLines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.map { TextCleaner.speakableContent(it) }
            ?.filter { it.isNotBlank() }
            .orEmpty()
        // Si Android entrega mensajes estructurados (MessagingStyle), usamos
        // únicamente el mensaje más reciente, no el primer texto de la lista
        // de mensajes pendientes. Así una actualización del grupo no vuelve a
        // leer un mensaje antiguo cuando acaba de llegar otro.
        val structuredMessages = if (Build.VERSION.SDK_INT >= 24) {
            try {
                val bundles = extras.getParcelableArray(Notification.EXTRA_MESSAGES)
                    ?.mapNotNull { it as? Bundle }
                    ?.toTypedArray()
                Notification.MessagingStyle.Message.getMessagesFromBundleArray(bundles)
            } catch (_: Exception) { emptyList() }
        } else emptyList()
        // A WhatsApp group summary can contain the newest message even when
        // that message is a voice note (whose MessagingStyle text may be null).
        // Keep the newest structured item so the summary can be processed once;
        // the per-conversation timestamp watermark below prevents replaying old
        // messages when Android posts both summary and child notifications.
        // En algunos grupos, dos mensajes pueden compartir la misma marca temporal
        // o la notificación más reciente puede ser una nota de voz sin texto.
        // Si las marcas empatan, prevalece el último elemento del arreglo de Android.
        val latestStructuredMessage = structuredMessages.withIndex()
            .maxWithOrNull(compareBy<IndexedValue<Notification.MessagingStyle.Message>> { it.value.timestamp }
                .thenBy { it.index })?.value
        val structuredSender = normalizeWhatsAppSender(
            pkg, TextCleaner.cleanName(latestStructuredMessage?.sender), conversation
        )
        val structuredContent = latestStructuredMessage?.text?.toString()
            ?.let { TextCleaner.speakableContent(it) }.orEmpty()
        val structuredMimeType = latestStructuredMessage?.dataMimeType.orEmpty()
        val structuredIsGroupConversation = isGroupConversation(
            extras,
            structuredSender.ifBlank { title },
            conversation
        )
        val structuredGroupVoiceNote = pkg == "com.whatsapp" &&
            structuredIsGroupConversation && structuredMimeType.startsWith("audio/", ignoreCase = true)
        // CORRECCIÓN 1.4.1: WhatsApp puede actualizar el resumen del grupo
        // con un contador ("2 mensajes") y dejar el mensaje nuevo en
        // EXTRA_TEXT_LINES. También puede conservar EXTRA_MESSAGES con contenido
        // antiguo. Para grupos, priorizamos la última línea visible que realmente
        // contiene un mensaje y no un contador; así cada actualización se procesa
        // aunque el usuario no abra la conversación.
        val isPotentialWhatsAppGroup = pkg == "com.whatsapp" &&
            (isGroupSummaryNotification || isGroupConversation(extras, title, conversation))
        val visibleGroupLine = if (isPotentialWhatsAppGroup) {
            textLines.asReversed().firstOrNull { line ->
                line.isNotBlank() &&
                    !isMessageCountSummary(line, "") &&
                    !isGroupNameOnly(line, conversation) &&
                    !isGroupNameOnly(line, title) &&
                    !isGroupNameOnly(line, titleBig)
            }.orEmpty()
        } else ""

        val visibleSummaryText = when {
            !isPotentialWhatsAppGroup -> ""
            text.isNotBlank() &&
                !isMessageCountSummary(text, "") &&
                !isGroupNameOnly(text, conversation) &&
                !isGroupNameOnly(text, title) &&
                !isGroupNameOnly(text, titleBig) -> text
            visibleGroupLine.isNotBlank() -> visibleGroupLine
            else -> ""
        }
        val effectiveText = when {
            visibleSummaryText.isNotBlank() -> visibleSummaryText
            structuredContent.isNotBlank() -> structuredContent
            structuredGroupVoiceNote -> "mensaje de voz"
            text.isNotBlank() && !isMessageCountSummary(text, "") -> text
            textLines.lastOrNull { !isMessageCountSummary(it, "") }.orEmpty().isNotBlank() ->
                textLines.lastOrNull { !isMessageCountSummary(it, "") }.orEmpty()
            else -> text
        }

        // Detectar únicamente eliminaciones explícitas presentes en el texto
        // actual de la notificación. No inferir que era voz por metadatos antiguos.
        if (pkg == "com.whatsapp") {
            val deletionSpeech = buildDeletedMessageAnnouncement(
                title = title,
                titleBig = titleBig,
                conversation = conversation,
                text = listOf(text, effectiveText).filter { it.isNotBlank() }.distinct().joinToString(" "),
                extras = extras
            )
            if (deletionSpeech != null) {
                val deletionKey = "$pkg|deleted|$title|$conversation|$effectiveText"
                val deletionNow = System.currentTimeMillis()
                val deletionOld = recent[deletionKey]
                if (deletionOld == null || deletionNow - deletionOld >= 5000L) {
                    recent[deletionKey] = deletionNow
                    recent.entries.removeIf { deletionNow - it.value > 600000L }
                    TtsEngine.speak(context, deletionSpeech)
                }
                return
            }
        }


        // No anunciar actividad saliente de WhatsApp mientras el usuario envía
        // archivos, APK, documentos, fotos, vídeos o audios. Estas notificaciones
        // de progreso no son mensajes recibidos; a veces Android las presenta
        // como “WhatsApp: Enviando dos archivos a Jenny Ortiz”, lo que provocaba
        // que Háblame leyera en voz alta el estado de la carga.
        if (pkg == "com.whatsapp" && isOutgoingWhatsAppMediaTransfer(
                title = title,
                titleBig = titleBig,
                conversation = conversation,
                text = text,
                effectiveText = effectiveText,
                textLines = textLines,
                structuredSender = structuredSender
            )) return

        // Las notificaciones MessagingStyle contienen a veces todo el historial
        // de mensajes sin leer. La clave por marca de tiempo permite anunciar
        // una sola vez el mensaje nuevo, pero sí permite repetir un texto igual
        // cuando realmente llega como otro mensaje con otra marca de tiempo.

        // A summary without MessagingStyle messages may still carry the newest
        // group message in EXTRA_TEXT / EXTRA_BIG_TEXT / EXTRA_TEXT_LINES. Do not
        // discard it blindly: WhatsApp/Android sometimes updates only the summary
        // while a group remains unread. Pure count-only summaries are filtered below.
        val summaryHasUsableFallback = effectiveText.isNotBlank() &&
            !isMessageCountSummary(effectiveText, "")
        if (isGroupSummaryNotification && latestStructuredMessage == null && !summaryHasUsableFallback) return

        // Una nota de voz de WhatsApp puede traer en la notificación metadatos
        // como el icono/micrófono y la duración (por ejemplo, 0:03), además
        // de la hora del mensaje. Esos datos no son contenido que deba leer
        // Háblame. Si la notificación identifica una nota de voz, conservamos
        // únicamente la etiqueta "mensaje de voz".
        val isWhatsAppVoiceNote = pkg == "com.whatsapp" &&
            Regex("\\bmensaje\\s+de\\s+voz\\b", RegexOption.IGNORE_CASE).containsMatchIn(effectiveText)
        var notificationContent = if (isWhatsAppVoiceNote) "mensaje de voz" else effectiveText

        // Las llamadas de WhatsApp se anuncian como llamadas, no como mensajes.
        // Una actualización de la misma notificación puede convertirse en
        // “llamada perdida” cuando el usuario no contesta.
        if (pkg == "com.whatsapp" && isWhatsAppCallNotification(n, title, conversation, effectiveText)) {
            announceWhatsAppCall(context, extras, title, conversation, effectiveText)
            return
        }

        val titleIsSummary = isMessageCountSummary(title, "")
        // Si el título es solo un resumen del tipo «3 mensajes» y Android no
        // proporciona el mensaje individual estructurado, no adivinamos usando
        // texto antiguo del grupo: ignoramos ese resumen.
        if (titleIsSummary && structuredSender.isBlank() && visibleSummaryText.isBlank()) return

        // En WhatsApp, el título puede ser el nombre del grupo y el remitente
        // venir dentro del texto visible (por ejemplo: "Jener Bitel: Hola").
        // Nunca usamos el nombre del grupo como remitente cuando ambos títulos
        // identifican la conversación. Primero intentamos el remitente de
        // MessagingStyle; después, el prefijo explícito del mensaje visible.
        val preliminaryGroup = structuredIsGroupConversation ||
            isGroupConversation(extras, title, conversation) ||
            (isGroupSummaryNotification && conversation.isNotBlank() && title.equals(conversation, ignoreCase = true))
        val fallbackGroupName = conversation.ifBlank {
            titleBig.takeIf { it.isNotBlank() && !it.equals(title, ignoreCase = true) }.orEmpty()
        }
        val titleAsSender = normalizeWhatsAppSender(pkg, title, conversation)
        val visibleSender = if (pkg == "com.whatsapp" &&
            (preliminaryGroup || titleAsSender.isBlank()) &&
            (structuredSender.isBlank() || visibleSummaryText.isNotBlank())
        ) {
            extractSenderFromMessageText(
                effectiveText,
                fallbackGroupName.ifBlank { conversation.ifBlank { title } },
                appName = "WhatsApp"
            )
        } else ""
        val initialSenderTitle = normalizeWhatsAppSender(pkg, when {
            visibleSummaryText.isNotBlank() && visibleSender.isNotBlank() -> visibleSender
            structuredSender.isNotBlank() -> structuredSender
            visibleSender.isNotBlank() -> visibleSender
            preliminaryGroup && title.equals(fallbackGroupName, ignoreCase = true) -> ""
            isGroupSummaryNotification && conversation.isNotBlank() && title.equals(conversation, ignoreCase = true) -> ""
            else -> title
        }, conversation)
        // WhatsApp can put both the group name and sender in EXTRA_TITLE, or
        // expose the group name as the title while the sender is in MessagingStyle.
        // Never let the group name become the spoken sender for group messages.
        val isGroupConversation = preliminaryGroup ||
            isGroupConversation(extras, initialSenderTitle, conversation)
        val groupCandidates = listOf(conversation, titleBig, title)
            .map { TextCleaner.cleanName(it) }
            .filter { it.isNotBlank() && !isMessageCountSummary(it, "") }
        val senderTitle = if (pkg == "com.whatsapp" && isGroupConversation) {
            listOf(structuredSender, visibleSender, initialSenderTitle, title, titleBig)
                .asSequence()
                .map { normalizeWhatsAppSender(pkg, it, conversation) }
                .map { candidate ->
                    var cleaned = candidate
                    for (groupCandidate in groupCandidates) {
                        if (groupCandidate.isNotBlank()) {
                            val escapedGroup = Regex.escape(groupCandidate)
                            cleaned = cleaned
                                .replace(
                                    Regex("^$escapedGroup\\s*[,;:]?\\s*", RegexOption.IGNORE_CASE),
                                    ""
                                )
                                .replace(
                                    Regex("(?:\\s*[,;:]\\s*@?\\s*|\\s*@\\s*)$escapedGroup$", RegexOption.IGNORE_CASE),
                                    ""
                                ).trim()
                        }
                    }
                    TextCleaner.cleanName(cleaned)
                }
                .firstOrNull { candidate ->
                    candidate.isNotBlank() &&
                        !candidate.equals("WhatsApp", ignoreCase = true) &&
                        groupCandidates.none { it.equals(candidate, ignoreCase = true) }
                }.orEmpty()
        } else initialSenderTitle
        if (pkg == "com.whatsapp") {
            notificationContent = stripWhatsAppSenderPrefix(
                notificationContent,
                listOf(visibleSender, senderTitle, structuredSender, title),
                conversation
            )
        }

        // El nombre del grupo nunca debe convertirse en contenido ni leerse
        // como si fuera un mensaje. Los contadores de mensajes son resúmenes.
        if (isMessageCountSummary(conversation, "") ||
            isMessageCountSummary(effectiveText, "") ||
            (isMessageCountSummary(titleBig, "") && structuredSender.isBlank() && visibleSummaryText.isBlank())) return

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.').ifBlank { "Aplicación" }
        }

        if (pkg !in detailedApps) {
            val genericKey = "$pkg|$appName"
            val nowGeneric = System.currentTimeMillis()
            val oldGeneric = recent[genericKey]
            if (oldGeneric != null && nowGeneric - oldGeneric < 5000L) return
            recent[genericKey] = nowGeneric
            recent.entries.removeIf { nowGeneric - it.value > 600000L }
            TtsEngine.speak(context, appName)
            return
        }

        // WhatsApp y otras apps de mensajería pueden publicar una notificación
        // temporal de actividad propia mientras el usuario envía un video, foto,
        // audio, documento, etc. No es un mensaje recibido y no debe anunciarse.
        val selfActivityPackages = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.instagram.android",
            "com.zhiliaoapp.musically",
            "com.google.android.apps.messaging"
        )
        if (pkg in selfActivityPackages &&
            title.equals(appName, ignoreCase = true) &&
            conversation.isBlank() &&
            notificationContent.isBlank()
        ) return

        val now = System.currentTimeMillis()
        val structuredTimestamp = latestStructuredMessage?.timestamp ?: 0L
        // La marca temporal no siempre basta para distinguir mensajes de grupo:
        // WhatsApp puede reutilizarla en dos mensajes consecutivos. La huella
        // también forma parte de la clave de deduplicación, para no descartar
        // un mensaje nuevo solo porque coincida hora y remitente.
        // Include the currently visible notification text as a fallback signal.
        // WhatsApp may update the group summary while retaining stale MessagingStyle
        // entries; the visible newest text must still distinguish that update.
        val isWhatsAppGroupNotification = pkg == "com.whatsapp" &&
            (isGroupConversation || isGroupSummaryNotification)
        // Para grupos, la huella se basa en el mensaje que realmente vamos a leer,
        // no en EXTRA_MESSAGES, que WhatsApp a veces deja obsoleto al actualizar
        // el resumen. Así un mensaje nuevo con la misma marca temporal no se pierde.
        val structuredFingerprint = if (isWhatsAppGroupNotification) {
            listOf(
                senderTitle,
                notificationContent,
                structuredMimeType,
                latestStructuredMessage?.dataUri?.toString().orEmpty()
            ).joinToString("|").hashCode().toString()
        } else {
            listOf(
                structuredSender,
                structuredContent,
                notificationContent,
                structuredMimeType,
                latestStructuredMessage?.dataUri?.toString().orEmpty()
            ).joinToString("|").hashCode().toString()
        }
        val key = if (structuredTimestamp > 0L && isWhatsAppGroupNotification) {
            // Deduplicar representaciones del mismo mensaje, pero mantener la huella
            // del contenido visible para no silenciar mensajes posteriores del grupo.
            "$pkg|group-message|${conversation.ifBlank { titleBig.ifBlank { title } }}|$structuredTimestamp|$structuredFingerprint"
        } else if (structuredTimestamp > 0L) {
            // Mantener el comportamiento previo para mensajes individuales y otras apps.
            "$pkg|message|$conversation|$structuredTimestamp|$senderTitle"
        } else if (pkg == "com.whatsapp" && isGroupConversation) {
            // Same group message can arrive first as a summary and then as a child
            // notification. Use its visible content, not the notification title,
            // so those two representations share a deduplication key.
            "$pkg|group-fallback|$conversation|$senderTitle|$notificationContent|$titleBig"
        } else {
            "$pkg|$senderTitle|$conversation|$notificationContent|$titleBig"
        }
        // WhatsApp puede reconstruir la notificación con un mensaje anterior
        // cuando se edita/elimina el último. Conservamos la marca temporal más
        // alta ya anunciada por conversación para no volver a leer ese historial.
        val watermarkPrefs = context.getSharedPreferences("whatsapp_message_watermarks", Context.MODE_PRIVATE)
        // Some WhatsApp group notifications omit EXTRA_CONVERSATION_TITLE.
        // Use a stable group-title fallback rather than sharing one watermark
        // across unrelated conversations with an empty conversation field.
        val watermarkConversation = conversation.ifBlank {
            if (isGroupConversation) titleBig.ifBlank { title } else title
        }
        val watermarkKey = "last_$pkg|$watermarkConversation".hashCode().toString()
        val fingerprintKey = "fingerprint_$watermarkKey"
        if (pkg == "com.whatsapp" && structuredTimestamp > 0L && !isWhatsAppGroupNotification) {
            val lastAnnouncedTimestamp = watermarkPrefs.getLong(watermarkKey, 0L)
            if (structuredTimestamp <= lastAnnouncedTimestamp) return
        }

        val old = recent[key]
        if (structuredTimestamp > 0L) {
            if (old != null) return
        } else if (old != null && now - old < 5000L) {
            return
        }
        recent[key] = now
        if (pkg == "com.whatsapp" && structuredTimestamp > 0L && !isWhatsAppGroupNotification) {
            watermarkPrefs.edit()
                .putLong(watermarkKey, structuredTimestamp)
                .putString(fingerprintKey, structuredFingerprint)
                .apply()
        }
        recent.entries.removeIf { now - it.value > 600000L }

        val readTitle = Prefs.getBool(context, "title_$pkg", true)
        // WhatsApp content reading must default OFF, matching the settings UI.
        // Preserve the existing defaults for every other supported application.
        val readContent = Prefs.getBool(context, "content_$pkg", pkg != "com.whatsapp")

        // Si WhatsApp muestra el número en lugar del nombre, no se lee toda la
        // cadena de dígitos. Si ese número tampoco existe en Contactos, se usa
        // la frase natural “número desconocido”. Si sí existe, se recupera el
        // nombre guardado en el teléfono.
        val resolvedTitle = if (pkg == "com.whatsapp" && looksLikePhoneNumber(senderTitle)) {
            lookupContact(context, senderTitle)?.let { TextCleaner.cleanName(it) } ?: "número desconocido"
        } else {
            senderTitle
        }
        val titlePart = if (readTitle && resolvedTitle.isNotBlank()) resolvedTitle else ""
        val contentPart = if (readContent && notificationContent.isNotBlank()) notificationContent else ""
        val announcementGroup = if (isGroupConversation) {
            listOf(conversation, titleBig, title).firstOrNull { raw ->
                val candidate = TextCleaner.cleanName(raw)
                val normalizedCandidate = normalizeWhatsAppSender(pkg, candidate, conversation)
                candidate.isNotBlank() &&
                    !candidate.equals(appName, ignoreCase = true) &&
                    !candidate.equals("WhatsApp", ignoreCase = true) &&
                    !candidate.equals(titlePart, ignoreCase = true) &&
                    !normalizedCandidate.equals(titlePart, ignoreCase = true) &&
                    !isMessageCountSummary(candidate, "") &&
                    !isGroupNameOnly(candidate, titlePart)
            }.orEmpty()
        } else ""

        // Individual: "WhatsApp de Jennifer. Contenido".
        // Group: "WhatsApp de Jennifer a Familia. Contenido".
        // Sender, group and body are resolved independently from Android notification fields.
        val intro = when {
            titlePart.isNotBlank() && announcementGroup.isNotBlank() ->
                "$appName de $titlePart a ${TextCleaner.cleanName(announcementGroup)}"
            titlePart.isNotBlank() ->
                "$appName de $titlePart"
            announcementGroup.isNotBlank() ->
                "$appName a ${TextCleaner.cleanName(announcementGroup)}"
            else -> appName
        }
        if (isWhatsAppVoiceNote && readContent) {
            TtsEngine.speakWithPause(context, intro, "Mensaje de voz.", 100L)
        } else if (contentPart.isNotBlank() && titlePart.isNotBlank()) {
            TtsEngine.speakWithPause(context, intro, contentPart, 100L)
        } else {
            val speech = if (contentPart.isNotBlank()) "$intro. $contentPart" else intro
            if (speech.isNotBlank()) TtsEngine.speak(context, speech)
        }
    }

    private fun isOutgoingWhatsAppMediaTransfer(
        title: String,
        titleBig: String,
        conversation: String,
        text: String,
        effectiveText: String,
        textLines: List<String>,
        structuredSender: String
    ): Boolean {
        // Una notificación de mensaje real suele incluir el remitente estructurado
        // o el nombre de la conversación. Limitamos este filtro a estados genéricos
        // de la propia app para no silenciar mensajes recibidos que mencionen archivos.
        if (structuredSender.isNotBlank()) return false
        if (conversation.isNotBlank()) return false
        if (title.isNotBlank() && !title.equals("WhatsApp", ignoreCase = true)) return false

        val combined = (listOf(title, titleBig, text, effectiveText) + textLines)
            .joinToString(" ")
            .lowercase()
            .replace('á', 'a').replace('é', 'e').replace('í', 'i')
            .replace('ó', 'o').replace('ú', 'u').replace('ü', 'u')

        val outgoingVerb = Regex(
            "\\b(enviando|enviar|subiendo|cargando|compartiendo|uploading|sending|sharing)\\b",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(combined)
        if (!outgoingVerb) return false

        val mediaOrFile = Regex(
            "\\b(archivo|archivos|documento|documentos|apk|foto|fotos|imagen|imagenes|video|videos|" +
                "audio|audios|nota de voz|notas de voz|adjunto|adjuntos|file|files|document|documents|" +
                "photo|photos|image|images|video|videos|audio|voice note|attachment|attachments)\\b",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(combined)

        return mediaOrFile
    }

    private fun buildDeletedMessageAnnouncement(
        title: String,
        titleBig: String,
        conversation: String,
        text: String,
        extras: Bundle
    ): String? {
        // WhatsApp puede exponer la frase de eliminación en distintos campos,
        // incluidos EXTRA_TEXT_LINES y EXTRA_TITLE_BIG. Revisamos solo el texto
        // presente en esta actualización, no metadatos de audio anteriores.
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.map { it.toString() }
            .orEmpty()
        val combined = listOf(
            title,
            conversation,
            text,
            extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString().orEmpty(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        ).plus(lines).joinToString(" ").lowercase()

        val explicitDeletion = listOf(
            "eliminó este mensaje", "elimino este mensaje",
            "eliminaste este mensaje", "eliminaste el mensaje",
            "se eliminó este mensaje", "se elimino este mensaje",
            "se eliminó el mensaje", "se elimino el mensaje",
            "se eliminó un mensaje", "se elimino un mensaje",
            "mensaje eliminado", "mensaje eliminado para todos",
            "el mensaje fue eliminado", "el mensaje ha sido eliminado",
            "este mensaje fue eliminado", "este mensaje ha sido eliminado",
            "eliminó un mensaje", "elimino un mensaje",
            "eliminó varios mensajes", "elimino varios mensajes",
            "eliminó los mensajes", "elimino los mensajes",
            "this message was deleted", "you deleted this message",
            "you deleted a message", "message deleted",
            "deleted a message", "deleted messages"
        ).any { combined.contains(it) }
        if (!explicitDeletion) return null

        // No intentamos adivinar si el mensaje eliminado era de voz: WhatsApp
        // puede conservar el texto/icono de audio en campos secundarios. La
        // locución es general y distingue uno o varios mensajes.
        val isMultiple = Regex(
            "\\b(varios|varias|múltiples|multiples|multiple|multiple[s]?)\\b",
            RegexOption.IGNORE_CASE
        ).containsMatchIn(combined) ||
            Regex("\\b(mensajes|messages)\\b", RegexOption.IGNORE_CASE).containsMatchIn(combined) &&
            (combined.contains("eliminó los mensajes") || combined.contains("elimino los mensajes") ||
                combined.contains("deleted messages"))

        val deletionLine = (lines + listOf(text,
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()))
            .firstOrNull { line ->
                val lower = line.lowercase()
                listOf("eliminó", "elimino", "mensaje eliminado", "this message was deleted", "message deleted", "deleted a message")
                    .any { lower.contains(it) }
            }.orEmpty()
        val senderFromLine = deletionLine.substringBefore(":", "").trim()
            .takeIf { deletionLine.contains(":") && it.isNotBlank() }
        val candidateSender = senderFromLine
            ?: title.takeIf {
                it.isNotBlank() && !it.equals("WhatsApp", ignoreCase = true) &&
                    !it.equals(conversation, ignoreCase = true)
            }
        val description = if (isMultiple) {
            "se eliminaron varios mensajes de WhatsApp"
        } else {
            "se eliminó un mensaje de WhatsApp"
        }
        val groupName = conversation.takeIf {
            it.isNotBlank() && !it.equals("WhatsApp", ignoreCase = true) &&
                !it.equals(candidateSender, ignoreCase = true)
        } ?: titleBig.takeIf {
            it.isNotBlank() && !it.equals("WhatsApp", ignoreCase = true) &&
                !it.equals(candidateSender, ignoreCase = true)
        }
        val announcement = if (candidateSender != null) "$candidateSender eliminó ${if (isMultiple) "varios mensajes" else "un mensaje"} de WhatsApp"
            else description
        return if (groupName != null) {
            "$announcement, en ${TextCleaner.cleanName(groupName)}"
        } else {
            announcement
        }
    }

    private fun isWhatsAppCallNotification(
        notification: Notification,
        title: String,
        conversation: String,
        text: String
    ): Boolean {
        if (notification.category == Notification.CATEGORY_CALL) return true
        val combined = "$title $conversation $text".lowercase()
        return combined.contains("llamada") ||
            combined.contains("llamando") ||
            combined.contains("llamada entrante") ||
            combined.contains("llamada perdida") ||
            combined.contains("llamada de voz") ||
            combined.contains("llamada de video") ||
            combined.contains("incoming call") ||
            combined.contains("missed call") ||
            combined.contains("voice call") ||
            combined.contains("video call")
    }

    private fun announceWhatsAppCall(
        context: Context,
        extras: Bundle,
        title: String,
        conversation: String,
        text: String
    ) {
        if (!canSpeak()) return

        val combined = "$title $conversation $text"
        val lower = combined.lowercase()
        val missed = lower.contains("perdida") ||
            lower.contains("missed") ||
            lower.contains("rechazada") ||
            lower.contains("declined")

        var sender = ""
        val explicit = Regex(
            "(?:llamada\\s+(?:perdida|entrante)?\\s*(?:de|from)|(?:de|from))\\s+(.+)",
            RegexOption.IGNORE_CASE
        ).find(combined)
        if (explicit != null) sender = explicit.groupValues[1].trim()

        val generic = setOf(
            "whatsapp", "llamada", "llamada entrante", "llamada perdida",
            "incoming call", "missed call", "voice call", "video call"
        )

        if (sender.isBlank()) {
            val candidates = listOf(title, conversation, text)
                .map { it.trim() }
                .filter { it.isNotBlank() }
            sender = candidates.firstOrNull {
                it.lowercase() !in generic &&
                    !it.lowercase().contains("llamada") &&
                    !it.lowercase().contains("call") &&
                    !it.matches(Regex("^\\d+$"))
            } ?: ""
        }

        sender = TextCleaner.cleanName(sender)
        if (sender.isBlank() || sender.equals("WhatsApp", ignoreCase = true)) {
            sender = "número desconocido"
        } else if (looksLikePhoneNumber(sender)) {
            sender = lookupContact(context, sender)?.let { TextCleaner.cleanName(it) }
                ?: "número desconocido"
        }

        val speech = if (missed) {
            "Llamada perdida de WhatsApp de $sender"
        } else {
            "Llamada de WhatsApp de $sender"
        }

        val key = "whatsapp_call|$missed|$sender"
        val now = System.currentTimeMillis()
        val old = recent[key]
        if (old != null && now - old < 5000L) return
        recent[key] = now
        recent.entries.removeIf { now - it.value > 15000L }

        // Las llamadas de WhatsApp entrantes no se anuncian: Android/WhatsApp
        // no las expone de forma suficientemente fiable para garantizar una
        // lectura inmediata. Se conserva únicamente la llamada perdida, una
        // sola vez y sin usar las repeticiones de las llamadas normales.
        if (!missed) return
        TtsEngine.speakRepeated(context, speech, 1)
    }

    private fun extractSenderFromSummary(title: String, conversation: String): String {
        var candidate = title
        if (conversation.isNotBlank() && candidate.startsWith(conversation, ignoreCase = true)) {
            candidate = candidate.substring(conversation.length)
        }
        candidate = candidate.replace(
            Regex("(?:^|[,;:–—-])?\\s*(?:\\d+|uno|una|un|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|varios|varias|múltiples|multiples)\\s+(?:mensajes|messages)\\b", RegexOption.IGNORE_CASE),
            " "
        )
        candidate = candidate.replace(Regex("\\s*[,;:–—-]\\s*"), " ")
            .replace(Regex("\\s+"), " ").trim()
        return TextCleaner.cleanName(candidate).takeUnless {
            it.isBlank() || isMessageCountSummary(it, "") || it.equals("WhatsApp", ignoreCase = true)
        }.orEmpty()
    }

    private fun normalizeWhatsAppSender(
        packageName: String,
        rawSender: String,
        groupName: String = ""
    ): String {
        if (packageName != "com.whatsapp") return TextCleaner.cleanName(rawSender).trim()

        var sender = TextCleaner.cleanName(rawSender).trim()
        // Android/WhatsApp may prepend the app name to the contact in title fields.
        sender = sender.replace(
            Regex("^WhatsApp(?:\\s*[,;:：–—-]\\s*|\\s+de\\s+|\\s+)", RegexOption.IGNORE_CASE),
            ""
        ).trim()
        // Some notification layouts combine sender and group in one title, e.g.
        // "WhatsApp, Jennifer, @ Familia". Keep only the sender here.
        if (groupName.isNotBlank()) {
            sender = sender.replace(
                Regex("(?:\\s*[,;:]\\s*@?\\s*|\\s*@\\s*)${Regex.escape(TextCleaner.cleanName(groupName))}$", RegexOption.IGNORE_CASE),
                ""
            ).trim()
        }
        if (sender.equals("WhatsApp", ignoreCase = true)) return ""
        return sender
    }

    private fun stripWhatsAppSenderPrefix(
        content: String,
        senderCandidates: List<String>,
        groupName: String
    ): String {
        var result = content.trim()
        if (result.isBlank()) return result
        for (rawCandidate in senderCandidates) {
            val candidate = normalizeWhatsAppSender("com.whatsapp", rawCandidate, groupName)
            if (candidate.isBlank()) continue
            val escaped = Regex.escape(candidate)
            val optionalGroupSuffix = if (groupName.isBlank()) "" else
                "(?:\\s*[,;:]\\s*@?\\s*${Regex.escape(TextCleaner.cleanName(groupName))}|\\s*@\\s*${Regex.escape(TextCleaner.cleanName(groupName))})?"
            val patterns = listOf(
                Regex("^\\s*WhatsApp\\s*[,;:：–—-]\\s*$escaped$optionalGroupSuffix\\s*:\\s*", RegexOption.IGNORE_CASE),
                Regex("^\\s*$escaped$optionalGroupSuffix\\s*:\\s*", RegexOption.IGNORE_CASE)
            )
            val pattern = patterns.firstOrNull { it.containsMatchIn(result) }
            if (pattern != null) {
                result = result.replaceFirst(pattern, "").trim()
                break
            }
        }
        return result
    }

    private fun isGroupNameOnly(value: String, groupName: String): Boolean {
        val text = TextCleaner.cleanName(value)
            .replace(Regex("^@\\s*"), "")
            .trim()
        val group = TextCleaner.cleanName(groupName)
            .replace(Regex("^@\\s*"), "")
            .trim()
        return text.isNotBlank() && group.isNotBlank() && text.equals(group, ignoreCase = true)
    }

    private fun extractSenderFromMessageText(message: String, groupName: String, appName: String): String {
        val value = message.trim()
        if (value.isBlank()) return ""
        // Only trust an explicit short prefix before a colon; do not guess from
        // arbitrary message text or from the group title itself.
        val match = Regex("^([^\\n:]{1,80}):\\s*.+$", RegexOption.DOT_MATCHES_ALL).find(value) ?: return ""
        val candidate = normalizeWhatsAppSender("com.whatsapp", match.groupValues[1], groupName)
        if (candidate.isBlank() || candidate.equals(groupName, ignoreCase = true) ||
            candidate.equals(appName, ignoreCase = true) || isMessageCountSummary(candidate, "") ||
            candidate.equals("WhatsApp", ignoreCase = true)) return ""
        return candidate
    }

    private fun isMessageCountSummary(title: String, text: String): Boolean {
        val combined = "${title.trim()} ${text.trim()}"
        val count = "(?:\\d+|uno|una|un|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|varios|varias|múltiples|multiples)"
        return Regex("\\b$count\\s+(?:mensajes|messages)\\b", RegexOption.IGNORE_CASE)
            .containsMatchIn(combined)
    }

    private fun looksLikePhoneNumber(value: String): Boolean {
        val normalized = value.replace(Regex("[^0-9+]"), "")
        val digits = normalized.count { it.isDigit() }
        return digits >= 7 && normalized.length <= 20 && normalized.count { it == '+' } <= 1
    }

    private fun lookupContact(context: Context, number: String): String? {
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) return null

        return try {
            val uri = ContactsContract.PhoneLookup.CONTENT_FILTER_URI.buildUpon()
                .appendPath(android.net.Uri.encode(number)).build()
            context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isGroupConversation(
        extras: Bundle,
        title: String,
        conversation: String
    ): Boolean {
        // Android exposes this flag for MessagingStyle notifications when the
        // originating app marks the conversation as a group.
        if (extras.containsKey("android.isGroupConversation") &&
            extras.getBoolean("android.isGroupConversation", false)
        ) return true

        // WhatsApp, Telegram and Messenger frequently provide the group name
        // through EXTRA_CONVERSATION_TITLE without setting the flag. In that
        // case a different conversation title is the reliable group signal.
        if (conversation.isBlank()) return false
        if (conversation.equals(title, ignoreCase = true)) return false
        return true
    }

    private fun canSpeak(): Boolean {
        if (!Prefs.getBool(this, "normal_only", true)) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
