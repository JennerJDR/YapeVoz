package com.hablame.app

import android.Manifest
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.telephony.PhoneNumberUtils
import android.net.Uri
import androidx.core.content.ContextCompat

class CallStateReceiver : BroadcastReceiver() {
    companion object {
        @Volatile private var ringingAnnouncementActive = false
        @Volatile private var announcementScheduled = false
        @Volatile private var latestPhoneState: String = TelephonyManager.EXTRA_STATE_IDLE
        @Volatile private var latestIncomingNumber: String? = null
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) return
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: run {
            WhatsAppDiagnostic.record(context, "CALL: broadcast PHONE_STATE sin EXTRA_STATE")
            return
        }
        latestPhoneState = state
        val hasNumberExtra = !intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER).isNullOrBlank()
        WhatsAppDiagnostic.record(context, "CALL: estado=$state; númeroEnBroadcast=$hasNumberExtra; READ_PHONE_STATE=${granted(context, Manifest.permission.READ_PHONE_STATE)}; READ_PHONE_NUMBERS=${granted(context, Manifest.permission.READ_PHONE_NUMBERS)}; READ_CALL_LOG=${granted(context, Manifest.permission.READ_CALL_LOG)}; READ_CONTACTS=${granted(context, Manifest.permission.READ_CONTACTS)}")
        // Answering, rejecting or ending the call must immediately cancel every
        // pending repetition so no alert continues over the conversation.
        if (state == TelephonyManager.EXTRA_STATE_OFFHOOK || state == TelephonyManager.EXTRA_STATE_IDLE) {
            WhatsAppDiagnostic.record(context, "CALL: limpiar anuncio pendiente por estado=$state")
            latestIncomingNumber = null
            announcementScheduled = false
            if (ringingAnnouncementActive) {
                ringingAnnouncementActive = false
                TtsEngine.stop()
            }
            return
        }
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return
        if (!Prefs.getBool(context, "service_enabled", true)) {
            WhatsAppDiagnostic.record(context, "CALL: ignorada; servicio desactivado en preferencias")
            return
        }

        // Android can emit PHONE_STATE twice for the same ring: one broadcast may
        // have an empty number and the other the actual caller ID. Collect both
        // briefly before speaking so the empty event does not win the race.
        intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            ?.trim()?.takeIf { it.isNotBlank() }?.let {
                latestIncomingNumber = it
                WhatsAppDiagnostic.record(context, "CALL: número de llamada recibido en broadcast posterior; longitudNúmero=${it.count { ch -> ch.isDigit() }}")
            }
        if (ringingAnnouncementActive || announcementScheduled) {
            WhatsAppDiagnostic.record(context, "CALL: evento RINGING duplicado; anuncioActivo=$ringingAnnouncementActive; anuncioProgramado=$announcementScheduled")
            return
        }
        announcementScheduled = true
        WhatsAppDiagnostic.record(context, "CALL: programado análisis de llamada; númeroRecibido=${!latestIncomingNumber.isNullOrBlank()}")

        val pending = goAsync()
        val app = context.applicationContext
        Thread {
            try {
                // Android puede enviar dos broadcasts RINGING: uno sin número y
                // otro con EXTRA_INCOMING_NUMBER. El orden no está garantizado.
                // Esperar brevemente y volver a comprobar el valor compartido evita
                // anunciar “número desconocido” antes de que llegue el número real.
                val deadline = android.os.SystemClock.elapsedRealtime() + 4000L
                while (latestPhoneState == TelephonyManager.EXTRA_STATE_RINGING &&
                    latestIncomingNumber.isNullOrBlank() &&
                    android.os.SystemClock.elapsedRealtime() < deadline) {
                    Thread.sleep(100L)
                }
                if (latestPhoneState != TelephonyManager.EXTRA_STATE_RINGING) {
                    WhatsAppDiagnostic.record(app, "CALL: cancelada tras espera; estado actual=$latestPhoneState")
                    return@Thread
                }
                if (!canSpeak(app)) {
                    val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    WhatsAppDiagnostic.record(app, "CALL: no se anuncia por modo de sonido/interrupciones; modoTimbre=${am.ringerMode}; filtroInterrupciones=${nm.currentInterruptionFilter}; soloModoNormal=${Prefs.getBool(app, "normal_only", true)}")
                    return@Thread
                }
                val number = latestIncomingNumber
                WhatsAppDiagnostic.record(app, "CALL: tras espera; númeroDisponible=${!number.isNullOrBlank()}; longitudNúmero=${number?.count { it.isDigit() } ?: 0}")
                val speech = buildSpeech(app, number)
                WhatsAppDiagnostic.record(app, "CALL: decisión de anuncio; textoGenerado=${speech.isNotBlank()}; modoDesconocido=${Prefs.getString(app, "unknown_mode", "number")}")
                if (speech.isNotBlank() && latestPhoneState == TelephonyManager.EXTRA_STATE_RINGING) {
                    ringingAnnouncementActive = true
                    val repetitions = Prefs.getInt(app, "call_repetitions", 2).coerceIn(1, 5)
                    WhatsAppDiagnostic.record(app, "CALL: inicia TTS; repeticiones=$repetitions")
                    val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val startingRingVolume = audio.getStreamVolume(AudioManager.STREAM_RING)
                    TtsEngine.speakRepeated(app, speech, repetitions)
                    Thread {
                        try {
                            while (latestPhoneState == TelephonyManager.EXTRA_STATE_RINGING && ringingAnnouncementActive) {
                                val currentVolume = audio.getStreamVolume(AudioManager.STREAM_RING)
                                if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL || currentVolume < startingRingVolume) {
                                    WhatsAppDiagnostic.record(app, "CALL: anuncio detenido porque se silenció/bajó el timbre; volumenInicial=$startingRingVolume; volumenActual=$currentVolume; modo=${audio.ringerMode}")
                                    ringingAnnouncementActive = false
                                    TtsEngine.stop()
                                    break
                                }
                                Thread.sleep(200L)
                            }
                        } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                    }.start()
                } else if (speech.isBlank()) {
                    WhatsAppDiagnostic.record(app, "CALL: no se genera voz; revisar modo de número desconocido y disponibilidad del identificador")
                }
            } catch (e: InterruptedException) {
                WhatsAppDiagnostic.record(app, "CALL: hilo interrumpido")
                Thread.currentThread().interrupt()
            } catch (e: Exception) {
                WhatsAppDiagnostic.record(app, "CALL: excepción en proceso: ${e.javaClass.simpleName}")
            } finally {
                announcementScheduled = false
                pending.finish()
            }
        }.start()
    }

    private fun granted(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun canSpeak(context: Context): Boolean {
        if (!Prefs.getBool(context, "normal_only", true)) return true
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
    }

    private fun buildSpeech(context: Context, number: String?): String {
        val contactsPermission = granted(context, Manifest.permission.READ_CONTACTS)
        val contactName = if (!number.isNullOrBlank() && contactsPermission) {
            lookupContact(context, number)
        } else null
        WhatsAppDiagnostic.record(context, "CALL: búsqueda de contacto; permisoContactos=$contactsPermission; númeroDisponible=${!number.isNullOrBlank()}; contactoEncontrado=${!contactName.isNullOrBlank()}")

        // Un número guardado siempre se identifica por el nombre del contacto.
        // El modo de número desconocido solo se aplica si no hubo coincidencia.
        if (!contactName.isNullOrBlank()) {
            return "Llamada entrante de ${TextCleaner.cleanName(contactName)}"
        }

        return when (Prefs.getString(context, "unknown_mode", "number")) {
            "unknown" -> "Llamada entrante de número desconocido"
            "none" -> ""
            else -> {
                // In "leer número" mode, only announce the number if Android supplied it.
                // Do not silently substitute "número desconocido": that phrase belongs
                // exclusively to the explicit unknown-caller preference above.
                val n = number?.filter { it.isDigit() }.orEmpty()
                if (n.isBlank()) "" else "Llamada entrante del ${speakDigitsIndividually(n)}"
            }
        }
    }

    // Convert each digit to its Spanish name so TTS never interprets the
    // complete phone number as a large quantity. Contact lookup still uses
    // the original number above, unchanged.
    private fun speakDigitsIndividually(number: String): String {
        val names = arrayOf("cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve")
        return number.map { digit -> names[digit.digitToInt()] }.joinToString(", ")
    }

    private fun lookupContact(context: Context, number: String): String? {
        return try {
            // Try the incoming number as-is and common national/international forms.
            // PhoneLookup expects the raw number appended to CONTENT_FILTER_URI; pre-encoding
            // it before appendPath can double-encode '+' and other characters on some devices.
            val candidates = linkedSetOf<String>()
            candidates += number.trim()
            val digits = number.filter { it.isDigit() }
            if (digits.isNotEmpty()) candidates += digits
            if (digits.startsWith("51") && digits.length == 11) {
                candidates += digits.drop(2)             // 51937275122 -> 937275122
                candidates += "+$digits"                // 51937275122 -> +51937275122
            } else if (digits.length == 9 && digits.startsWith("9")) {
                candidates += "51$digits"
                candidates += "+51$digits"
            }

            for (candidate in candidates) {
                // Android documenta PhoneLookup con Uri.encode(phoneNumber).
                // Es necesario codificar el segmento para que +51, espacios y
                // otros caracteres no alteren la consulta del proveedor de contactos.
                // appendPath codifica el segmento por sí mismo. No usar Uri.encode aquí:
                // hacerlo antes puede convertir % en %25 y romper la búsqueda del contacto.
                val uri = ContactsContract.PhoneLookup.CONTENT_FILTER_URI
                    .buildUpon()
                    .appendPath(candidate)
                    .build()
                val found = context.contentResolver.query(
                    uri,
                    arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                    null, null, null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                }
                if (!found.isNullOrBlank()) return found
            }

            // Fallback for devices/providers that don't match equivalent +51 formats in PhoneLookup.
            // Compare with Android's phone-number comparator, then compare normalized digit suffixes.
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val phoneIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cursor.moveToNext()) {
                    val savedNumber = cursor.getString(phoneIndex).orEmpty()
                    if (PhoneNumberUtils.compare(number, savedNumber)) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) return name
                    }
                    val incomingDigits = number.filter { it.isDigit() }.let {
                        if (it.startsWith("51") && it.length == 11) it.drop(2) else it
                    }
                    val savedDigits = savedNumber.filter { it.isDigit() }.let {
                        if (it.startsWith("51") && it.length == 11) it.drop(2) else it
                    }
                    // Require the complete 9-digit Peruvian mobile number; avoid matching short suffixes.
                    if (incomingDigits.length == 9 && savedDigits.length == 9 && incomingDigits == savedDigits) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) return name
                    }
                }
            }
            null
        } catch (e: Exception) {
            WhatsAppDiagnostic.record(context, "CALL: error buscando contacto: ${e.javaClass.simpleName}")
            null
        }
    }
}
