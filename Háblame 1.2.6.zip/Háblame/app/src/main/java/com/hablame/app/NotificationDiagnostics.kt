package com.hablame.app

import android.app.Notification
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.service.notification.StatusBarNotification
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Temporary privacy-conscious WhatsApp notification lifecycle log for diagnosis. */
object NotificationDiagnostics {
    private const val PREFS = "hablame_diagnostics"
    private const val ENABLED = "whatsapp_log_enabled"
    private const val MAX_LINES = 500
    private val lock = Any()

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, enabled).apply()
        if (enabled) log(context, "DIAGNOSTIC", "Registro activado manualmente")
    }

    fun posted(context: Context, sbn: StatusBarNotification) {
        if (sbn.packageName != "com.whatsapp" || !isEnabled(context)) return
        log(context, "POSTED", describe(sbn, null))
    }

    fun removed(context: Context, sbn: StatusBarNotification, reason: Int) {
        if (sbn.packageName != "com.whatsapp" || !isEnabled(context)) return
        log(context, "REMOVED", describe(sbn, reason))
    }

    private fun describe(sbn: StatusBarNotification, reason: Int?): String {
        val n = sbn.notification
        val e = n.extras ?: Bundle()
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val titleBig = e.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val summary = e.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)?.toString().orEmpty()
        val sub = e.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val lines = e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.map { it.toString() }.orEmpty()
        val all = (listOf(title, titleBig, text, big, summary, sub) + lines).joinToString(" ").lowercase(Locale.ROOT)
        val delete = listOf("eliminó", "elimino", "eliminado", "deleted", "delete").any { all.contains(it) }
        val edit = listOf("editó", "edito", "editado", "edited", "edit message").any { all.contains(it) }
        val messagesCount = try {
            if (Build.VERSION.SDK_INT >= 24) e.getParcelableArray(Notification.EXTRA_MESSAGES)?.size ?: 0 else 0
        } catch (_: Exception) { -1 }
        val reasonText = reason?.let { ",reason=$it" }.orEmpty()
        return "key=${sbn.key.hashCode().toString(16)},id=${sbn.id},tag=${sbn.tag?.hashCode()?.toString(16) ?: "-"}," +
            "groupKey=${sbn.groupKey?.hashCode()?.toString(16) ?: "-"},postTime=${sbn.postTime}," +
            "when=${n.`when`},flags=${n.flags},category=${n.category ?: "-"}," +
            "groupSummary=${(n.flags and Notification.FLAG_GROUP_SUMMARY) != 0},ongoing=${(n.flags and Notification.FLAG_ONGOING_EVENT) != 0}" +
            "$reasonText,extrasKeys=${e.keySet().sorted().joinToString(";")},messagesArray=$messagesCount," +
            "title=${field(title)},titleBig=${field(titleBig)},text=${field(text)},bigText=${field(big)}," +
            "summary=${field(summary)},subText=${field(sub)},textLines=${lines.size}," +
            "deleteWord=$delete,editWord=$edit,hasConversationTitle=${e.containsKey(Notification.EXTRA_CONVERSATION_TITLE)}," +
            "isGroupConversation=${e.getBoolean("android.isGroupConversation", false)}"
    }

    private fun field(value: String): String = "len=${value.length},hash=${value.hashCode().toString(16)}"

    private fun file(context: Context) = File(context.filesDir, "whatsapp-diagnostics.txt")

    private fun log(context: Context, type: String, detail: String) {
        synchronized(lock) {
            try {
                val f = file(context)
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
                f.appendText("$stamp | $type | $detail\n")
                val lines = f.readLines()
                if (lines.size > MAX_LINES) f.writeText(lines.takeLast(MAX_LINES).joinToString("\n", postfix = "\n"))
            } catch (_: Exception) { }
        }
    }

    fun exportText(context: Context): String = synchronized(lock) {
        val header = "Háblame WhatsApp diagnostics | version=${try { context.packageManager.getPackageInfo(context.packageName, 0).versionName } catch (_: Exception) { "?" }} | Android=${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "Privacy: message bodies and contact/group names are not stored; fields show only length/hash and metadata.\n\n"
        header + try { file(context).takeIf { it.exists() }?.readText().orEmpty() } catch (_: Exception) { "No se pudo leer el registro.\n" }
    }

    fun clear(context: Context) {
        synchronized(lock) {
            try { file(context).writeText("") } catch (_: Exception) { }
        }
        log(context, "DIAGNOSTIC", "Registro limpiado")
    }
}
