# Háblame 1.4.1

Proyecto Android de Háblame, paquete `com.hablame.app`.

Esta versión corrige el procesamiento de notificaciones de grupos de WhatsApp para que los mensajes nuevos puedan anunciarse aunque WhatsApp reutilice/actualice la notificación del grupo, entregue un contador de mensajes o conserve contenido estructurado anterior. La deduplicación de mensajes de grupo se basa en la conversación, la marca temporal disponible, el remitente y el contenido anunciado; no se usa una marca temporal antigua como motivo para silenciar mensajes posteriores.

Se conserva la lógica de mensajes individuales y las demás pantallas/funciones del proyecto. Versión Android: `1.4.1` (`versionCode 44`).

## Compilación

Sube `Háblame 1.4.1.zip` a la raíz del repositorio y asegúrate de que el flujo de trabajo esté disponible en `.github/workflows/build.yml`. Ejecuta GitHub Actions y descarga el artefacto `Hablame-APK-1.4.1`.

Nota: para instalar como actualización sin desinstalar la versión anterior, el APK nuevo debe estar firmado con la misma clave que la versión instalada. Si la compilación usa una clave distinta, Android rechazará la actualización.
