package com.hablame.app

import android.content.Context
import java.io.File

/** Temporary local diagnostics for the WhatsApp group-notification issue. */
object WhatsAppDiagnostic {
    private const val FILE_NAME = "whatsapp_diagnostic.txt"
    @Synchronized fun record(context: Context, message: String) {
        try {
            val file = File(context.filesDir, FILE_NAME)
            val safe = message.replace("\r", " ").replace("\n", " ").take(1400)
            file.appendText("${System.currentTimeMillis()} | $safe\n", Charsets.UTF_8)
            if (file.length() > 100_000L) {
                val lines = file.readLines(Charsets.UTF_8).takeLast(100)
                file.writeText(lines.joinToString("\n", postfix = "\n"), Charsets.UTF_8)
            }
        } catch (_: Exception) { }
    }
    fun read(context: Context): String {
        return try {
            val file = File(context.filesDir, FILE_NAME)
            if (file.exists()) file.readText(Charsets.UTF_8).takeLast(60_000) else "Todavía no hay registros. Envía dos mensajes de prueba al grupo primero."
        } catch (e: Exception) { "No se pudo leer el diagnóstico: ${e.javaClass.simpleName}" }
    }
    fun clear(context: Context) { try { File(context.filesDir, FILE_NAME).delete() } catch (_: Exception) { } }
}
