# Yape Voz 1.5 Pro

Aplicación Android que anuncia en voz alta las notificaciones de pagos de Yape.

## Mejoras 1.5
- Interfaz renovada inspirada en el diseño Pro de Yape Voz.
- Icono 3D renovado.
- Nombre dinámico: primer nombre o nombre y apellido.
- Montos en soles y céntimos en lenguaje natural.
- Opción para leer u omitir el código de seguridad (omitido por defecto).
- Solo procesa notificaciones del paquete oficial de Yape configurado en el proyecto.
- Opción para no anunciar durante llamadas.
- Opción para respetar silencio y No molestar.
- Acceso directo a configuración de Texto a voz con varios intents compatibles.
- La app no selecciona una voz propia: usa la voz que el usuario haya configurado en Android.
- Prueba de voz usando la misma configuración TTS.
- Mantiene deduplicación y funcionamiento en segundo plano.
