package pe.yapevoz

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var screenFlipper: ViewFlipper
    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var nameModeSpinner: Spinner
    private lateinit var codeSwitch: Switch
    private lateinit var callsSwitch: Switch
    private lateinit var silentSwitch: Switch

    private lateinit var navInicio: Button
    private lateinit var navVoz: Button
    private lateinit var navLectura: Button
    private lateinit var navAjustes: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        screenFlipper = findViewById(R.id.screenFlipper)
        status = findViewById(R.id.status)
        enabledSwitch = findViewById(R.id.enabledSwitch)
        nameModeSpinner = findViewById(R.id.nameModeSpinner)
        codeSwitch = findViewById(R.id.codeSwitch)
        callsSwitch = findViewById(R.id.callsSwitch)
        silentSwitch = findViewById(R.id.silentSwitch)

        navInicio = findViewById(R.id.navInicio)
        navVoz = findViewById(R.id.navVoz)
        navLectura = findViewById(R.id.navLectura)
        navAjustes = findViewById(R.id.navAjustes)

        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)

        val modes = listOf("Solo primer nombre", "Nombre y apellido")
        nameModeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modes
        )

        val savedMode = prefs.getString(
            YapeNotificationListener.KEY_NAME_MODE,
            YapeNotificationListener.NAME_FIRST
        ) ?: YapeNotificationListener.NAME_FIRST

        nameModeSpinner.setSelection(
            if (savedMode == YapeNotificationListener.NAME_FULL) 1 else 0
        )

        nameModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val value = if (position == 1) {
                    YapeNotificationListener.NAME_FULL
                } else {
                    YapeNotificationListener.NAME_FIRST
                }
                prefs.edit().putString(YapeNotificationListener.KEY_NAME_MODE, value).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        enabledSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)
        codeSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_READ_CODE, false)
        callsSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
        silentSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)

        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_ENABLED, checked).apply()
            updateStatus()
        }

        codeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_READ_CODE, checked).apply()
        }

        callsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, checked).apply()
        }

        silentSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, checked).apply()
        }

        findViewById<Button>(R.id.testButton).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }

        findViewById<Button>(R.id.testButtonVoice).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }

        findViewById<Button>(R.id.notificationsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.dndButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        findViewById<Button>(R.id.voiceSettingsButton).setOnClickListener {
            openTtsSettings()
        }

        setupNavigation()
        showScreen(0)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun setupNavigation() {
        navInicio.setOnClickListener { showScreen(0) }
        navVoz.setOnClickListener { showScreen(1) }
        navLectura.setOnClickListener { showScreen(2) }
        navAjustes.setOnClickListener { showScreen(3) }
    }

    private fun showScreen(index: Int) {
        screenFlipper.displayedChild = index

        val selected = "#5B20D8"
        val normal = "#776F87"
        navInicio.setTextColor(if (index == 0) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navVoz.setTextColor(if (index == 1) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navLectura.setTextColor(if (index == 2) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navAjustes.setTextColor(if (index == 3) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))

        navInicio.setBackgroundResource(if (index == 0) R.drawable.bg_selected_nav else android.R.color.transparent)
        navVoz.setBackgroundResource(if (index == 1) R.drawable.bg_selected_nav else android.R.color.transparent)
        navLectura.setBackgroundResource(if (index == 2) R.drawable.bg_selected_nav else android.R.color.transparent)
        navAjustes.setBackgroundResource(if (index == 3) R.drawable.bg_selected_nav else android.R.color.transparent)
    }

    private fun openTtsSettings() {
        val intents = listOf(
            Intent("com.android.settings.TTS_SETTINGS").setPackage("com.android.settings"),
            Intent("android.settings.TTS_SETTINGS"),
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent("android.settings.TEXT_TO_SPEECH_SETTINGS")
        )

        for (intent in intents) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: ActivityNotFoundException) {
                // Intentar la siguiente opción.
            }
        }

        try {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updateStatus() {
        val listenerOk = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        )?.contains(packageName) == true

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) == true

        status.text = buildString {
            append(if (listenerOk) "✓ Acceso a notificaciones activo\n" else "⚠ Falta acceso a notificaciones\n")
            append(if (batteryOk) "✓ Batería sin restricciones\n" else "⚠ Falta quitar restricción de batería\n")
            append(if (enabledSwitch.isChecked) "✓ Yape Voz está ACTIVADA" else "⏸ Yape Voz está PAUSADA")
        }
    }
}
