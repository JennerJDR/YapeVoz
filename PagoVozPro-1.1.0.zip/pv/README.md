# Pago Voz Pro — base de nueva versión

Base construida conservando la lógica de lectura de Yape de la versión funcional y agregando una segunda fuente: Banco Falabella.

## Fuentes
- Yape: `com.bcp.innovacxion.yapeapp`
- Banco Falabella Perú: `per.bf.desa`

## Importante
La detección de Banco Falabella usa un parser conservador porque el formato exacto de la notificación recibida por el teléfono debe validarse con una notificación real. No se debe inventar el texto de esa notificación.

## Compilación
Usar Java 17, Android SDK 35 y Gradle 8.10, como en las compilaciones que ya funcionaron.
