# Háblame 1.0.3

Aplicación Android para anunciar llamadas y notificaciones mediante voz.

- applicationId: `com.hablame.app`
- versionName: `1.0.3`
- versionCode: `3`
- compileSdk/targetSdk: 35
- minSdk: 26

La firma estable se configura mediante secretos de GitHub Actions (`HABLAME_KEYSTORE_BASE64`, `HABLAME_KEYSTORE_PASSWORD`, `HABLAME_KEY_ALIAS`, `HABLAME_KEY_PASSWORD`). Si no existen, el workflow usa la firma debug únicamente para poder compilar y probar.
