# Háblame 1.0.3

Aplicación Android para anunciar llamadas y notificaciones mediante voz.

- applicationId: `com.hablame.app`
- versionName: `1.0.3`
- versionCode: `4`
- compileSdk/targetSdk: 35
- minSdk: 26

Esta versión de prueba no incluye ninguna clave privada ni requiere secretos de firma permanente. El APK de release se firma con la clave debug del entorno de compilación para mantener el proceso de prueba sencillo.
