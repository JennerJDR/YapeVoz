package com.hablame.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.regex.Pattern

object Prefs {
    private const val P = "hablame_prefs"
    private fun p(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)
    fun getBool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun getInt(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun getString(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun setString(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

object TextCleaner {
    private val emoji = Pattern.compile("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}\\x{1F3FB}-\\x{1F3FF}]")

    fun cleanName(value: CharSequence?): String {
        if (value == null) return ""
        val s = emoji.matcher(value.toString()).replaceAll("")
        return s.replace(Regex("[\\p{So}\\p{Cn}]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun cleanContent(value: CharSequence?): String {
        if (value == null) return ""
        return value.toString().replace(Regex("\\s+"), " ").trim()
    }

    fun speakableContent(value: CharSequence?): String {
        if (value == null) return ""
        var s = cleanContent(value)
        val replacements = linkedMapOf(
            "❤️" to " corazón ", "❤" to " corazón ", "😂" to " cara llorando de risa ",
            "🤣" to " rodando de risa ", "😊" to " sonrisa ", "🙂" to " sonrisa ",
            "😀" to " cara feliz ", "😃" to " cara feliz ", "😄" to " sonrisa ",
            "😁" to " sonrisa amplia ", "😆" to " risa ", "😅" to " sonrisa nerviosa ",
            "😉" to " guiño ", "😍" to " enamorado ", "😘" to " beso ",
            "🥰" to " enamorado ", "😎" to " gafas de sol ", "😭" to " llorando ",
            "😢" to " triste ", "😡" to " enojado ", "😠" to " enojado ",
            "😱" to " asustado ", "😮" to " sorprendido ", "😴" to " durmiendo ",
            "🤔" to " pensando ", "🙄" to " poniendo los ojos en blanco ",
            "👍" to " pulgar arriba ", "👎" to " pulgar abajo ", "👏" to " aplausos ",
            "🙏" to " manos juntas ", "🔥" to " fuego ", "🎉" to " celebración ",
            "💯" to " cien por cien ", "⭐" to " estrella ", "✨" to " brillo ",
            "💔" to " corazón roto ", "💚" to " corazón verde ", "💙" to " corazón azul ",
            "💜" to " corazón morado ", "💛" to " corazón amarillo ", "🩷" to " corazón rosa ",
            "🚀" to " cohete ", "⚠️" to " advertencia ", "❗" to " exclamación ",
            "❓" to " pregunta ", "☀️" to " sol ", "🌙" to " luna", "☕" to " café ",
            "🎵" to " nota musical ", "🎶" to " notas musicales "
        )
        replacements.forEach { (emoji, word) -> s = s.replace(emoji, word) }
        return s.replace(Regex("\\s+"), " ").trim()
    }
}

object TtsEngine {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private val repeatHandler = Handler(Looper.getMainLooper())
    private var repeatToken = 0

    fun init(c: Context, onReady: (() -> Unit)? = null) {
        if (tts != null && ready) { onReady?.invoke(); return }
        audioManager = c.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(c.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                val voiceName = Prefs.getString(c, "tts_voice", "")
                if (voiceName.isNotEmpty()) {
                    tts?.voices?.firstOrNull { it.name == voiceName }?.let { tts?.voice = it }
                }
                applyAudioAttributes(c)
            }
            onReady?.invoke()
        }
    }

    fun reload(c: Context, onReady: (() -> Unit)? = null) {
        stop()
        tts?.shutdown()
        tts = null
        ready = false
        focusRequest = null
        init(c, onReady)
    }

    private fun usageFor(c: Context): Int = when (Prefs.getString(c, "audio_usage", "notification")) {
        "call" -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        "media" -> AudioAttributes.USAGE_MEDIA
        "alarm" -> AudioAttributes.USAGE_ALARM
        else -> AudioAttributes.USAGE_NOTIFICATION
    }

    private fun streamForUsage(usage: Int): Int = when (usage) {
        AudioAttributes.USAGE_VOICE_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        AudioAttributes.USAGE_MEDIA -> AudioManager.STREAM_MUSIC
        AudioAttributes.USAGE_ALARM -> AudioManager.STREAM_ALARM
        else -> AudioManager.STREAM_NOTIFICATION
    }

    private fun applyAudioAttributes(c: Context) {
        val attrs = AudioAttributes.Builder()
            .setUsage(usageFor(c))
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        tts?.setAudioAttributes(attrs)
    }

    private fun requestFocus(c: Context): Boolean {
        val am = audioManager ?: return false
        val usage = usageFor(c)
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        if (Build.VERSION.SDK_INT >= 26) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .build()
            focusRequest = request
            return am.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        @Suppress("DEPRECATION")
        return am.requestAudioFocus(null, streamForUsage(usage), AudioManager.AUDIOFOCUS_GAIN_TRANSIENT) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
        focusRequest = null
    }

    fun speak(c: Context, text: String) {
        speakRepeated(c, text, 1)
    }

    fun speakRepeated(c: Context, text: String, count: Int) {
        if (text.isBlank()) return
        init(c)
        if (!ready) return
        repeatToken++
        val token = repeatToken
        repeatHandler.removeCallbacksAndMessages(null)
        stopInternal(false)
        applyAudioAttributes(c)
        requestFocus(c)
        var remaining = count.coerceIn(1, 5)

        fun speakNext() {
            if (token != repeatToken || remaining <= 0 || !ready) {
                abandonFocus()
                return
            }
            val utteranceId = "hablame_${System.currentTimeMillis()}_${remaining}"
            val listener = object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    if (token != repeatToken) return
                    remaining--
                    if (remaining > 0) {
                        repeatHandler.postDelayed({ speakNext() }, 900L)
                    } else {
                        abandonFocus()
                    }
                }
                override fun onError(id: String?) { if (token == repeatToken) abandonFocus() }
            }
            tts?.setOnUtteranceProgressListener(listener)
            val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) }
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
        speakNext()
    }

    private fun stopInternal(abandon: Boolean) {
        tts?.stop()
        if (abandon) abandonFocus()
    }

    fun stop() {
        repeatToken++
        repeatHandler.removeCallbacksAndMessages(null)
        stopInternal(true)
    }

    fun voicesForCurrentConfiguration(): List<android.speech.tts.Voice> {
        val engine = tts ?: return emptyList()
        val all = engine.voices?.toList().orEmpty().filter { it.locale.language.isNotBlank() }
        if (all.isEmpty()) return emptyList()
        val currentLocale = engine.language ?: return all.sortedBy { it.name }
        val languageMatches = all.filter { it.locale.language.equals(currentLocale.language, true) }
        if (languageMatches.isNotEmpty()) {
            val countryMatches = languageMatches.filter {
                currentLocale.country.isNotBlank() && it.locale.country.equals(currentLocale.country, true)
            }
            return (if (countryMatches.isNotEmpty()) countryMatches else languageMatches)
                .distinctBy { it.name }
                .sortedWith(compareBy({ it.locale.displayLanguage }, { it.locale.displayCountry }, { it.name }))
        }
        return all.sortedWith(compareBy({ it.locale.displayLanguage }, { it.locale.displayCountry }, { it.name }))
    }

    fun currentVoiceName(): String = tts?.voice?.name.orEmpty()
    fun setVoice(v: android.speech.tts.Voice) { if (ready) tts?.voice = v }
}

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var statusPill: TextView
    private var current = "inicio"
    private var waitingForPermissionSettings = false
    private var permissionFlowStarted = false
    private var runtimePermissionDenied = false
    private var runtimeDialogActive = false
    private var openedTtsSettings = false

    private val blue by lazy { ContextCompat.getColor(this, R.color.hab_blue) }
    private val green by lazy { ContextCompat.getColor(this, R.color.hab_green) }
    private val textColor by lazy { ContextCompat.getColor(this, R.color.hab_text) }
    private val muted by lazy { ContextCompat.getColor(this, R.color.hab_muted) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val scroll = findViewById<ScrollView>(R.id.scroll)
        setupSwipeNavigation(scroll)
        val baseTop = dp(10)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            val bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, top + baseTop, view.paddingRight, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(scroll)
        content = findViewById(R.id.page_container)
        statusPill = findViewById(R.id.service_status)
        setupBottomNav()
        TtsEngine.init(this)
        refreshStatus()
        showPage("inicio")
    }

    override fun onPause() {
        super.onPause()
        if (!waitingForPermissionSettings && !runtimeDialogActive) {
            permissionFlowStarted = false
            runtimePermissionDenied = false
        }
    }

    override fun onResume() {
        super.onResume()
        if (openedTtsSettings) {
            openedTtsSettings = false
            TtsEngine.reload(this) {
                if (current == "voice" && !isFinishing && !isDestroyed) showPage("voice")
            }
        }
        refreshStatus()
        if (waitingForPermissionSettings) {
            waitingForPermissionSettings = false
            Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 450)
        } else if (!permissionFlowStarted && !runtimePermissionDenied) {
            permissionFlowStarted = true
            Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 500)
        }
    }

    private fun continuePermissionFlow() {
        if (isFinishing || isDestroyed) return
        refreshStatus()

        if (!HablameNotificationListener.isEnabled(this)) {
            waitingForPermissionSettings = true
            try {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            return
        }

        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
            return
        }

        if (!hasPermission(Manifest.permission.READ_PHONE_STATE) ||
            (Build.VERSION.SDK_INT >= 26 && !hasPermission(Manifest.permission.READ_PHONE_NUMBERS)) ||
            !hasPermission(Manifest.permission.READ_CALL_LOG)) {
            runtimeDialogActive = true
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_PHONE_NUMBERS,
                    Manifest.permission.READ_CALL_LOG
                ), 21
            )
            return
        }

        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
            return
        }

        if (isBatteryOptimized()) {
            waitingForPermissionSettings = true
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            return
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        runtimeDialogActive = false
        val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (!allGranted) {
            runtimePermissionDenied = true
            Toast.makeText(this, "Quedan permisos pendientes. Se volverán a solicitar al entrar nuevamente.", Toast.LENGTH_LONG).show()
            refreshStatus()
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 350)
    }

    private fun setupBottomNav() {
        findViewById<View>(R.id.nav_home).setOnClickListener { showPage("inicio") }
        findViewById<View>(R.id.nav_apps).setOnClickListener { showPage("apps") }
        findViewById<View>(R.id.nav_calls).setOnClickListener { showPage("calls") }
        findViewById<View>(R.id.nav_voice).setOnClickListener { showPage("voice") }
        findViewById<View>(R.id.nav_permissions).setOnClickListener { showPage("permissions") }
        updateBottomNav("inicio")
    }

    private fun setupSwipeNavigation(scroll: ScrollView) {
        var downX = 0f
        var downY = 0f
        scroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (kotlin.math.abs(dx) > dp(72) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                        if (dx < 0) showAdjacentPage(1) else showAdjacentPage(-1)
                    }
                }
            }
            false
        }
    }

    private fun showAdjacentPage(direction: Int) {
        val pages = listOf("inicio", "apps", "calls", "voice", "permissions")
        val index = pages.indexOf(current)
        if (index < 0) return
        val next = (index + direction).coerceIn(0, pages.lastIndex)
        if (next != index) showPage(pages[next])
    }

    private fun updateBottomNav(page: String) {
        val ids = listOf(R.id.nav_home, R.id.nav_apps, R.id.nav_calls, R.id.nav_voice, R.id.nav_permissions)
        ids.forEachIndexed { index, id ->
            val item = findViewById<LinearLayout>(id)
            val active = when (index) {
                0 -> page == "inicio"
                1 -> page == "apps"
                2 -> page == "calls"
                3 -> page == "voice"
                else -> page == "permissions"
            }
            item.background = if (active) getDrawable(R.drawable.bg_nav_active) else null
            val icon = item.getChildAt(0) as? ImageView
            val label = item.getChildAt(1) as? TextView
            icon?.setColorFilter(if (active) green else blue)
            label?.setTextColor(if (active) green else blue)
            item.alpha = if (active) 1f else 0.82f
        }
    }

    private fun refreshStatus() {
        val enabled = Prefs.getBool(this, "service_enabled", true)
        val notificationOk = HablameNotificationListener.isEnabled(this)
        val phoneOk = hasPermission(Manifest.permission.READ_PHONE_STATE)
        val contactsOk = hasPermission(Manifest.permission.READ_CONTACTS)
        val permissionsOk = notificationOk && phoneOk && contactsOk
        when {
            !enabled -> {
                statusPill.text = "Servicio desactivado"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_disabled_pill)
            }
            permissionsOk -> {
                statusPill.text = "✓  Servicio activo"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_green_pill)
            }
            else -> {
                statusPill.text = "⚠  Requiere permisos"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_red_pill)
            }
        }
    }

    private fun showPage(page: String) {
        current = page
        content.removeAllViews()
        updateBottomNav(page)
        findViewById<ScrollView>(R.id.scroll)?.post { findViewById<ScrollView>(R.id.scroll)?.scrollTo(0, 0) }
        when (page) {
            "inicio" -> homePage()
            "apps" -> appsPage()
            "calls" -> callsPage()
            "voice" -> voicePage()
            "permissions" -> permissionsPage()
        }
    }

    private fun homePage() {
        val enabled = Prefs.getBool(this, "service_enabled", true)
        addSectionTitle("Háblame")
        addText("Lee en voz alta llamadas y notificaciones para que estés siempre informado, sin mirar tu teléfono.", 14, muted)
        val status = card()
        status.addView(text("Estado de Háblame", 17, textColor, true))
        status.addView(space(5))
        status.addView(text(if (enabled) "Llamadas y notificaciones se anuncian según tu configuración." else "Háblame está desactivado. No anunciará llamadas ni notificaciones.", 13, muted))
        content.addView(status)
        addSpacer(10)
        homeActionCard(R.drawable.ic_call, "Llamadas", if (!enabled) "Desactivadas" else if (hasPermission(Manifest.permission.READ_PHONE_STATE)) "Activadas" else "Requiere permiso") { showPage("calls") }
        homeActionCard(R.drawable.ic_bell, "Notificaciones", if (!enabled) "Desactivadas" else if (HablameNotificationListener.isEnabled(this)) "Activadas" else "Requiere acceso") { showPage("apps") }
        addSpacer(8)
        homeActionCard(R.drawable.ic_settings, "Acceso rápido a permisos", "Revisar permisos pendientes") { showPage("permissions") }
        addSpacer(10)
        val toggle = button(if (enabled) "Desactivar Háblame" else "Activar Háblame")
        toggle.background = getDrawable(if (enabled) R.drawable.bg_blue_button else R.drawable.bg_inactive_button)
        toggle.setOnClickListener {
            val next = !Prefs.getBool(this, "service_enabled", true)
            Prefs.setBool(this, "service_enabled", next)
            if (!next) TtsEngine.stop()
            refreshStatus()
            showPage("inicio")
            Toast.makeText(this, if (next) "Háblame activado." else "Háblame desactivado.", Toast.LENGTH_SHORT).show()
        }
        content.addView(toggle)
        addSpacer(18)
    }

    private fun appsPage() {
        addSectionTitle("Aplicaciones")
        addText("Todas las aplicaciones con notificaciones pueden ser leídas. Háblame anuncia primero la aplicación y luego el título de la notificación.", 14, muted)

        val apps = listOf(
            Triple("WhatsApp", "com.whatsapp", "app_com.whatsapp"),
            Triple("Telegram", "org.telegram.messenger", "app_org.telegram.messenger"),
            Triple("Messenger", "com.facebook.orca", "app_com.facebook.orca"),
            Triple("Facebook", "com.facebook.katana", "app_com.facebook.katana"),
            Triple("Instagram", "com.instagram.android", "app_com.instagram.android"),
            Triple("TikTok", "com.zhiliaoapp.musically", "app_com.zhiliaoapp.musically"),
            Triple("Mensajes", "com.google.android.apps.messaging", "app_com.google.android.apps.messaging"),
            Triple("Gmail", "com.google.android.gm", "app_com.google.android.gm")
        )
        apps.forEach { (name, pkg, key) -> appRow(name, pkg, key) }

        val other = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("Otras aplicaciones", 15, textColor, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = androidx.appcompat.widget.SwitchCompat(this)
        sw.isChecked = Prefs.getBool(this, "read_other_apps", true)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, "read_other_apps", v) }
        row.addView(sw)
        other.addView(row)
        other.addView(text("Lee la aplicación y el título de cualquier otra notificación.", 11, muted))
        content.addView(other)
        addSpacer(7)
    }

    private fun appRow(name: String, pkg: String, key: String) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        val lp = LinearLayout.LayoutParams(dp(40), dp(40))
        lp.marginEnd = dp(12)
        icon.layoutParams = lp
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
        catch (_: Exception) { icon.setImageResource(R.drawable.ic_bell) }
        row.addView(icon)
        val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        label.addView(text(name, 15, textColor, true))
        label.addView(text("Lectura de notificaciones", 11, muted))
        row.addView(label)
        val sw = androidx.appcompat.widget.SwitchCompat(this)
        sw.isChecked = Prefs.getBool(this, key, true)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v) }
        row.addView(sw)
        c.addView(row)
        c.setOnClickListener { appDetail(name, pkg, key) }
        content.addView(c)
        addSpacer(7)
    }

    private fun appDetail(name: String, pkg: String, key: String) {
        content.removeAllViews()
        addBack("Aplicaciones") { showPage("apps") }
        addSectionTitle(name)
        addText("Háblame leerá la notificación que llegue de $name.", 14, muted)
        settingSwitch("Activada", Prefs.getBool(this, key, true), key) { }
        settingSwitch("Leer el título de la notificación", Prefs.getBool(this, "title_$pkg", true), "title_$pkg") { }
        settingSwitch("Leer el contenido de la notificación", Prefs.getBool(this, "content_$pkg", true), "content_$pkg") { }
        addSubTitle("Regla general")
        val rule = card()
        rule.addView(text("Emojis y símbolos del nombre de la persona o del grupo se omiten. Los emojis que estén dentro del mensaje se interpretan y se anuncian.", 13, muted))
        content.addView(rule)
    }

    private fun callsPage() {
        addSectionTitle("Llamadas")
        addText("Configura cómo quieres que se anuncien las llamadas entrantes.", 14, muted)
        settingSwitch("Contactos guardados — leer el nombre del contacto", Prefs.getBool(this, "call_contact_name", true), "call_contact_name") { }
        addSubTitle("Números desconocidos")
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val a = RadioButton(this).apply { id = View.generateViewId(); text = "Leer el número" }
        val b = RadioButton(this).apply { id = View.generateViewId(); text = "Decir “número desconocido”" }
        val c = RadioButton(this).apply { id = View.generateViewId(); text = "No anunciar" }
        group.addView(a); group.addView(b); group.addView(c)
        when (Prefs.getString(this, "unknown_mode", "number")) {
            "unknown" -> b.isChecked = true
            "none" -> c.isChecked = true
            else -> a.isChecked = true
        }
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setString(this, "unknown_mode", when (id) { b.id -> "unknown"; c.id -> "none"; else -> "number" })
        }
        content.addView(group)
        addSubTitle("Repetición del anuncio")
        val repCard = card()
        repCard.addView(text("Cuántas veces anunciar una llamada entrante", 14, textColor, true))
        val repSpinner = Spinner(this)
        val repLabels = (1..5).map { if (it == 1) "1 vez" else "$it veces" }
        repSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, repLabels)
        repSpinner.setSelection((Prefs.getInt(this, "call_repetitions", 2).coerceIn(1, 5)) - 1)
        repSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Prefs.setInt(this@MainActivity, "call_repetitions", position + 1)
            }
        }
        repCard.addView(repSpinner)
        content.addView(repCard)
        addSpacer(8)
        addSubTitle("Otras opciones")
        val info = card()
        info.addView(text("Háblame solo habla en modo de sonido normal.", 14, textColor, true))
        info.addView(text("En silencio, vibración o No molestar no realizará anuncios.", 12, muted))
        content.addView(info)
    }

    private fun voicePage() {
        addSectionTitle("Voz")
        addText("Configura la voz que utiliza el motor TTS seleccionado en Android y el canal de audio para sus anuncios.", 14, muted)

        val c = card()
        c.addView(text("Voces del TTS actual", 13, textColor, true))
        val settings = button("⚙  Configurar TTS")
        settings.setOnClickListener {
            openedTtsSettings = true
            try {
                startActivity(Intent(Settings.ACTION_TEXT_TO_SPEECH_SETTINGS))
            } catch (_: Exception) {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { }
            }
        }
        c.addView(settings)
        addSpacer(6)

        val spinner = Spinner(this)
        val voices = TtsEngine.voicesForCurrentConfiguration()
        val labels = voices.map {
            val locale = it.locale.toLanguageTag().ifBlank { it.locale.displayLanguage }
            "$locale — ${it.name.substringAfterLast(".")}"
        }.toMutableList()
        if (labels.isEmpty()) labels.add("No hay voces disponibles para la configuración actual")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        c.addView(spinner)
        val currentVoice = Prefs.getString(this, "tts_voice", "")
        val idx = voices.indexOfFirst { it.name == currentVoice || it.name == TtsEngine.currentVoiceName() }
        if (idx >= 0) spinner.setSelection(idx)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p: AdapterView<*>?) {}
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos < voices.size) {
                    TtsEngine.setVoice(voices[pos])
                    Prefs.setString(this@MainActivity, "tts_voice", voices[pos].name)
                }
            }
        }
        addSpacer(5)
        val test = button("▶  Probar voz")
        test.setOnClickListener { TtsEngine.speak(this, "Esta es una prueba de voz de Háblame.") }
        c.addView(test)
        content.addView(c)

        addSpacer(8)
        addSubTitle("Canal de audio")
        val audioCard = card()
        audioCard.addView(text("Elige por qué canal del sistema quieres escuchar la voz de Háblame.", 12, muted))
        val audioGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val options = listOf(
            Triple("call", "Llamadas", AudioManager.STREAM_VOICE_CALL),
            Triple("alarm", "Alarma", AudioManager.STREAM_ALARM),
            Triple("media", "Multimedia", AudioManager.STREAM_MUSIC),
            Triple("notification", "Notificaciones", AudioManager.STREAM_NOTIFICATION)
        )
        val radioByKey = mutableMapOf<String, RadioButton>()
        options.forEach { (key, label, _) ->
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = label
                setPadding(0, dp(2), 0, dp(2))
            }
            radioByKey[key] = rb
            audioGroup.addView(rb)
        }
        val selectedAudio = Prefs.getString(this, "audio_usage", "notification")
        radioByKey[selectedAudio]?.isChecked = true
        audioGroup.setOnCheckedChangeListener { group, checkedId ->
            val selected = options.firstOrNull { radioByKey[it.first]?.id == checkedId }?.first ?: "notification"
            Prefs.setString(this, "audio_usage", selected)
            TtsEngine.reload(this)
        }
        audioCard.addView(audioGroup)
        audioCard.addView(text("Háblame solicita el tipo de audio elegido y prioridad temporal mientras habla, pero no cambia automáticamente el volumen del teléfono.", 12, muted))
        content.addView(audioCard)

        addSpacer(8)
        settingSwitch("Solo en modo sonido normal", Prefs.getBool(this, "normal_only", true), "normal_only") { }
        addText("No hablar en silencio, vibración o No molestar.", 12, muted)
        val rule = card()
        rule.addView(text("Emojis y símbolos en nombres y grupos", 14, textColor, true))
        rule.addView(text("Se omiten automáticamente en el nombre de la persona o del grupo. Si aparecen dentro del mensaje, Háblame los interpreta al hablar.", 12, muted))
        content.addView(rule)
    }

    private fun permissionsPage() {
        addSectionTitle("Permisos")
        addText("Al entrar por primera vez, Háblame solicita automáticamente los permisos que falten.", 14, muted)
        permissionRow("Acceso a notificaciones", HablameNotificationListener.isEnabled(this)) {
            waitingForPermissionSettings = true
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        permissionRow("Notificaciones de Háblame", Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        permissionRow("Batería sin restricciones", !isBatteryOptimized()) {
            waitingForPermissionSettings = true
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        permissionRow("Inicio automático", true) {
            Toast.makeText(this, "El inicio automático depende del fabricante del teléfono.", Toast.LENGTH_LONG).show()
        }
        permissionRow("Teléfono", hasPermission(Manifest.permission.READ_PHONE_STATE) && hasPermission(Manifest.permission.READ_CALL_LOG)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_CALL_LOG), 21)
        }
        permissionRow("Contactos", hasPermission(Manifest.permission.READ_CONTACTS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
        }
        permissionRow("Texto a voz", true) {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { }
        }
    }

    private fun permissionRow(title: String, ok: Boolean, action: () -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        icon.setImageResource(if (ok) R.drawable.ic_shield else R.drawable.ic_bell)
        row.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(text(title, 14, textColor, true))
        col.addView(text(if (ok) "Permitido" else "Requiere atención", 12, if (ok) green else ContextCompat.getColor(this, R.color.hab_red)))
        row.addView(col)
        row.addView(text(if (ok) "✓" else "›", 20, if (ok) green else blue, true))
        c.addView(row)
        c.setOnClickListener { action() }
        content.addView(c)
        addSpacer(7)
    }

    private fun settingSwitch(label: String, checked: Boolean, key: String, onChanged: (Boolean) -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(label, 14, textColor, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = androidx.appcompat.widget.SwitchCompat(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v); onChanged(v) }
        row.addView(sw)
        c.addView(row)
        content.addView(c)
        addSpacer(7)
    }

    private fun homeActionCard(iconRes: Int, title: String, sub: String, onClick: () -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        icon.setImageResource(iconRes)
        row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(text(title, 15, textColor, true))
        col.addView(text(sub, 12, green))
        row.addView(col)
        row.addView(text("✓", 20, green, true))
        c.addView(row)
        c.setOnClickListener { onClick() }
        content.addView(c)
        addSpacer(7)
    }

    private fun addBack(label: String, onClick: () -> Unit) {
        val b = TextView(this).apply {
            text = "‹  $label"; textSize = 14f; setTextColor(blue); setPadding(0, 4, 0, 12); setOnClickListener { onClick() }
        }
        content.addView(b)
    }

    private fun addSectionTitle(s: String): TextView {
        val t = text(s, 25, textColor, true)
        t.setPadding(0, 4, 0, 4)
        content.addView(t)
        return t
    }

    private fun addSubTitle(s: String) { content.addView(text(s, 14, textColor, true)); addSpacer(4) }
    private fun addText(s: String, size: Int, color: Int) { content.addView(text(s, size, color, false)); addSpacer(7) }
    private fun addSpacer(n: Int) { content.addView(space(n)) }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(2, 2, 2, 2) }
    private fun space(h: Int) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = getDrawable(R.drawable.bg_card); setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = LinearLayout.LayoutParams(-1, -2) }
    private fun button(label: String) = Button(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE); background = getDrawable(R.drawable.bg_blue_button); isAllCaps = false; minHeight = dp(48) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun isBatteryOptimized(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        return !pm.isIgnoringBatteryOptimizations(packageName)
    }
}
