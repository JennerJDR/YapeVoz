package com.hablame.app

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap

class HablameNotificationListener : NotificationListenerService() {
    companion object {
        private val recent = ConcurrentHashMap<String, Long>()

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(":").any {
                try { ComponentName.unflattenFromString(it) == ComponentName(context, HablameNotificationListener::class.java) }
                catch (_: Exception) { false }
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.getBool(this, "service_enabled", true)) return
        val pkg = sbn.packageName
        if (pkg == packageName) return

        val knownKey = "app_$pkg"
        val knownApps = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.facebook.katana",
            "com.instagram.android",
            "com.zhiliaoapp.musically",
            "com.google.android.apps.messaging",
            "com.google.android.gm"
        )

        if (pkg in knownApps) {
            if (!Prefs.getBool(this, knownKey, true)) return
        } else if (!Prefs.getBool(this, "read_other_apps", true)) {
            return
        }

        if (!canSpeak()) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = n.extras ?: Bundle()
        val title = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_TITLE))
        val text = TextCleaner.speakableContent(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)
        )
        val conversation = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))

        val key = "$pkg|$title|$conversation|$text"
        val now = System.currentTimeMillis()
        val old = recent[key]
        if (old != null && now - old < 5000L) return
        recent[key] = now
        recent.entries.removeIf { now - it.value > 15000L }

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.').ifBlank { "Aplicación" }
        }

        val readTitle = Prefs.getBool(this, "title_$pkg", true)
        val readContent = Prefs.getBool(this, "content_$pkg", true)
        val titlePart = if (readTitle && title.isNotBlank()) title else ""
        val contentPart = if (readContent && text.isNotBlank()) text else ""

        val speech = when {
            titlePart.isNotBlank() && contentPart.isNotBlank() -> "$appName. $titlePart. $contentPart"
            titlePart.isNotBlank() -> "$appName. $titlePart"
            contentPart.isNotBlank() -> "$appName. $contentPart"
            else -> appName
        }

        if (speech.isNotBlank()) TtsEngine.speak(this, speech)
    }

    private fun canSpeak(): Boolean {
        if (!Prefs.getBool(this, "normal_only", true)) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
