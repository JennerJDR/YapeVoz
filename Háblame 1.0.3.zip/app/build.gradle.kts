plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hablame.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hablame.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.0.3"
    }

    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("HABLAME_KEYSTORE_PATH")
            val keystorePassword = System.getenv("HABLAME_KEYSTORE_PASSWORD")
            val keyAliasEnv = System.getenv("HABLAME_KEY_ALIAS")
            val keyPasswordEnv = System.getenv("HABLAME_KEY_PASSWORD")

            if (keystorePath.isNullOrBlank() || keystorePassword.isNullOrBlank() ||
                keyAliasEnv.isNullOrBlank() || keyPasswordEnv.isNullOrBlank()) {
                throw GradleException("Falta la firma permanente de Háblame. Configura los secretos HABLAME_KEYSTORE_BASE64, HABLAME_KEYSTORE_PASSWORD, HABLAME_KEY_ALIAS y HABLAME_KEY_PASSWORD en GitHub Actions.")
            }

            storeFile = file(keystorePath)
            storePassword = keystorePassword
            keyAlias = keyAliasEnv
            keyPassword = keyPasswordEnv
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
