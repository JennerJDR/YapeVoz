# Háblame 1.0.1

Aplicación Android para anunciar llamadas y notificaciones mediante voz.

- applicationId: `com.hablame.app`
- versionName: `1.0.1`
- versionCode: `2`
- compileSdk/targetSdk: 35
- minSdk: 26

La firma estable se configura mediante secretos de GitHub Actions (`HABLAME_KEYSTORE_BASE64`, `HABLAME_KEYSTORE_PASSWORD`, `HABLAME_KEY_ALIAS`, `HABLAME_KEY_PASSWORD`). Si no existen, el workflow usa la firma debug únicamente para poder compilar y probar.
