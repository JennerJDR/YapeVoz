plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.hablame.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hablame.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.0.1"
    }

    signingConfigs {
        // Firma estable opcional mediante secretos de GitHub Actions.
        // Si no están configurados, se usa la firma debug de Gradle para poder compilar.
        val ksPath = System.getenv("HABLAME_KEYSTORE_PATH")
        val ksPassword = System.getenv("HABLAME_KEYSTORE_PASSWORD")
        val ksAlias = System.getenv("HABLAME_KEY_ALIAS")
        val keyPassword = System.getenv("HABLAME_KEY_PASSWORD")
        if (!ksPath.isNullOrBlank() && !ksPassword.isNullOrBlank() &&
            !ksAlias.isNullOrBlank() && !keyPassword.isNullOrBlank()) {
            create("permanent") {
                storeFile = file(ksPath)
                storePassword = ksPassword
                keyAlias = ksAlias
                this.keyPassword = keyPassword
            }
        }
    }

    buildTypes {
        debug {
            if (signingConfigs.names.contains("permanent")) {
                signingConfig = signingConfigs.getByName("permanent")
            }
        }
        release {
            if (signingConfigs.names.contains("permanent")) {
                signingConfig = signingConfigs.getByName("permanent")
            } else {
                signingConfig = signingConfigs.getByName("debug")
            }
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
