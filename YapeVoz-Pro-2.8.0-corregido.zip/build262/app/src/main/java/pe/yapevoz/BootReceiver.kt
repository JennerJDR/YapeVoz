package pe.yapevoz

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return

        val prefs = context.getSharedPreferences(YapeNotificationListener.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)) {
            YapeWatchdogService.start(context)
        }
    }
}
