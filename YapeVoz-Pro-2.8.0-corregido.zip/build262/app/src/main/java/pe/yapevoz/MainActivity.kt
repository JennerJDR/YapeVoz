package pe.yapevoz

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Build
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.ViewFlipper
import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var screenFlipper: ViewFlipper
    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var nameModeSpinner: Spinner
    private lateinit var codeSwitch: Switch
    private lateinit var callsSwitch: Switch
    private lateinit var silentSwitch: Switch
    private lateinit var notificationAccessSwitch: Switch
    private lateinit var showNotificationsSwitch: Switch
    private lateinit var batterySwitch: Switch
    private lateinit var autostartSwitch: Switch
    private lateinit var todayCount: TextView
    private lateinit var todayTotal: TextView
    private lateinit var historyText: TextView

    private var firstSetupStage = 0
    private var firstSetupWaitingForReturn = false
    private val firstSetupHandler = Handler(Looper.getMainLooper())

    private lateinit var navInicio: Button
    private lateinit var navVoz: Button
    private lateinit var navLectura: Button
    private lateinit var navAjustes: Button

    private val statusHandler = Handler(Looper.getMainLooper())
    private val statusRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            updateStats()
            statusHandler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        screenFlipper = findViewById(R.id.screenFlipper)
        status = findViewById(R.id.status)
        enabledSwitch = findViewById(R.id.enabledSwitch)
        nameModeSpinner = findViewById(R.id.nameModeSpinner)
        codeSwitch = findViewById(R.id.codeSwitch)
        callsSwitch = findViewById(R.id.callsSwitch)
        silentSwitch = findViewById(R.id.silentSwitch)
        notificationAccessSwitch = findViewById(R.id.notificationAccessSwitch)
        showNotificationsSwitch = findViewById(R.id.showNotificationsSwitch)
        batterySwitch = findViewById(R.id.batterySwitch)
        autostartSwitch = findViewById(R.id.autostartSwitch)
        todayCount = findViewById(R.id.todayCount)
        todayTotal = findViewById(R.id.todayTotal)
        historyText = findViewById(R.id.historyText)

        val root = findViewById<View>(R.id.root)
        val initialTop = root.paddingTop
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(view.paddingLeft, initialTop + bars.top, view.paddingRight, initialBottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        navInicio = findViewById(R.id.navInicio)
        navVoz = findViewById(R.id.navVoz)
        navLectura = findViewById(R.id.navLectura)
        navAjustes = findViewById(R.id.navAjustes)

        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)

        val speechVolumeSeekBar = findViewById<SeekBar>(R.id.speechVolumeSeekBar)
        val speechVolumeValue = findViewById<TextView>(R.id.speechVolumeValue)
        val savedSpeechVolume = prefs.getFloat(
            YapeNotificationListener.KEY_TTS_VOLUME,
            YapeNotificationListener.DEFAULT_TTS_VOLUME
        ).coerceIn(
            YapeNotificationListener.MIN_TTS_VOLUME,
            YapeNotificationListener.MAX_TTS_VOLUME
        )
        val initialVolumeProgress = (savedSpeechVolume * 100f).toInt().coerceIn(0, 100)
        speechVolumeSeekBar.max = 100
        speechVolumeSeekBar.progress = initialVolumeProgress

        fun updateSpeechVolumeLabel(progress: Int) {
            val volume = (progress.coerceIn(0, 100) / 100f)
                .coerceIn(
                    YapeNotificationListener.MIN_TTS_VOLUME,
                    YapeNotificationListener.MAX_TTS_VOLUME
                )
            prefs.edit().putFloat(YapeNotificationListener.KEY_TTS_VOLUME, volume).apply()
            speechVolumeValue.text = String.format(Locale.US, "%d%%", (volume * 100).toInt())
        }

        updateSpeechVolumeLabel(initialVolumeProgress)
        speechVolumeSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateSpeechVolumeLabel(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        findViewById<Button>(R.id.resetSpeechVolumeButton).setOnClickListener {
            val defaultVolumeProgress = (YapeNotificationListener.DEFAULT_TTS_VOLUME * 100f)
                .toInt().coerceIn(0, 100)
            speechVolumeSeekBar.progress = defaultVolumeProgress
            updateSpeechVolumeLabel(defaultVolumeProgress)
        }

        val modes = listOf("Solo primer nombre", "Nombre y apellido")
        nameModeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modes
        )

        val savedMode = prefs.getString(
            YapeNotificationListener.KEY_NAME_MODE,
            YapeNotificationListener.NAME_FIRST
        ) ?: YapeNotificationListener.NAME_FIRST

        nameModeSpinner.setSelection(
            if (savedMode == YapeNotificationListener.NAME_FULL) 1 else 0
        )

        nameModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val value = if (position == 1) {
                    YapeNotificationListener.NAME_FULL
                } else {
                    YapeNotificationListener.NAME_FIRST
                }
                prefs.edit().putString(YapeNotificationListener.KEY_NAME_MODE, value).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        enabledSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)
        codeSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_READ_CODE, false)
        callsSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
        silentSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)

        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_ENABLED, checked).apply()
            if (checked) {
                startProtection()
            } else {
                YapeWatchdogService.stop(this)
            }
            updateStatus()
        }

        codeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_READ_CODE, checked).apply()
        }

        callsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, checked).apply()
        }

        silentSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, checked).apply()
        }

        findViewById<Button>(R.id.testButtonVoice).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }

        findViewById<Button>(R.id.reactivateButton).setOnClickListener {
            reactivateService()
        }

        findViewById<Button>(R.id.notificationsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        notificationAccessSwitch.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.showNotificationsButton).setOnClickListener {
            openAppNotificationSettings()
        }
        showNotificationsSwitch.setOnClickListener {
            openAppNotificationSettings()
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            openBatterySettings()
        }
        batterySwitch.setOnClickListener {
            openBatterySettings()
        }

        findViewById<Button>(R.id.autostartButton).setOnClickListener {
            openAutoStartSettings()
        }
        autostartSwitch.setOnClickListener {
            autostartSwitch.isChecked = true
            getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
                .edit().putBoolean(KEY_AUTOSTART_CONFIRMED, true).apply()
            openAutoStartSettings()
        }
        if (isSamsungDevice()) {
            (findViewById<Button>(R.id.autostartButton).parent as? View)?.visibility = View.GONE
        }

        findViewById<Button>(R.id.voiceSettingsButton).setOnClickListener {
            openTtsSettings()
        }

        setupSettings(prefs)
        (findViewById<SeekBar>(R.id.speechVolumeSeekBar).parent as? View)?.visibility = View.GONE
        findViewById<Button>(R.id.themeButton).setOnClickListener { showScreen(4) }

        setupNavigation()
        showScreen(0)
        startProtection()
        updateStatus()
        updateStats()

        if (!prefs.getBoolean(KEY_FIRST_SETUP_DONE, false)) {
            firstSetupHandler.postDelayed({ startFirstSetup() }, 500L)
        }
    }

    override fun onResume() {
        super.onResume()
        if (firstSetupWaitingForReturn) {
            firstSetupWaitingForReturn = false
            firstSetupHandler.postDelayed({ continueFirstSetup() }, 450L)
        }
        startProtection()
        YapeNotificationListener.syncDefaultVoice(this)
        updatePermissionSwitches()
        applySavedTheme()
        updateStatus()
        updateStats()
        statusHandler.removeCallbacks(statusRunnable)
        statusHandler.postDelayed(statusRunnable, 1000L)
    }

    override fun onPause() {
        statusHandler.removeCallbacks(statusRunnable)
        super.onPause()
    }


    private fun openBatterySettings() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun updatePermissionSwitches() {
        notificationAccessSwitch.isChecked = isNotificationListenerEnabled()
        showNotificationsSwitch.isChecked = if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm?.areNotificationsEnabled() == true
        }
        val pm = getSystemService(PowerManager::class.java)
        batterySwitch.isChecked = pm?.isIgnoringBatteryOptimizations(packageName) == true
        if (!isSamsungDevice()) {
            autostartSwitch.isChecked = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
                .getBoolean(KEY_AUTOSTART_CONFIRMED, !isXiaomiDevice())
        }
    }

    private fun isSamsungDevice(): Boolean = Build.MANUFACTURER.lowercase(Locale.ROOT).contains("samsung")

    private fun applySavedTheme() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        applyTheme(prefs.getString(KEY_THEME, THEME_LIGHT) ?: THEME_LIGHT)
    }

    private fun setupSettings(prefs: android.content.SharedPreferences) {
        val seek = findViewById<SeekBar>(R.id.settingsSpeechVolumeSeekBar)
        val value = findViewById<TextView>(R.id.settingsSpeechVolumeValue)
        val saved = prefs.getFloat(YapeNotificationListener.KEY_TTS_VOLUME, YapeNotificationListener.DEFAULT_TTS_VOLUME)
            .coerceIn(YapeNotificationListener.MIN_TTS_VOLUME, YapeNotificationListener.MAX_TTS_VOLUME)
        seek.progress = (saved * 100f).toInt()
        value.text = "${seek.progress}%"
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = (progress / 100f).coerceIn(YapeNotificationListener.MIN_TTS_VOLUME, YapeNotificationListener.MAX_TTS_VOLUME)
                prefs.edit().putFloat(YapeNotificationListener.KEY_TTS_VOLUME, v).apply()
                value.text = "${(v * 100).toInt()}%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        findViewById<Button>(R.id.settingsResetVolumeButton).setOnClickListener {
            seek.progress = (YapeNotificationListener.DEFAULT_TTS_VOLUME * 100f).toInt()
        }
        findViewById<Button>(R.id.settingsBackButton).setOnClickListener { showScreen(0) }
        findViewById<Button>(R.id.themeSettingsButton).setOnClickListener {
            val names = arrayOf("☀️  Claro", "🌙  Oscuro", "🟣  Morado", "🔵  Azul")
            val keys = arrayOf(THEME_LIGHT, THEME_DARK, THEME_PURPLE, THEME_BLUE)
            val current = keys.indexOf(prefs.getString(KEY_THEME, THEME_LIGHT)).coerceAtLeast(0)
            AlertDialog.Builder(this).setTitle("Elegir tema")
                .setSingleChoiceItems(names, current) { dialog, which ->
                    prefs.edit().putString(KEY_THEME, keys[which]).apply()
                    applyTheme(keys[which])
                    dialog.dismiss()
                }.show()
        }
        findViewById<Button>(R.id.resetSettingsButton).setOnClickListener {
            AlertDialog.Builder(this).setTitle("Restablecer ajustes")
                .setMessage("Se devolverán las opciones de la aplicación a sus valores predeterminados. Los permisos de Android no se modificarán.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Restablecer") { _, _ ->
                    prefs.edit()
                        .putBoolean(YapeNotificationListener.KEY_ENABLED, true)
                        .putBoolean(YapeNotificationListener.KEY_READ_CODE, false)
                        .putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
                        .putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)
                        .putString(YapeNotificationListener.KEY_NAME_MODE, YapeNotificationListener.NAME_FIRST)
                        .putFloat(YapeNotificationListener.KEY_TTS_VOLUME, YapeNotificationListener.DEFAULT_TTS_VOLUME)
                        .putString(KEY_THEME, THEME_LIGHT).apply()
                    enabledSwitch.isChecked = true
                    codeSwitch.isChecked = false
                    callsSwitch.isChecked = true
                    silentSwitch.isChecked = true
                    nameModeSpinner.setSelection(0)
                    seek.progress = (YapeNotificationListener.DEFAULT_TTS_VOLUME * 100f).toInt()
                    applyTheme(THEME_LIGHT)
                    Toast.makeText(this, "Ajustes restablecidos.", Toast.LENGTH_SHORT).show()
                }.show()
        }
    }

    private fun applyTheme(theme: String) {
        val root = findViewById<View>(R.id.root)
        val dark = theme == THEME_DARK
        val accent = when (theme) {
            THEME_BLUE -> Color.rgb(25, 91, 190)
            THEME_PURPLE -> Color.rgb(112, 47, 210)
            THEME_DARK -> Color.rgb(132, 84, 238)
            else -> Color.rgb(91, 32, 216)
        }
        val bg = if (dark) Color.rgb(20, 18, 25) else Color.rgb(250, 249, 253)
        val surface = if (dark) Color.rgb(43, 40, 51) else when (theme) {
            THEME_BLUE -> Color.rgb(235, 244, 255)
            THEME_PURPLE -> Color.rgb(245, 238, 255)
            else -> Color.rgb(241, 248, 255)
        }
        val primary = if (dark) Color.WHITE else Color.rgb(33, 22, 83)
        val secondary = if (dark) Color.rgb(205, 198, 216) else Color.rgb(113, 106, 125)
        root.setBackgroundColor(bg)
        findViewById<View>(R.id.bottomNav).setBackgroundColor(if (dark) Color.rgb(27, 24, 34) else Color.WHITE)
        findViewById<Button>(R.id.themeButton).backgroundTintList = ColorStateList.valueOf(accent)
        val label = when (theme) { THEME_DARK -> "Oscuro"; THEME_PURPLE -> "Morado"; THEME_BLUE -> "Azul"; else -> "Claro" }
        findViewById<Button>(R.id.themeSettingsButton).text = "🎨  Tema\n$label"
        applyThemeRecursive(root, dark, accent, surface, primary, secondary)
        window.statusBarColor = if (dark) Color.rgb(14, 12, 18) else Color.rgb(33, 22, 83)
        window.navigationBarColor = if (dark) Color.rgb(14, 12, 18) else Color.WHITE
    }

    private fun applyThemeRecursive(view: View, dark: Boolean, accent: Int, surface: Int, primary: Int, secondary: Int) {
        if (view is TextView) {
            val c = view.currentTextColor
            if (c != Color.WHITE && c != Color.rgb(233,225,255) && c != Color.rgb(228,255,240)) {
                view.setTextColor(if (dark) secondary else if (c == Color.rgb(113,106,125) || c == Color.rgb(81,72,94)) secondary else primary)
            }
        }
        if (view is Button) {
            val t = view.text.toString()
            if (t.contains("Tema") || t.contains("Restablecer") || t.contains("Abrir configuración") || t.contains("Volumen")) {
                view.setTextColor(if (dark) Color.WHITE else accent)
            }
        }
        if (view is LinearLayout && view.id != R.id.root && view.id != R.id.bottomNav) {
            view.backgroundTintList = ColorStateList.valueOf(surface)
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) applyThemeRecursive(view.getChildAt(i), dark, accent, surface, primary, secondary)
        }
    }

    private fun isXiaomiDevice(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase(Locale.ROOT)
        return manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")
    }

    private fun startFirstSetup() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_FIRST_SETUP_DONE, false)) return
        firstSetupStage = 0
        continueFirstSetup()
    }

    private fun continueFirstSetup() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_FIRST_SETUP_DONE, false)) return

        when (firstSetupStage) {
            0 -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_POST_NOTIFICATIONS)
                    return
                }
                firstSetupStage = 1
                continueFirstSetup()
            }
            1 -> {
                if (!isNotificationListenerEnabled()) {
                    firstSetupWaitingForReturn = true
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    return
                }
                firstSetupStage = 2
                continueFirstSetup()
            }
            2 -> {
                val pm = getSystemService(PowerManager::class.java)
                if (pm?.isIgnoringBatteryOptimizations(packageName) != true) {
                    firstSetupWaitingForReturn = true
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                    return
                }
                firstSetupStage = 3
                continueFirstSetup()
            }
            3 -> {
                firstSetupStage = 4
                firstSetupWaitingForReturn = true
                openAutoStartSettings()
            }
            else -> {
                prefs.edit().putBoolean(KEY_FIRST_SETUP_DONE, true).apply()
                Toast.makeText(this, "Configuración inicial lista. Yape Voz está preparado.", Toast.LENGTH_SHORT).show()
                updateStatus()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            firstSetupStage = 1
            firstSetupHandler.postDelayed({ continueFirstSetup() }, 300L)
        }
    }

    private fun openAppNotificationSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            })
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    private fun openAutoStartSettings() {
        // Xiaomi/Redmi/POCO: abre directamente la pantalla de
        // "Autoencendido" (Autostart) de Seguridad. Xiaomi expone
        // esta pantalla mediante SecurityCenter; el usuario debe
        // activar manualmente Yape Voz.
        val xiaomiIntent = Intent().apply {
            component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
        }
        try {
            if (xiaomiIntent.resolveActivity(packageManager) != null) {
                startActivity(xiaomiIntent)
                return
            }
        } catch (_: Exception) {}

        // Algunas versiones de HyperOS exponen una acción propia.
        val hyperOsIntent = Intent("miui.intent.action.OP_AUTO_START").apply {
            setPackage("com.miui.securitycenter")
            data = Uri.parse("package:$packageName")
        }
        try {
            if (hyperOsIntent.resolveActivity(packageManager) != null) {
                startActivity(hyperOsIntent)
                return
            }
        } catch (_: Exception) {}

        // Último recurso: información de la aplicación.
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        try {
            startActivity(appDetails)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updateStats() {
        val summary = YapeNotificationListener.getTodaySummary(this)
        todayCount.text = summary.first.toString()
        todayTotal.text = String.format(Locale.US, "S/ %.2f", summary.second / 100.0)
        historyText.text = YapeNotificationListener.getHistoryText(this)
    }

    private fun setupNavigation() {
        navInicio.setOnClickListener { showScreen(0) }
        navLectura.setOnClickListener { showScreen(1) }
        navVoz.setOnClickListener { showScreen(2) }
        navAjustes.setOnClickListener { showScreen(3) }
    }

    private fun showScreen(index: Int) {
        screenFlipper.displayedChild = index

        val selected = "#5B20D8"
        val normal = "#776F87"
        navInicio.setTextColor(if (index == 0) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navLectura.setTextColor(if (index == 1) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navVoz.setTextColor(if (index == 2) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navAjustes.setTextColor(if (index == 3) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))

        navInicio.setBackgroundResource(if (index == 0) R.drawable.bg_selected_nav else android.R.color.transparent)
        navLectura.setBackgroundResource(if (index == 1) R.drawable.bg_selected_nav else android.R.color.transparent)
        navVoz.setBackgroundResource(if (index == 2) R.drawable.bg_selected_nav else android.R.color.transparent)
        navAjustes.setBackgroundResource(if (index == 3) R.drawable.bg_selected_nav else android.R.color.transparent)
    }

    private fun openTtsSettings() {
        val intents = listOf(
            Intent("com.android.settings.TTS_SETTINGS").setPackage("com.android.settings"),
            Intent("android.settings.TTS_SETTINGS"),
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent("android.settings.TEXT_TO_SPEECH_SETTINGS")
        )

        for (intent in intents) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: ActivityNotFoundException) {
                // Intentar la siguiente opción.
            }
        }

        try {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun startProtection() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)) {
            YapeWatchdogService.start(this)
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun reactivateService() {
        if (!isNotificationListenerEnabled()) {
            Toast.makeText(
                this,
                "Activa primero el acceso a notificaciones de Yape Voz.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return
        }

        getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
            .edit().putBoolean(YapeNotificationListener.KEY_ENABLED, true).apply()
        enabledSwitch.isChecked = true
        YapeWatchdogService.start(this)

        Toast.makeText(this, "Servicio de Yape Voz reactivado.", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        val listenerAccess = isNotificationListenerEnabled()
        val connected = YapeNotificationListener.isConnected(this)
        val watchdog = YapeWatchdogService.isRunning(this)

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) == true

        status.text = buildString {
            append(if (connected) "✓ Escuchando notificaciones de Yape\n" else if (listenerAccess) "⚠ Acceso activo, pero el lector no está conectado\n" else "⚠ Falta acceso a notificaciones\n")
            append(if (watchdog) "✓ Protección en segundo plano activa\n" else "⚠ Protección en segundo plano detenida\n")
            append(if (batteryOk) "✓ Batería sin restricciones\n" else "⚠ Falta quitar restricción de batería\n")
            append(if (enabledSwitch.isChecked) "✓ Yape Voz está ACTIVADA" else "⏸ Yape Voz está PAUSADA")
        }
    }

    companion object {
        private const val REQUEST_POST_NOTIFICATIONS = 9001
        private const val KEY_FIRST_SETUP_DONE = "first_setup_done"
        private const val KEY_AUTOSTART_CONFIRMED = "autostart_confirmed"
        private const val KEY_THEME = "app_theme"
        private const val THEME_LIGHT = "light"
        private const val THEME_DARK = "dark"
        private const val THEME_PURPLE = "purple"
        private const val THEME_BLUE = "blue"
    }
}
