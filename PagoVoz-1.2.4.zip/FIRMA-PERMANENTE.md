# Firma permanente de Pago Voz 1.2.4

Esta versión usa `signing/pagovoz-release.jks` y el alias `pagovoz`.

IMPORTANTE: conservar SIEMPRE la carpeta `signing/` y el archivo `.jks`.
No publicar el repositorio ni compartir estos archivos con terceros.
Todas las versiones posteriores deben usar exactamente esta misma clave para poder actualizar 1.2.4 encima.
