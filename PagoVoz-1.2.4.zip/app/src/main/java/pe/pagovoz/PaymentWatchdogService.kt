package pe.pagovoz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat

/**
 * Servicio en primer plano de vigilancia.
 * Mantiene el proceso de Pago Voz activo y pide a Android que vuelva a enlazar
 * el NotificationListener cuando se desconecta.
 */
class PaymentWatchdogService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val checkRunnable = object : Runnable {
        override fun run() {
            checkListener()
            handler.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        setRunning(this, true)
        createChannel()
        startAsForeground()
        handler.post(checkRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        checkListener()
        return START_STICKY
    }

    override fun onDestroy() {
        setRunning(this, false)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun checkListener() {
        val prefs = getSharedPreferences(PaymentNotificationListener.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(PaymentNotificationListener.KEY_ENABLED, true)) {
            stopSelf()
            return
        }

        val hasAccess = isNotificationListenerEnabled()
        val connected = PaymentNotificationListener.isConnected(this)
        if (hasAccess && !connected) {
            // La reconexión se solicita desde el propio NotificationListenerService
            // en onListenerDisconnected(). Aquí solo vigilamos y mostramos el estado,
            // evitando llamar a la API desde un componente que no es el listener.
        }

        updateNotification(hasAccess, connected)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun startAsForeground() {
        val notification = buildNotification(
            access = isNotificationListenerEnabled(),
            connected = PaymentNotificationListener.isConnected(this)
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: SecurityException) {
            setRunning(this, false)
            stopSelf()
        } catch (_: IllegalStateException) {
            setRunning(this, false)
            stopSelf()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pago Voz",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notificación permanente de Pago Voz"
                setShowBadge(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(access: Boolean, connected: Boolean): Notification =
        buildNotificationFor(this, access, connected)

    private fun updateNotification(access: Boolean, connected: Boolean) {
        try {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIFICATION_ID, buildNotification(access, connected))
        } catch (_: Exception) {
            // La notificación no debe tumbar el servicio ni la aplicación.
        }
    }

    companion object {
        private const val CHANNEL_ID = "pago_voz_watchdog"
        private const val NOTIFICATION_ID = 2001
        private const val CHECK_INTERVAL_MS = 60_000L

        fun updateNow(context: Context) {
            try {
                val access = isNotificationListenerEnabled(context)
                val connected = PaymentNotificationListener.isConnected(context)
                val manager = context.getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID, buildNotificationFor(context, access, connected))
            } catch (_: Exception) {
            }
        }

        private fun isNotificationListenerEnabled(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                "enabled_notification_listeners"
            ) ?: return false
            return enabled.contains(context.packageName)
        }

        private fun buildNotificationFor(context: Context, access: Boolean, connected: Boolean): Notification {
            val summary = PaymentNotificationListener.getTodaySummary(context)
            val text = "Pagos recibidos: ${summary.first}    Total: ${formatCentsStatic(summary.second)}"
            val openApp = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
            val pendingIntent = PendingIntent.getActivity(context, 2001, openApp, pendingFlags)
            val custom = android.widget.RemoteViews(context.packageName, R.layout.notification_payment).apply {
                setTextViewText(R.id.notification_title, "Pago Voz")
                setTextViewText(R.id.notification_count, "Pagos recibidos: ${summary.first}")
                setTextViewText(R.id.notification_total, "Total: ${formatCentsStatic(summary.second)}")
            }

            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.notification_icon)
                .setContentTitle("Pago Voz")
                .setContentText(text)
                .setCustomContentView(custom)
                .setCustomBigContentView(custom)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .build()
        }

        private fun formatCentsStatic(cents: Long): String =
            "S/ ${cents / 100L}.${(cents % 100L).toString().padStart(2, '0')}"

        private fun setRunning(context: Context, running: Boolean) {
            context.getSharedPreferences(PaymentNotificationListener.PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(PaymentNotificationListener.KEY_WATCHDOG_RUNNING, running).apply()
        }

        fun isRunning(context: Context): Boolean =
            context.getSharedPreferences(PaymentNotificationListener.PREFS, Context.MODE_PRIVATE)
                .getBoolean(PaymentNotificationListener.KEY_WATCHDOG_RUNNING, false)

        fun start(context: Context) {
            val intent = Intent(context, PaymentWatchdogService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, PaymentWatchdogService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
