# Yape Voz — primera versión

Esta aplicación está diseñada para Android y usa el acceso oficial de Android a las notificaciones.

- Filtra exclusivamente el paquete de Yape: `com.bcp.innovacxion.yapeapp`.
- No inicia sesión en Yape ni solicita tu contraseña.
- Lee en voz alta las notificaciones que parecen indicar un pago recibido.
- No pronuncia códigos de seguridad, OTP, PIN ni números largos.
- No anuncia cuando el teléfono está en silencio/vibración o en No molestar (cuando Android permite consultar ese estado).
- Incluye accesos para activar el acceso a notificaciones, quitar restricciones de batería y permitir consultar No molestar.

## Compilación

Abrir en Android Studio y esperar a que Gradle sincronice. Luego:
Build > Build APK(s)

## Importante

La primera versión necesita probarse con una notificación real de Yape, porque el texto exacto de las notificaciones puede variar por versión de Yape y por modelo de teléfono. El paquete actual de Yape Perú se verificó como `com.bcp.innovacxion.yapeapp`.
