package pe.yapevoz

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class YapeNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private val lastSpokenAt = AtomicLong(0)

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                tts?.language = Locale("es", "PE")
                tts?.setSpeechRate(1.0f)
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != YAPE_PACKAGE) return

        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        // MainActivity stores its switch in its private prefs, so use the service's
        // own default enabled state. The switch is mirrored below by a simple
        // service preference when the app is launched in the installed build.
        if (!prefs.getBoolean("enabled", true)) return

        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val raw = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString(". ")

        if (!looksLikePayment(raw)) return
        if (isSilentOrDnd()) return

        val cleaned = cleanForSpeech(raw)
        if (cleaned.isBlank()) return

        val now = System.currentTimeMillis()
        if (now - lastSpokenAt.get() < 2500) return
        lastSpokenAt.set(now)

        tts?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, "yape_payment")
    }

    private fun looksLikePayment(s: String): Boolean {
        val n = normalize(s)
        val money = Regex("""(?:s/|s\.|soles?)\s*\d""").containsMatchIn(n)
        val received = n.contains("recibiste") || n.contains("recibio") ||
                n.contains("recibiste un pago") || n.contains("te yapearon") ||
                n.contains("recibiste dinero")
        return money && received
    }

    private fun cleanForSpeech(s: String): String {
        var x = s
        // Never announce security codes / verification codes aloud.
        x = x.replace(Regex("(?i)(codigo|código)\\s*(de\\s*)?(seguridad|verificacion|verificación)?\\s*[:#-]?\\s*[A-Z0-9-]+"), "")
        x = x.replace(Regex("(?i)(clave|pin|otp)\\s*[:#-]?\\s*[A-Z0-9-]+"), "")
        x = x.replace(Regex("""\b\d{4,8}\b"""), "")
        x = x.replace(Regex("""\s+"""), " ").trim()

        // Make common Yape wording more natural for TTS.
        x = x.replace("S/", "soles ")
        x = x.replace("S/.", "soles ")
        x = x.replace("s/", "soles ")
        return "Yape recibido. $x"
    }

    private fun isSilentOrDnd(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return true

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: SecurityException) {
            false
        }
    }

    private fun normalize(s: String): String {
        return Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace("\\p{M}+".toRegex(), "")
    }

    companion object {
        const val YAPE_PACKAGE = "com.bcp.innovacxion.yapeapp"

        fun testSpeech(context: Context) {
            val t = TextToSpeech(context) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    t.language = Locale("es", "PE")
                    t.speak("Prueba de Yape Voz. El lector de pagos está funcionando.", TextToSpeech.QUEUE_FLUSH, null, "test")
                }
            }
        }
    }
}
