package com.hablame.app

import android.app.Notification
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class HablameNotificationListener : NotificationListenerService() {
    private val worker: ExecutorService by lazy { Executors.newSingleThreadExecutor() }

    companion object {
        private val recent = ConcurrentHashMap<String, Long>()

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(":").any {
                try { ComponentName.unflattenFromString(it) == ComponentName(context, HablameNotificationListener::class.java) }
                catch (_: Exception) { false }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Keep the selected TTS engine initialized while the listener is alive,
        // so a locked-screen notification can be spoken without waiting for the UI.
        try { TtsEngine.ensureCurrentEngine(applicationContext) } catch (_: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.getBool(this, "service_enabled", true)) return
        if (sbn.packageName == packageName) return
        val app = applicationContext
        worker.execute {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Hablame:NotificationSpeech")
            try {
                wakeLock.acquire(60000L)
                processNotification(app, sbn)
            } catch (_: Exception) {
                // Never let one notification stop the listener worker.
            } finally {
                try { if (wakeLock.isHeld) wakeLock.release() } catch (_: Exception) { }
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun processNotification(context: Context, sbn: StatusBarNotification) {
        if (!Prefs.getBool(context, "service_enabled", true)) return
        val pkg = sbn.packageName
        val knownKey = "app_$pkg"
        val knownApps = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.facebook.katana",
            "com.instagram.android",
            "com.zhiliaoapp.musically",
            "com.google.android.apps.messaging",
            "com.google.android.gm"
        )

        if (pkg in knownApps) {
            if (!Prefs.getBool(context, knownKey, true)) return
        } else if (!Prefs.getBool(context, "read_other_apps", true)) {
            return
        }

        if (!canSpeak()) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = n.extras ?: Bundle()
        val title = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_TITLE))
        val text = TextCleaner.speakableContent(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)
        )
        val conversation = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))
        val isGroupConversation = isGroupConversation(extras, title, conversation)

        val key = "$pkg|$title|$conversation|$text"
        val now = System.currentTimeMillis()
        val old = recent[key]
        if (old != null && now - old < 5000L) return
        recent[key] = now
        recent.entries.removeIf { now - it.value > 15000L }

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.').ifBlank { "Aplicación" }
        }

        val readTitle = Prefs.getBool(context, "title_$pkg", true)
        val readContent = Prefs.getBool(context, "content_$pkg", true)
        val titlePart = if (readTitle && title.isNotBlank()) title else ""
        val contentPart = if (readContent && text.isNotBlank()) text else ""

        // Para conversaciones individuales: "WhatsApp de Gerardo".
        // Para grupos: "WhatsApp de Gerardo a Familia".
        // La misma regla se aplica a Telegram, Messenger y las demás apps.
        val intro = when {
            titlePart.isNotBlank() && isGroupConversation && conversation.isNotBlank() ->
                "$appName de $titlePart a $conversation"
            titlePart.isNotBlank() ->
                "$appName de $titlePart"
            isGroupConversation && conversation.isNotBlank() ->
                "$appName a $conversation"
            else ->
                appName
        }
        val speech = if (contentPart.isNotBlank()) "$intro. $contentPart" else intro

        if (speech.isNotBlank()) TtsEngine.speak(context, speech)
    }


    private fun isGroupConversation(
        extras: Bundle,
        title: String,
        conversation: String
    ): Boolean {
        // Android exposes this flag for MessagingStyle notifications when the
        // originating app marks the conversation as a group.
        if (extras.containsKey("android.isGroupConversation") &&
            extras.getBoolean("android.isGroupConversation", false)
        ) return true

        // WhatsApp, Telegram and Messenger frequently provide the group name
        // through EXTRA_CONVERSATION_TITLE without setting the flag. In that
        // case a different conversation title is the reliable group signal.
        if (conversation.isBlank()) return false
        if (conversation.equals(title, ignoreCase = true)) return false
        return true
    }

    private fun canSpeak(): Boolean {
        if (!Prefs.getBool(this, "normal_only", true)) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
