package pe.yapevoz

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class YapeNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private val lastSpokenAt = AtomicLong(0)

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) configureTts(tts)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Yape is an independent app from the BCP banking app.
        if (sbn.packageName != YAPE_PACKAGE) return

        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return
        if (isSilentOrDnd()) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
        val raw = listOf(title, text, bigText, subText)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(". ")

        val cleaned = cleanSecurityText(raw)
        if (!looksLikePayment(cleaned)) return

        val amount = extractAmount(cleaned) ?: return
        val sender = extractSenderName(cleaned)
        val nameMode = prefs.getString(KEY_NAME_MODE, NAME_FIRST) ?: NAME_FIRST
        val spokenName = sender?.let { formatName(it, nameMode) }

        val phrase = when {
            !spokenName.isNullOrBlank() -> "Recibiste un Yape de $spokenName por $amount."
            else -> "Recibiste un Yape por $amount."
        }

        val now = System.currentTimeMillis()
        if (now - lastSpokenAt.get() < 1800L) return
        lastSpokenAt.set(now)

        tts?.speak(phrase, TextToSpeech.QUEUE_FLUSH, null, "yape_payment")
    }

    private fun configureTts(engine: TextToSpeech?) {
        engine ?: return
        val spanish = listOf(Locale("es", "PE"), Locale("es", "ES"), Locale("es", "MX"))
        val voices = engine.voices.orEmpty()
        val bestVoice = voices
            .filter { voice -> spanish.any { it.language == voice.locale.language && it.country == voice.locale.country } }
            .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
            .firstOrNull()

        if (bestVoice != null) engine.voice = bestVoice else engine.language = Locale("es", "PE")
        engine.setSpeechRate(0.98f)
        engine.setPitch(1.0f)
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }

    private fun looksLikePayment(s: String): Boolean {
        val n = normalize(s)

        // Como ya filtramos por el paquete oficial de Yape, solo necesitamos
        // encontrar un monto. No exigimos una frase exacta porque Yape puede
        // cambiar el texto de la notificación.
        return Regex(
            """(?:s\s*/?\.?|soles?)\s*\d+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?\s*(?:soles?|s/)"""
        ).containsMatchIn(n)
    }

    private fun extractAmount(s: String): String? {
        val patterns = listOf(
            Regex(
                """(?i)(?:s\s*/?\.?|soles?)\s*([0-9]+(?:[.,][0-9]{1,2})?)"""
            ),
            Regex(
                """(?i)([0-9]+(?:[.,][0-9]{1,2})?)\s*(?:soles?|s/)"""
            ),
            Regex(
                """(?i)(?:por|de)\s*(?:s\s*/?\.?\s*)?([0-9]+(?:[.,][0-9]{1,2})?)"""
            )
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val value = match.groupValues[1].replace(',', '.')
            return "S/ $value"
        }

        return null
    }

    private fun extractSenderName(s: String): String? {
        val patterns = listOf(
            Regex("""(?i)(?:recibiste|recibio|recibió)\s+(?:un\s+)?(?:yape|pago)?\s*(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)(?=\s+(?:por|s/|soles?)\b|[.!]|$)"""),
            Regex("""(?i)(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)(?=\s+(?:te\s+(?:envio|envió|yapeo|yapeó)|por|s/|soles?)\b|[.!]|$)"""),
            Regex("""(?i)^([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)\s+te\s+(?:envio|envió|yapeo|yapeó)\b"""),
            Regex("""(?i)([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)\s+te\s+(?:envio|envió|yapeo|yapeó)\s+(?:S/|[0-9])"""),
            Regex("""(?i)te\s+(?:envio|envió|yapeo|yapeó)\s+(?:un\s+)?(?:yape\s+)?(?:de\s+)?([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)(?=\s+(?:por|S/|soles?)\b|[.!]|$)""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val name = match.groupValues[1]
                .trim()
                .replace(Regex("""\s+"""), " ")
                .trim('.', ',', ':', ';')

            if (isPlausibleName(name)) return name
        }

        return null
    }

    private fun isPlausibleName(name: String): Boolean {
        if (name.length !in 2..60) return false
        val n = normalize(name)
        val blocked = setOf("yape", "pago", "dinero", "tu", "un", "una", "el", "la", "te")
        return n !in blocked && n.split(' ').any { it.length >= 2 }
    }

    private fun formatName(name: String, mode: String): String {
        val parts = name.split(Regex("""\s+"""))
            .filter { it.isNotBlank() }
            .map { it.trim('.', ',', ':', ';') }
        if (parts.isEmpty()) return name

        return when (mode) {
            NAME_FULL -> parts.joinToString(" ")
            NAME_SURNAME_FIRST -> if (parts.size >= 2) parts.drop(1).joinToString(" ") + " " + parts.first() else parts.first()
            else -> parts.first()
        }
    }

    private fun cleanSecurityText(s: String): String {
        var x = s

        // La propia Yape indica que la notificación puede incluir un
        // código de seguridad de 3 dígitos. Lo eliminamos para que nunca
        // sea pronunciado, pero conservamos el monto.
        x = x.replace(
            Regex(
                """(?i)(c[oó]digo\s+(?:de\s+)?seguridad|clave|pin|otp)\s*[:#-]?\s*[A-Z0-9-]+"""
            ),
            ""
        )

        return x.replace(Regex("""\s+"""), " ").trim()
    }

    private fun isSilentOrDnd(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return true

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: SecurityException) {
            false
        }
    }

    private fun normalize(s: String): String {
        return Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace("""\p{M}+""".toRegex(), "")
    }

    companion object {
        const val YAPE_PACKAGE = "com.bcp.innovacxion.yapeapp"
        const val KEY_NAME_MODE = "name_mode"
        const val NAME_FIRST = "first"
        const val NAME_FULL = "full"
        const val NAME_SURNAME_FIRST = "surname_first"

        fun testSpeech(context: Context) {
            lateinit var testTts: TextToSpeech
            testTts = TextToSpeech(context) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    val voices = testTts.voices.orEmpty()
                    val best = voices
                        .filter { it.locale.language == "es" }
                        .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
                        .firstOrNull()
                    if (best != null) testTts.voice = best else testTts.language = Locale("es", "PE")
                    testTts.setSpeechRate(0.98f)
                    testTts.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    testTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { testTts.shutdown() }
                        override fun onError(utteranceId: String?) { testTts.shutdown() }
                    })
                    testTts.speak(
                        "Prueba de Yape Voz. El lector de pagos está funcionando.",
                        TextToSpeech.QUEUE_FLUSH, null, "test"
                    )
                }
            }
        }
    }
}
