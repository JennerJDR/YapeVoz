package pe.yapevoz

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var nameModeSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        enabledSwitch = findViewById(R.id.enabledSwitch)
        nameModeSpinner = findViewById(R.id.nameModeSpinner)

        val modes = listOf("Solo nombre", "Nombre y apellido", "Apellido y nombre")
        nameModeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, modes)
        val savedMode = getSharedPreferences("app", MODE_PRIVATE)
            .getString(YapeNotificationListener.KEY_NAME_MODE, YapeNotificationListener.NAME_FIRST)
        nameModeSpinner.setSelection(
            when (savedMode) {
                YapeNotificationListener.NAME_FULL -> 1
                YapeNotificationListener.NAME_SURNAME_FIRST -> 2
                else -> 0
            }
        )
        nameModeSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val value = when (position) {
                    1 -> YapeNotificationListener.NAME_FULL
                    2 -> YapeNotificationListener.NAME_SURNAME_FIRST
                    else -> YapeNotificationListener.NAME_FIRST
                }
                getSharedPreferences("app", MODE_PRIVATE).edit().putString(YapeNotificationListener.KEY_NAME_MODE, value).apply()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        enabledSwitch.isChecked = getSharedPreferences("app", MODE_PRIVATE)
            .getBoolean("enabled", true)
        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            getSharedPreferences("app", MODE_PRIVATE).edit().putBoolean("enabled", checked).apply()
            updateStatus()
        }

        findViewById<Button>(R.id.notificationsButton).setOnClickListener {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        findViewById<Button>(R.id.dndButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<Button>(R.id.testButton).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val listenerOk = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) == true

        status.text = buildString {
            append(if (listenerOk) "✓ Acceso a notificaciones activo\n" else "⚠ Falta acceso a notificaciones\n")
            append(if (batteryOk) "✓ Batería sin restricciones\n" else "⚠ Falta quitar restricción de batería\n")
            append(if (enabledSwitch.isChecked) "✓ Anuncio automático ACTIVADO" else "⏸ Anuncio automático PAUSADO")
        }
    }
}
