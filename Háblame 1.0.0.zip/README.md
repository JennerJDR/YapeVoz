# Háblame 1.0.0

Aplicación Android para anunciar llamadas entrantes y leer notificaciones seleccionadas mediante Text-to-Speech.

- Application ID: `com.hablame.app`
- Nombre: `Háblame`
- Versión: `1.0.0`
- Compile SDK: 35
- Java: 17
- Gradle: 8.9

## Compilación

El workflow `.github/workflows/build.yml` prepara Java 17, Android SDK 35 y Gradle 8.9, y ejecuta:

`gradle assembleDebug --no-daemon`

El APK se publica como artifact `Hablame-1.0.0-debug`.

## Diseño

`docs/diseno-oficial-hablame-1.0.0.png` conserva el boceto visual suministrado para esta versión.

## Firma

La compilación debug utiliza la firma debug de Android. Para una versión release actualizable entre versiones debe conservarse una keystore permanente y utilizarse mediante GitHub Secrets.
