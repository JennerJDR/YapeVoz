
package com.hablame.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioManager
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import android.telephony.TelephonyManager
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.Normalizer
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.regex.Pattern

object Prefs {
    private const val P = "hablame_prefs"
    private fun p(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)
    fun getBool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun getInt(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun getString(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun setString(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

object TextCleaner {
    private val emoji = Pattern.compile("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}\\x{1F3FB}-\\x{1F3FF}]")
    fun cleanName(value: CharSequence?): String {
        if (value == null) return ""
        val s = emoji.matcher(value.toString()).replaceAll("")
        return s.replace(Regex("[\\p{So}\\p{Cn}]"), "").replace(Regex("\\s+"), " ").trim()
    }
    fun cleanContent(value: CharSequence?, keepEmojis: Boolean): String {
        if (value == null) return ""
        var s = value.toString().replace(Regex("\\s+"), " ").trim()
        if (!keepEmojis) s = emoji.matcher(s).replaceAll("")
        return s
    }
}

object TtsEngine {
    private var tts: TextToSpeech? = null
    private var ready = false
    fun init(c: Context, onReady: (() -> Unit)? = null) {
        if (tts != null) { onReady?.invoke(); return }
        tts = TextToSpeech(c.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                tts?.language = Locale("es", "ES")
                val voiceName = Prefs.getString(c, "tts_voice", "")
                if (voiceName.isNotEmpty()) {
                    tts?.voices?.firstOrNull { it.name == voiceName }?.let { tts?.voice = it }
                }
            }
            onReady?.invoke()
        }
    }
    fun speak(c: Context, text: String) {
        if (text.isBlank()) return
        init(c)
        if (!ready) return
        val vol = Prefs.getInt(c, "tts_volume", 70) / 100f
        val params = android.os.Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol) }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "hablame_${System.currentTimeMillis()}")
    }
    fun stop() { tts?.stop() }
    fun voices(): List<TextToSpeech.Voice> = tts?.voices?.toList() ?: emptyList()
    fun setVoice(v: TextToSpeech.Voice) { if (ready) tts?.voice = v }
}

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var statusPill: TextView
    private var current = "inicio"

    private val blue by lazy { ContextCompat.getColor(this, R.color.hab_blue) }
    private val green by lazy { ContextCompat.getColor(this, R.color.hab_green) }
    private val textColor by lazy { ContextCompat.getColor(this, R.color.hab_text) }
    private val muted by lazy { ContextCompat.getColor(this, R.color.hab_muted) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.page_container)
        statusPill = findViewById(R.id.service_status)
        setupBottomNav()
        TtsEngine.init(this)
        refreshStatus()
        showPage("inicio")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun setupBottomNav() {
        findViewById<View>(R.id.nav_home).setOnClickListener { showPage("inicio") }
        findViewById<View>(R.id.nav_apps).setOnClickListener { showPage("apps") }
        findViewById<View>(R.id.nav_calls).setOnClickListener { showPage("calls") }
        findViewById<View>(R.id.nav_voice).setOnClickListener { showPage("voice") }
        findViewById<View>(R.id.nav_permissions).setOnClickListener { showPage("permissions") }
    }

    private fun refreshStatus() {
        val notificationOk = HablameNotificationListener.isEnabled(this)
        val phoneOk = hasPermission(Manifest.permission.READ_PHONE_STATE)
        val contactsOk = hasPermission(Manifest.permission.READ_CONTACTS)
        val ok = notificationOk && phoneOk && contactsOk
        statusPill.text = if (ok) "✓  Servicio activo" else "⚠  Requiere permisos"
        statusPill.setTextColor(Color.WHITE)
        statusPill.setBackgroundResource(if (ok) R.drawable.bg_green_pill else R.drawable.bg_red_pill)
    }

    private fun showPage(page: String) {
        current = page
        content.removeAllViews()
        when(page) {
            "inicio" -> homePage()
            "apps" -> appsPage()
            "calls" -> callsPage()
            "voice" -> voicePage()
            "permissions" -> permissionsPage()
        }
    }

    private fun homePage() {
        addSectionTitle("Háblame")
        addText("Lee en voz alta llamadas y notificaciones para que estés siempre informado, sin mirar tu teléfono.", 14, muted)
        val status = card()
        val title = text("Estado de Háblame", 17, textColor, true)
        status.addView(title)
        status.addView(space(5))
        status.addView(text("Llamadas y notificaciones se anuncian según tu configuración.", 13, muted))
        content.addView(status)
        addSpacer(10)
        homeActionCard(R.drawable.ic_call, "Llamadas", if (hasPermission(Manifest.permission.READ_PHONE_STATE)) "Activadas" else "Requiere permiso") { showPage("calls") }
        homeActionCard(R.drawable.ic_bell, "Notificaciones", if (HablameNotificationListener.isEnabled(this)) "Activadas" else "Requiere acceso") { showPage("apps") }
        val b = button("Desactivar Háblame")
        b.setOnClickListener {
            TtsEngine.stop()
            Toast.makeText(this, "Háblame detenido por esta sesión.", Toast.LENGTH_SHORT).show()
        }
        content.addView(b)
        addSpacer(8)
        homeActionCard(R.drawable.ic_settings, "Acceso rápido a permisos", "Todo en orden") { showPage("permissions") }
    }

    private fun appsPage() {
        addSectionTitle("Aplicaciones")
        addText("Selecciona qué aplicaciones quieres que lea Háblame.", 14, muted)
        val apps = listOf(
            Triple("WhatsApp","com.whatsapp",true),
            Triple("Telegram","org.telegram.messenger",true),
            Triple("Messenger","com.facebook.orca",true),
            Triple("Facebook","com.facebook.katana",true),
            Triple("Instagram","com.instagram.android",false),
            Triple("TikTok","com.zhiliaoapp.musically",false),
            Triple("Mensajes","com.google.android.apps.messaging",false),
            Triple("Gmail","com.google.android.gm",false)
        )
        apps.forEach { (name,pkg,supported) ->
            appRow(name,pkg,supported)
        }
    }

    private fun appRow(name: String, pkg: String, supported: Boolean) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        val lp = LinearLayout.LayoutParams(dp(40),dp(40))
        lp.marginEnd = dp(12)
        icon.layoutParams = lp
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
        catch (_: Exception) { icon.setImageResource(R.drawable.ic_bell) }
        row.addView(icon)
        val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        label.addView(text(name, 15, textColor, true))
        if (!supported) label.addView(text("No disponible en esta versión", 11, muted))
        row.addView(label)
        val sw = androidx.appcompat.widget.SwitchCompat(this)
        sw.isChecked = supported && Prefs.getBool(this, "app_$pkg", true)
        sw.isEnabled = supported
        sw.setOnCheckedChangeListener { _, v -> if (supported) Prefs.setBool(this, "app_$pkg", v) }
        row.addView(sw)
        c.addView(row)
        c.setOnClickListener { if (supported) appDetail(name,pkg) else Toast.makeText(this,"Esta aplicación no está habilitada en Háblame 1.0.0.",Toast.LENGTH_SHORT).show() }
        content.addView(c)
        addSpacer(7)
    }

    private fun appDetail(name: String, pkg: String) {
        content.removeAllViews()
        addBack("Aplicaciones") { showPage("apps") }
        val title = addSectionTitle(name)
        addText("Configura cómo se anuncian las notificaciones de $name.", 14, muted)
        settingSwitch("Activada", Prefs.getBool(this,"app_$pkg",true), "app_$pkg") { }
        if (name == "Facebook") {
            settingSwitch("Comentarios — leer contenido", Prefs.getBool(this,"fb_comments",true), "fb_comments") { }
            settingSwitch("Me gusta", Prefs.getBool(this,"fb_likes",true), "fb_likes") { }
            settingSwitch("Otras notificaciones", Prefs.getBool(this,"fb_other",true), "fb_other") { }
        } else {
            settingSwitch("Leer contenido del mensaje", Prefs.getBool(this,"content_$pkg",true), "content_$pkg") { }
            settingSwitch("Leer nombre del grupo", Prefs.getBool(this,"group_$pkg",true), "group_$pkg") { }
            addSubTitle("Tipo de mensajes")
            val radio = RadioGroup(this)
            radio.orientation = RadioGroup.VERTICAL
            val all = RadioButton(this).apply { text = "Todos los mensajes"; isChecked = Prefs.getBool(this@MainActivity,"all_$pkg",true) }
            val individual = RadioButton(this).apply { text = "Solo mensajes individuales"; isChecked = !all.isChecked }
            radio.addView(all); radio.addView(individual)
            radio.setOnCheckedChangeListener { _, id ->
                Prefs.setBool(this,"all_$pkg",id == all.id)
            }
            content.addView(radio)
            addSubTitle("Reglas avanzadas")
            val adv = card()
            adv.addView(text("Los mensajes repetidos en pocos segundos se anuncian una sola vez.",13,muted))
            content.addView(adv)
        }
    }

    private fun callsPage() {
        addSectionTitle("Llamadas")
        addText("Configura cómo quieres que se anuncien las llamadas entrantes.",14,muted)
        settingSwitch("Contactos guardados — leer el nombre del contacto", Prefs.getBool(this,"call_contact_name",true), "call_contact_name") { }
        addSubTitle("Números desconocidos")
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val a = RadioButton(this).apply { id=View.generateViewId(); text="Leer el número" }
        val b = RadioButton(this).apply { id=View.generateViewId(); text="Decir “número desconocido”" }
        val c = RadioButton(this).apply { id=View.generateViewId(); text="No anunciar" }
        group.addView(a); group.addView(b); group.addView(c)
        when(Prefs.getString(this,"unknown_mode","number")) {
            "unknown" -> b.isChecked=true
            "none" -> c.isChecked=true
            else -> a.isChecked=true
        }
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setString(this,"unknown_mode",when(id){b.id->"unknown";c.id->"none";else->"number"})
        }
        content.addView(group)
        addSubTitle("Otras opciones")
        val info=card()
        info.addView(text("Leer llamadas en silencio/vibración",14,textColor,true))
        info.addView(text("No disponible: Háblame respeta el modo de sonido y No molestar.",12,muted))
        content.addView(info)
    }

    private fun voicePage() {
        addSectionTitle("Voz")
        addText("Configura la voz y las opciones de lectura.",14,muted)
        val c=card()
        c.addView(text("Selecciona una voz",13,textColor,true))
        val spinner=Spinner(this)
        val labels=mutableListOf<String>()
        val voices=TtsEngine.voices()
        voices.forEach { labels.add("${it.locale.displayLanguage} (${it.locale.displayCountry.ifEmpty{it.locale.country}}) — ${it.name.substringAfterLast(".")}")}
        if(labels.isEmpty()) labels.add("Español (España) - Voz del sistema")
        val adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,labels)
        spinner.adapter=adapter
        c.addView(spinner)
        val current=Prefs.getString(this,"tts_voice","")
        val idx=voices.indexOfFirst{it.name==current}
        if(idx>=0) spinner.setSelection(idx)
        spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?) {}
            override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){
                if(pos<voices.size){ TtsEngine.setVoice(voices[pos]); Prefs.setString(this@MainActivity,"tts_voice",voices[pos].name)}
            }
        }
        val test=button("▶  Probar voz")
        test.setOnClickListener{ TtsEngine.speak(this,"Esta es una prueba de voz de Háblame.") }
        c.addView(test)
        content.addView(c)
        addSpacer(8)
        val vol=card()
        vol.addView(text("Volumen de notificaciones",13,textColor,true))
        val seek=SeekBar(this)
        seek.max=100; seek.progress=Prefs.getInt(this,"tts_volume",70)
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){ if(f) Prefs.setInt(this@MainActivity,"tts_volume",p.coerceAtLeast(1)) }
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })
        vol.addView(seek)
        content.addView(vol)
        settingSwitch("Solo en modo sonido normal", Prefs.getBool(this,"normal_only",true), "normal_only") { }
        addText("No hablar en silencio, vibración o No molestar.",12,muted)
        settingSwitch("Interpretación de emojis en mensajes", Prefs.getBool(this,"content_emojis",false), "content_emojis") { }
        addText("Si está desactivado, se limpian emojis del contenido.",12,muted)
    }

    private fun permissionsPage() {
        addSectionTitle("Permisos")
        addText("Necesitamos estos permisos para que Háblame funcione correctamente.",14,muted)
        permissionRow("Acceso a notificaciones", HablameNotificationListener.isEnabled(this)) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        permissionRow("Notificaciones de Háblame", hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        permissionRow("Batería sin restricciones", !isBatteryOptimized()) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
            catch (_:Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        permissionRow("Inicio automático", true) {
            Toast.makeText(this,"El autoinicio depende del fabricante. Abre la configuración del sistema si tu teléfono la ofrece.",Toast.LENGTH_LONG).show()
        }
        permissionRow("Teléfono", hasPermission(Manifest.permission.READ_PHONE_STATE)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_CALL_LOG), 21)
        }
        permissionRow("Contactos", hasPermission(Manifest.permission.READ_CONTACTS)) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
        }
        permissionRow("Texto a voz", true) {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch(_:Exception) { }
        }
    }

    private fun permissionRow(title:String, ok:Boolean, action:()->Unit) {
        val c=card()
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val icon=ImageView(this); icon.setImageResource(if(ok)R.drawable.ic_shield else R.drawable.ic_bell)
        row.addView(icon,LinearLayout.LayoutParams(dp(36),dp(36)))
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        col.addView(text(title,14,textColor,true))
        col.addView(text(if(ok)"Permitido" else "Requiere atención",12,if(ok)green else ContextCompat.getColor(this,R.color.hab_red)))
        row.addView(col)
        row.addView(text(if(ok)"✓" else "›",20,if(ok)green else blue,true))
        c.addView(row); c.setOnClickListener{action()}; content.addView(c); addSpacer(7)
    }

    private fun settingSwitch(label:String, checked:Boolean, key:String, onChanged:(Boolean)->Unit) {
        val c=card()
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        row.addView(text(label,14,textColor,true),LinearLayout.LayoutParams(0,-2,1f))
        val sw=androidx.appcompat.widget.SwitchCompat(this)
        sw.isChecked=checked
        sw.setOnCheckedChangeListener{_,v->Prefs.setBool(this,key,v);onChanged(v)}
        row.addView(sw); c.addView(row); content.addView(c); addSpacer(7)
    }

    private fun homeActionCard(iconRes:Int,title:String,sub:String,onClick:()->Unit){
        val c=card(); val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val icon=ImageView(this); icon.setImageResource(iconRes); row.addView(icon,LinearLayout.LayoutParams(dp(42),dp(42)))
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
        col.addView(text(title,15,textColor,true)); col.addView(text(sub,12,green))
        row.addView(col); row.addView(text("✓",20,green,true)); c.addView(row); c.setOnClickListener{onClick()}; content.addView(c); addSpacer(7)
    }

    private fun addBack(label:String,onClick:()->Unit){
        val b=TextView(this).apply{ text="‹  $label"; textSize=14f; setTextColor(blue); setPadding(0,4,0,12); setOnClickListener{onClick()} }
        content.addView(b)
    }
    private fun addSectionTitle(s:String):TextView{val t=text(s,25,textColor,true); t.setPadding(0,4,0,4); content.addView(t); return t}
    private fun addSubTitle(s:String){content.addView(text(s,14,textColor,true)); addSpacer(4)}
    private fun addText(s:String,size:Int,color:Int){content.addView(text(s,size,color,false)); addSpacer(7)}
    private fun addSpacer(n:Int){content.addView(space(n))}
    private fun text(s:String,size:Int,color:Int,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size.toFloat();setTextColor(color);if(bold)setTypeface(typeface,android.graphics.Typeface.BOLD);setPadding(2,2,2,2)}
    private fun space(h:Int)=Space(this).apply{layoutParams=LinearLayout.LayoutParams(1,dp(h))}
    private fun card()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;background=getDrawable(R.drawable.bg_card);setPadding(dp(14),dp(12),dp(14),dp(12));layoutParams=LinearLayout.LayoutParams(-1,-2)}
    private fun button(label:String)=Button(this).apply{text=label;textSize=14f;setTextColor(Color.WHITE);background=getDrawable(R.drawable.bg_blue_button);isAllCaps=false;minHeight=dp(48)}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun hasPermission(p:String)=ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED
    private fun isBatteryOptimized():Boolean{val pm=getSystemService(POWER_SERVICE) as android.os.PowerManager;return !pm.isIgnoringBatteryOptimizations(packageName)}
}
