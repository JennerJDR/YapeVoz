
package com.hablame.app

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Bundle
import android.media.AudioManager
import android.app.NotificationManager
import java.util.concurrent.ConcurrentHashMap

class HablameNotificationListener : NotificationListenerService() {
    companion object {
        private val recent = ConcurrentHashMap<String, Long>()
        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(":").any {
                try { ComponentName.unflattenFromString(it) == ComponentName(context, HablameNotificationListener::class.java) }
                catch (_: Exception) { false }
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        val supported = setOf("com.whatsapp","org.telegram.messenger","com.facebook.orca","com.facebook.katana")
        if (pkg !in supported) return

        val enabledKey = "app_$pkg"
        if (!Prefs.getBool(this, enabledKey, true)) return

        if (!canSpeak()) return

        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = n.extras ?: Bundle()
        val title = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_TITLE))
        val text = TextCleaner.cleanContent(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT),
            Prefs.getBool(this, "content_emojis", false)
        )
        val conversation = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))

        val key = "$pkg|$title|$conversation|$text"
        val now = System.currentTimeMillis()
        val old = recent[key]
        if (old != null && now - old < 5000L) return
        recent[key] = now
        recent.entries.removeIf { now - it.value > 15000L }

        val appName = when(pkg) {
            "com.whatsapp" -> "WhatsApp"
            "org.telegram.messenger" -> "Telegram"
            "com.facebook.orca" -> "Messenger"
            else -> "Facebook"
        }

        val speech = if (pkg == "com.facebook.katana") {
            if (!Prefs.getBool(this,"fb_other",true) && text.isBlank()) return
            buildFacebookSpeech(title, text)
        } else {
            val readContent = Prefs.getBool(this, "content_$pkg", true)
            val readGroup = Prefs.getBool(this, "group_$pkg", true)
            val who = if (title.isBlank()) "alguien" else title
            val base = if (conversation.isNotBlank() && readGroup) {
                "$appName de $who a $conversation"
            } else {
                "$appName de $who"
            }
            if (readContent && text.isNotBlank()) "$base. $text" else base
        }

        if (speech.isNotBlank()) TtsEngine.speak(this, speech)
    }

    private fun buildFacebookSpeech(title: String, text: String): String {
        val t = title.ifBlank { "Facebook" }
        return if (text.isBlank()) t else "$t. $text"
    }

    private fun canSpeak(): Boolean {
        if (!Prefs.getBool(this, "normal_only", true)) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
