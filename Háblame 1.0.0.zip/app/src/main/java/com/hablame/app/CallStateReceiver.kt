
package com.hablame.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.app.NotificationManager
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

class CallStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) return
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return

        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        if (state != TelephonyManager.EXTRA_STATE_RINGING) return

        if (Prefs.getBool(context, "normal_only", true)) {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) return
        }

        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
        val speech = buildSpeech(context, number)
        if (speech.isNotBlank()) TtsEngine.speak(context, speech)
    }

    private fun buildSpeech(context: Context, number: String?): String {
        val contactName = if (!number.isNullOrBlank() &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            lookupContact(context, number)
        } else null

        if (!contactName.isNullOrBlank() && Prefs.getBool(context,"call_contact_name",true)) {
            return "Llamada entrante de ${TextCleaner.cleanName(contactName)}"
        }

        return when (Prefs.getString(context,"unknown_mode","number")) {
            "unknown" -> "Llamada entrante de número desconocido"
            "none" -> ""
            else -> {
                val n = number?.trim().orEmpty()
                if (n.isBlank()) "Llamada entrante de número desconocido"
                else "Llamada entrante del $n"
            }
        }
    }

    private fun lookupContact(context: Context, number: String): String? {
        return try {
            val uri = ContactsContract.PhoneLookup.CONTENT_FILTER_URI.buildUpon()
                .appendPath(android.net.Uri.encode(number)).build()
            context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }
}
