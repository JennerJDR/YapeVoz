package pe.pagovoz

import android.Manifest
import android.app.Dialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences(PaymentNotificationListener.PREFS, MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var screen = 0
    private var permissionFlowBusy = false

    private val purple = Color.rgb(101, 37, 194)
    private val purpleDark = Color.rgb(48, 14, 105)
    private val purpleSoft = Color.rgb(244, 238, 255)
    private val green = Color.rgb(17, 184, 105)
    private val greenDark = Color.rgb(17, 129, 75)
    private val lightBg = Color.rgb(247, 246, 251)
    private val lightText = Color.rgb(29, 27, 35)
    private val muted = Color.rgb(105, 100, 116)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        PaymentNotificationListener.syncDefaultVoice(this)
        PaymentWatchdogService.start(this)
        window.decorView.postDelayed({ continuePermissionFlow() }, 500)
    }

    override fun onResume() {
        super.onResume()
        if (!permissionFlowBusy) window.decorView.postDelayed({ continuePermissionFlow() }, 350)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(lightBg)
        }

        if (screen == 0) {
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(18), dp(24), dp(18), dp(18))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(purple, purpleDark)
                ).apply {
                    cornerRadii = floatArrayOf(0f,0f,0f,0f,dp(26).toFloat(),dp(26).toFloat(),dp(26).toFloat(),dp(26).toFloat())
                }
            }

            val logo = ImageView(this).apply {
                setImageResource(R.drawable.pago_voz_mark)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            header.addView(logo, LinearLayout.LayoutParams(dp(142), dp(142)).apply { topMargin = dp(2) })

            header.addView(TextView(this).apply {
                text = "Tu asistente de cobros"
                textSize = 17f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
            header.addView(TextView(this).apply {
                text = "Te anuncia tus pagos por voz"
                textSize = 13f
                setTextColor(Color.rgb(235, 225, 255))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(25)))

            root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(245)))
        } else {
            val strip = TextView(this).apply {
                text = if (screen == 1) "Configuración" else "Resumen"
                textSize = 20f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), 0, dp(20), 0)
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(purple, purpleDark)
                )
            }
            root.addView(strip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)))
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(7))
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
        }
        nav.addView(navButton("⌂\nInicio", 0), LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(navButton("⚙\nConfiguración", 1), LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(navButton("ⓘ\nResumen", 2), LinearLayout.LayoutParams(0, dp(58), 1f))
        root.addView(nav)
        setContentView(root)
        show(screen)
    }

    private fun navButton(label: String, target: Int): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setOnClickListener { show(target) }
        setTextColor(if (screen == target) purple else muted)
    }

    private fun show(which: Int) {
        screen = which
        content.removeAllViews()
        when (which) { 0 -> home(); 1 -> settings(); else -> summary() }
    }

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(color)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(Color.WHITE, 18)
        elevation = dp(1).toFloat()
    }

    private fun title(text: String, size: Float = 27f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(lightText)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun subtitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(muted)
        setPadding(0, dp(3), 0, 0)
    }

    private fun gap(h: Int = 12) { content.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun home() {
        content.addView(title("Fuentes de pago", 20f))
        content.addView(subtitle("Activa o desactiva cada fuente por separado."))
        gap(12)
        sourceCard("Yape", PaymentNotificationListener.KEY_YAPE_ENABLED, R.drawable.yape_icon, purple)
        gap(10)
        sourceCard("Banco Falabella", PaymentNotificationListener.KEY_FALABELLA_ENABLED, R.drawable.falabella_icon, green)
        gap(14)
        val info = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = "●"; textSize = 24f; setTextColor(green); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(36), dp(36)))
        val infoText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val connected = PaymentNotificationListener.isConnected(this@MainActivity)
        infoText.addView(TextView(this).apply {
            text = if (connected) "Lector conectado" else "Lector pendiente"
            textSize = 16f
            setTextColor(if (connected) greenDark else muted)
            setTypeface(typeface, Typeface.BOLD)
        })
        infoText.addView(subtitle(if (connected) "Escuchando notificaciones de pagos" else "Revisa los permisos en Configuración"))
        row.addView(infoText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        info.addView(row)
        content.addView(info)
    }

    private fun sourceCard(label: String, key: String, iconRes: Int, accent: Int) {
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(ImageView(this).apply {
            setImageResource(iconRes)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(64), dp(64)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14),0,dp(8),0) }
        val status = TextView(this).apply { textSize = 13f; setTypeface(typeface, Typeface.BOLD) }
        texts.addView(TextView(this).apply {
            text = label; textSize = 17f
            setTextColor(lightText); setTypeface(typeface, Typeface.BOLD)
        })
        texts.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(28)))
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this)
        fun applyState(checked: Boolean) {
            status.text = if (checked) "Activo" else "Inactivo"
            status.setTextColor(if (checked) green else muted)
            sw.thumbTintList = ColorStateList.valueOf(if (checked) Color.WHITE else Color.rgb(230,228,233))
            sw.trackTintList = ColorStateList.valueOf(if (checked) green else Color.rgb(190,187,196))
        }
        val active = prefs.getBoolean(key, true)
        sw.isChecked = active
        applyState(active)
        sw.setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply(); applyState(checked) }
        row.addView(sw)
        c.addView(row)
        content.addView(c)
    }

    private fun settings() {
        sectionLabel("Voz")
        val audio = card()
        settingRow(audio, "🔊", "Volumen de notificaciones", "Controla el volumen de los anuncios") { showNotificationVolume() }
        divider(audio)
        settingRow(audio, "🔈", "Voz", "Configurar Texto a voz (TTS) de Android") { openTtsSettings() }
        divider(audio)
        settingRow(audio, "👤", "Cómo pronunciar el nombre", nameModeSummary()) { showNameModeDialog() }
        content.addView(audio)

        gap(14)
        sectionLabel("Información del pago")
        val payment = card()
        switchRow(payment, "Monto", PaymentNotificationListener.KEY_READ_AMOUNT, true)
        divider(payment)
        switchRow(payment, "Código de seguridad", PaymentNotificationListener.KEY_READ_CODE, false)
        content.addView(payment)

        gap(14)
        sectionLabel("Notificaciones")
        val other = card()
        switchRow(other, "No molestar / Modo silencio", PaymentNotificationListener.KEY_RESPECT_SILENT, true)
        content.addView(other)

        gap(14)
        val permissions = card()
        settingRow(permissions, "🛡", "Permisos", "Configura todos los permisos necesarios") { showPermissions() }
        content.addView(permissions)

        gap(14)
        val test = Button(this).apply {
            text = "▶  Probar voz"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            isAllCaps = false
            background = rounded(purple, 18)
            setOnClickListener { PaymentNotificationListener.testSpeech(this@MainActivity) }
        }
        content.addView(test, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
    }

    private fun sectionLabel(text: String) {
        content.addView(TextView(this).apply {
            this.text = text; textSize = 18f
            setTextColor(lightText)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(8))
        })
    }

    private fun settingRow(parent: LinearLayout, icon: String, label: String, sub: String, click: () -> Unit) {
        parent.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(3), 0, dp(3))
            setOnClickListener { click() }
            addView(TextView(this@MainActivity).apply { text = icon; textSize = 23f; gravity = Gravity.CENTER; setTextColor(purple) }, LinearLayout.LayoutParams(dp(42), dp(58)))
            val box = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
            box.addView(TextView(this@MainActivity).apply { text = label; textSize = 15f; setTextColor(lightText); setTypeface(typeface, Typeface.BOLD) })
            box.addView(TextView(this@MainActivity).apply { text = sub; textSize = 12f; setTextColor(muted); setPadding(0, dp(2), 0, 0) })
            addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(this@MainActivity).apply { text = "›"; textSize = 28f; setTextColor(muted); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(30), dp(58)))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))
    }

    private fun switchRow(parent: LinearLayout, label: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        val text = TextView(this).apply { text = label; textSize = 15f; setTypeface(typeface, Typeface.BOLD) }
        row.addView(text, LinearLayout.LayoutParams(0, dp(50), 1f))
        val sw = Switch(this)
        fun update(checked: Boolean) {
            text.setTextColor(if (checked) purple else muted)
            sw.thumbTintList = ColorStateList.valueOf(if (checked) Color.WHITE else Color.rgb(230,228,233))
            sw.trackTintList = ColorStateList.valueOf(if (checked) purple else Color.rgb(190,187,196))
        }
        val checked = prefs.getBoolean(key, default)
        sw.isChecked = checked; update(checked)
        sw.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply(); update(v) }
        row.addView(sw)
        parent.addView(row)
    }

    private fun divider(parent: LinearLayout) { parent.addView(View(this).apply { setBackgroundColor(Color.rgb(232,228,238)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))) }

    private fun nameModeSummary(): String = if (prefs.getString(PaymentNotificationListener.KEY_NAME_MODE, PaymentNotificationListener.NAME_FIRST) == PaymentNotificationListener.NAME_FULL) "Nombre y apellido" else "Solo nombre"

    private fun showNameModeDialog() {
        val values = arrayOf("Solo nombre", "Nombre y apellido")
        val checked = if (prefs.getString(PaymentNotificationListener.KEY_NAME_MODE, PaymentNotificationListener.NAME_FIRST) == PaymentNotificationListener.NAME_FULL) 1 else 0
        showChoiceDialog("Cómo pronunciar el nombre", values, checked) { which ->
            prefs.edit().putString(PaymentNotificationListener.KEY_NAME_MODE, if (which == 1) PaymentNotificationListener.NAME_FULL else PaymentNotificationListener.NAME_FIRST).apply()
            show(1)
        }
    }

    private fun showNotificationVolume() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val max = audio.getStreamMaxVolume(android.media.AudioManager.STREAM_NOTIFICATION)
        val current = audio.getStreamVolume(android.media.AudioManager.STREAM_NOTIFICATION)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(4)) }
        val value = TextView(this).apply { text = "${current * 100 / max}%"; gravity = Gravity.CENTER; textSize = 16f; setTextColor(purple); setTypeface(typeface, Typeface.BOLD) }
        val bar = SeekBar(this).apply { this.max = max; this.progress = current }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) audio.setStreamVolume(android.media.AudioManager.STREAM_NOTIFICATION, p, 0); value.text = "${p * 100 / max}%" }
            override fun onStartTrackingTouch(s: SeekBar?) = Unit
            override fun onStopTrackingTouch(s: SeekBar?) = Unit
        })
        box.addView(value); box.addView(bar)
        showCustomDialog("Volumen de notificaciones", box, "Listo", null)
    }

    private fun showPermissions() {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 22)
            setPadding(dp(20), dp(18), dp(20), dp(14))
        }
        box.addView(TextView(this).apply {
            text = "Permisos"
            textSize = 19f
            setTextColor(Color.BLACK)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(2), dp(2), dp(2), dp(10))
        })

        val items = listOf(
            Triple("Acceso a notificaciones", isNotificationListenerEnabled()) { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            Triple("Batería sin restricciones", isBatteryUnrestricted()) { requestBatteryOptimization() },
            Triple("Autoencendido / inicio automático", prefs.getBoolean("autostart_checked", false)) { openAutoStart() },
            Triple("Mostrar notificaciones", Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) { requestNotificationPermission() }
        )

        items.forEach { (label, active, action) ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
                setOnClickListener { dialog.dismiss(); action() }
            }
            row.addView(TextView(this).apply {
                text = "●"
                textSize = 18f
                setTextColor(if (active) green else Color.rgb(185,181,192))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(34), dp(50)))
            val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 15f
                setTextColor(Color.BLACK)
                setTypeface(typeface, Typeface.BOLD)
            })
            texts.addView(TextView(this@MainActivity).apply {
                text = if (active) "Activo" else "Pendiente"
                textSize = 12f
                setTextColor(if (active) greenDark else muted)
            })
            row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(this).apply { text = "›"; textSize = 26f; setTextColor(muted); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(28), dp(50)))
            box.addView(row)
        }

        val close = Button(this).apply {
            text = "Cerrar"
            isAllCaps = false
            textSize = 14f
            setTextColor(purple)
            setTypeface(typeface, Typeface.BOLD)
            background = rounded(Color.rgb(244, 238, 255), 14)
            setOnClickListener { dialog.dismiss() }
        }
        box.addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun openTtsSettings() {
        val actions = listOf(
            "com.android.settings.TTS_SETTINGS",
            "android.settings.TEXT_TO_SPEECH_SETTINGS",
            "android.settings.TTS_SETTINGS"
        )
        for (action in actions) {
            try {
                val intent = Intent(action)
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: Exception) { }
        }
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (_: Exception) {
        }
    }

    private fun summary() {
        content.addView(title("Historial de pagos", 22f))
        gap(10)
        val summary = PaymentNotificationListener.getTodaySummary(this)
        val stat = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stat.addView(statCard("${summary.first}", "Pagos hoy", purple), LinearLayout.LayoutParams(0, dp(108), 1f))
        stat.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        stat.addView(statCard(formatCents(summary.second), "Total hoy", green), LinearLayout.LayoutParams(0, dp(108), 1f))
        content.addView(stat)
        gap(14)

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(actionButton("Resetear contador") { confirmResetCounter() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        controls.addView(actionButton("Borrar historial") { confirmClearHistory() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(controls)
        gap(16)

        val history = readHistory()
        if (history.length() == 0) {
            val empty = card(); empty.addView(TextView(this).apply { text = "Todavía no hay pagos registrados."; textSize = 15f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20)) }); content.addView(empty); return
        }
        for (i in history.length() - 1 downTo 0) {
            content.addView(historyCard(history.optJSONObject(i) ?: continue)); gap(9)
            if (history.length() - i >= 12) break
        }
    }

    private fun actionButton(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); background = rounded(purple, 16); setOnClickListener { click() }
    }

    private fun statCard(value: String, label: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(accent, 18)
        addView(TextView(this@MainActivity).apply { text = value; textSize = 22f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER })
        addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
    }

    private fun historyCard(obj: org.json.JSONObject): LinearLayout {
        val source = obj.optString("source", "Yape")
        val amount = formatAmount(obj.optLong("soles", 0), obj.optInt("cents", 0))
        val name = obj.optString("name", "").ifBlank { "Sin nombre" }
        val code = obj.optString("code", "")
        val time = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(obj.optLong("timestamp", 0)))
        val accent = if (source == "Banco Falabella") green else purple
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = if (source == "Banco Falabella") "f." else "y"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD); background = rounded(accent, 16) }, LinearLayout.LayoutParams(dp(50), dp(50)))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        box.addView(TextView(this).apply { text = source; textSize = 14f; setTextColor(accent); setTypeface(typeface, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = "Recibiste $amount de $name"; textSize = 15f; setTextColor(lightText); setTypeface(typeface, Typeface.BOLD) })
        box.addView(TextView(this).apply { text = time; textSize = 12f; setTextColor(muted) })
        row.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener { showPaymentDetail(source, amount, name, code, time) }
        c.addView(row); return c
    }

    private fun showPaymentDetail(source: String, amount: String, name: String, code: String, time: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(10), dp(22), dp(4)) }
        val info = "Monto: $amount\nPagador: $name" + (if (code.isNotBlank()) "\nCódigo de seguridad: $code" else "") + "\nFecha: $time"
        box.addView(TextView(this).apply { text = info; textSize = 16f; setTextColor(Color.BLACK); setPadding(0, dp(8), 0, dp(8)) })
        showCustomDialog(source, box, "Cerrar", null)
    }

    private fun confirmResetCounter() {
        showCustomDialog("Resetear contador", TextView(this).apply { text = "¿Quieres reiniciar el contador de pagos de hoy? El historial se conservará."; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(18), dp(22), dp(8)) }, "Resetear") {
            prefs.edit().putLong(PaymentNotificationListener.KEY_COUNTER_RESET_AT, System.currentTimeMillis()).apply(); show(2)
        }
    }

    private fun confirmClearHistory() {
        showCustomDialog("Borrar historial", TextView(this).apply { text = "¿Seguro que quieres borrar todo el historial de pagos? Esta acción no se puede deshacer."; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(18), dp(22), dp(8)) }, "Borrar") {
            prefs.edit().putString(PaymentNotificationListener.KEY_PAYMENT_HISTORY, "[]").putLong(PaymentNotificationListener.KEY_COUNTER_RESET_AT, 0L).apply(); show(2)
        }
    }

    private fun readHistory(): JSONArray = try { JSONArray(prefs.getString(PaymentNotificationListener.KEY_PAYMENT_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
    private fun formatAmount(soles: Long, cents: Int): String = "S/ ${soles}.${cents.toString().padStart(2, '0')}"
    private fun formatCents(cents: Long): String = formatAmount(cents / 100L, (cents % 100L).toInt())

    private fun showCustomDialog(title: String, body: View, positive: String, onPositive: (() -> Unit)?) {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 22); setPadding(dp(20), dp(18), dp(20), dp(12)) }
        box.addView(TextView(this).apply { text = title; textSize = 19f; setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), dp(2), dp(2), dp(10)) })
        box.addView(body)
        val button = Button(this).apply { text = positive; isAllCaps = false; textSize = 14f; setTextColor(purple); setTypeface(typeface, Typeface.BOLD); background = rounded(Color.rgb(244,238,255), 14); setOnClickListener { dialog.dismiss(); onPositive?.invoke() } }
        box.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun showChoiceDialog(title: String, values: Array<String>, checked: Int, onSelected: (Int) -> Unit) {
        val dialog = Dialog(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 22); setPadding(dp(20), dp(18), dp(20), dp(12)) }
        box.addView(TextView(this).apply { text = title; textSize = 19f; setTextColor(Color.BLACK); setTypeface(typeface, Typeface.BOLD); setPadding(dp(2), dp(2), dp(2), dp(10)) })
        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        values.forEachIndexed { index, value ->
            val rb = RadioButton(this).apply { text = value; textSize = 15f; setTextColor(Color.BLACK); isChecked = index == checked; setPadding(0, dp(8), 0, dp(8)) }
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { _, id ->
            val index = group.indexOfChild(group.findViewById(id)); if (index >= 0) { dialog.dismiss(); onSelected(index) }
        }
        box.addView(group)
        dialog.setContentView(box)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun continuePermissionFlow() {
        if (permissionFlowBusy) return

        // En el primer inicio mostramos la ruta completa de configuración.
        // Si alguno ya está concedido, se salta automáticamente y continúa con el siguiente.
        if (!isNotificationListenerEnabled()) {
            showPermissionStep("1 de 4 · Acceso a notificaciones", "Pago Voz Pro necesita este acceso para detectar los pagos de Yape y Banco Falabella.", "Abrir configuración") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            showPermissionStep("2 de 4 · Mostrar notificaciones", "Permite las notificaciones de Pago Voz Pro para mantener visible el servicio que escucha los pagos.", "Permitir") { requestNotificationPermission() }
            return
        }
        if (!isBatteryUnrestricted()) {
            showPermissionStep("3 de 4 · Batería sin restricciones", "Permite que Pago Voz Pro siga funcionando en segundo plano para no perder pagos.", "Configurar") { requestBatteryOptimization() }
            return
        }
        if (isXiaomiFamily() && !prefs.getBoolean("autostart_checked", false)) {
            showPermissionStep("4 de 4 · Autoencendido", "En Xiaomi, Redmi o POCO activa el inicio automático para que el lector pueda volver a funcionar después de reiniciar el teléfono.", "Abrir configuración") {
                prefs.edit().putBoolean("autostart_checked", true).apply(); openAutoStart()
            }
            return
        }
        prefs.edit().putBoolean("setup_completed", true).apply()
    }

    private fun showPermissionStep(title: String, message: String, button: String, action: () -> Unit) {
        permissionFlowBusy = true
        val body = TextView(this).apply { text = message; textSize = 15f; setTextColor(Color.BLACK); setPadding(dp(22), dp(8), dp(22), dp(10)) }
        showCustomDialog(title, body, button) { permissionFlowBusy = false; action() }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.contains(packageName)
    }

    private fun isBatteryUnrestricted(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) pm.isIgnoringBatteryOptimizations(packageName) else true
    }

    private fun requestBatteryOptimization() {
        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
    }

    private fun isXiaomiFamily(): Boolean {
        val m = Build.MANUFACTURER.lowercase(Locale.ROOT)
        return m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")
    }

    private fun openAutoStart() {
        val i = Intent().apply { component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") }
        try { if (i.resolveActivity(packageManager) != null) { startActivity(i); return } } catch (_: Exception) { }
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }
}
