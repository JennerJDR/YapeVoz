# Yape Voz Pro 2.8.4 — firma permanente

Esta carpeta parte de la versión funcional 2.8.3 y cambia únicamente la versión a 2.8.4 y la firma de lanzamiento.

La firma permanente está en `yapevoz-pro-release.jks`.

Para futuras versiones se debe conservar el mismo archivo JKS y usar:
- alias: `yapevoz`
- contraseña del almacén: `YapeVozPro-2026-Firma-284`
- contraseña de la clave: `YapeVozPro-2026-Firma-284`

La versión 2.8.4 será la base de la cadena de actualizaciones firmadas.
