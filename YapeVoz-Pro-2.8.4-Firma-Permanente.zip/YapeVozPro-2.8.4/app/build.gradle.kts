plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pe.yapevoz"
    compileSdk = 35

    defaultConfig {
        applicationId = "pe.yapevoz"
        minSdk = 26
        targetSdk = 35
        versionCode = 40
        versionName = "2.8.4"
    }

    signingConfigs {
        create("release") {
            val keystoreFile = rootProject.file("yapevoz-pro-release.jks")
            storeFile = keystoreFile
            storePassword = providers.gradleProperty("YAPEVOZ_KEYSTORE_PASSWORD").orNull ?: "YapeVozPro-2026-Firma-284"
            keyAlias = providers.gradleProperty("YAPEVOZ_KEY_ALIAS").orNull ?: "yapevoz"
            keyPassword = providers.gradleProperty("YAPEVOZ_KEY_PASSWORD").orNull ?: "YapeVozPro-2026-Firma-284"
        }
    }

    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
