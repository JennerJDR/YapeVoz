package pe.pagovoz

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local diagnostic log containing behavior events only; never stores payment content or personal data. */
object DiagnosticLogger {
    private const val PREFS = "app"
    private const val ENABLED = "diagnostic_enabled"
    private const val FILE_NAME = "pagovoz_diagnostic.log"
    private val lock = Any()

    fun enabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, enabled).apply() }
    fun file(context: Context): File = File(context.filesDir, FILE_NAME)

    fun log(context: Context, event: String, source: String = "general") {
        if (!enabled(context)) return
        val safeEvent = event.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(48).ifBlank { "event" }
        val safeSource = when (source) { "Yape", "Banco Falabella" -> source; else -> "general" }
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        synchronized(lock) {
            try {
                val f = file(context)
                // Keep diagnostic storage bounded while preserving the latest events.
                if (f.exists() && f.length() > 512 * 1024) {
                    val old = f.readLines().takeLast(1500)
                    f.writeText(old.joinToString("\n", postfix = if (old.isEmpty()) "" else "\n"))
                }
                f.appendText("$time | $safeSource | $safeEvent\n")
            } catch (_: Exception) { }
        }
    }

    fun clear(context: Context) { try { file(context).delete() } catch (_: Exception) { } }
}
