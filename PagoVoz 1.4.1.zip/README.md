# PagoVoz 1.2.8 — proyecto de trabajo

Proyecto Android basado en PagoVoz 1.2.6.

## Cambios preparados
- versionName 1.2.8 / versionCode 18.
- Historial sin límite fijo de 500 registros, hasta que el usuario lo borre manualmente.
- Búsqueda del historial por fecha con selector de calendario y opción Ver todos.
- Reinicio del contador independiente del historial.
- Diagnóstico temporal local y opcional; registra eventos técnicos, no nombres, importes, códigos ni texto de notificaciones.
- Cola de anuncios de Falabella y reanudación de la cola tras anuncios prioritarios.
- Ajuste del reconocimiento del nombre de remitente de Falabella.
- Iconos originales de Yape/Falabella si están instalados.
- Número de versión centrado debajo de “Tu asistente de cobros”.
- Retroceso desde subpáginas vuelve a Inicio; doble retroceso en Inicio permite salir.
- Posición de desplazamiento independiente por pestaña.
- Interruptores unificados: verde al encender, gris oscuro al apagar.
- Lista limitada a marcas bancarias/financieras reconocidas; excluye Falabella.com y apps de voz como Yapay Voz.
- Activar una entidad financiera la mueve a “Aplicaciones visibles en Inicio” y crea su selector y prueba de voz independientes; apagarla la devuelve a la lista instalada.
- Detección por nombre/icono de algunas apps financieras instaladas; pueden mostrarse en Inicio y usar una regla inicial de transferencia.

## Limitación importante
Las aplicaciones adicionales se detectan por nombre/paquete y solo se anuncian cuando el usuario las activa y la notificación coincide con patrones iniciales de transferencia. No se ha podido probar cada entidad financiera ni ejecutar una compilación Android completa en este entorno. El APK debe compilarse en GitHub Actions y probarse en el teléfono antes de instalarlo. Si el patrón de una entidad es distinto, se deberá ajustar con un diagnóstico técnico sin contenido sensible.

## Firma
Conservar la carpeta `signing/` y el archivo JKS sin cambios. Mantener `applicationId = pe.pagovoz` y la misma firma para las actualizaciones.


Cambios de interfaz 1.3.2: el encabezado se reconstruye al cambiar de pestaña, de modo que el banner grande aparece solo en Inicio; Configuración y Resumen muestran una franja morada delgada. Cada fuente financiera activa tiene selector de voz y botón Probar voz en la misma fila, con voz independiente por aplicación.
