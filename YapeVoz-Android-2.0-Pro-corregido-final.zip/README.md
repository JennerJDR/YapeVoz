# Yape Voz Pro 2.0

Aplicación Android que escucha únicamente las notificaciones de Yape y anuncia en voz alta los pagos recibidos.

## Novedades 2.0
- Protección en segundo plano mediante un servicio en primer plano de uso especial.
- Detección real de conexión del NotificationListenerService.
- Reconexión automática cuando Android desconecta el lector.
- Botón “Reactivar servicio” sin necesidad de reiniciar el teléfono.
- Al abrir la aplicación se vuelve a comprobar el estado real.
- Inicio automático de la protección después de reiniciar o actualizar la aplicación, si Yape Voz estaba activado.
- Mantiene las funciones de 1.6: lectura de nombre, monto, código de seguridad opcional, llamadas, silencio/DND y configuración de voz.

## Importante
Android y el fabricante del teléfono pueden imponer restricciones adicionales. La versión 2.0 reduce mucho la posibilidad de que el lector quede desconectado, pero ninguna aplicación de terceros puede garantizar que el sistema nunca la detenga. Por eso la app muestra el estado real y permite reactivar el servicio.
