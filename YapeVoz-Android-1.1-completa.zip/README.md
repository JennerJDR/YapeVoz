# Yape Voz 1.1

Versión mejorada del lector de notificaciones de Yape.

- Solo procesa notificaciones del paquete oficial de Yape configurado en la app.
- Anuncia pagos recibidos con una frase corta: “Recibiste un Yape de … por S/ …”.
- Busca automáticamente una voz española de mayor calidad disponible en el teléfono.
- Usa `USAGE_NOTIFICATION`, por lo que la voz sigue el **volumen de notificaciones** del teléfono, no el multimedia.
- No habla en silencio, vibración o No molestar.
- Filtra códigos OTP/PIN y números largos de seguridad.
- Incluye botón de prueba de voz.
- Icono morado con parlante.

Nota: la voz tipo ChatGPT no se incorpora directamente; la aplicación selecciona la mejor voz española TTS que Android tenga instalada.

La redacción exacta de la notificación de Yape puede variar entre versiones. Si una notificación real no se reconoce, se puede ajustar el parser con el texto exacto de esa notificación.
