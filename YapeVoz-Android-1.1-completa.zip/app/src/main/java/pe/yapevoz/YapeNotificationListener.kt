package pe.yapevoz

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class YapeNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private val lastSpokenAt = AtomicLong(0)

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) configureTts(tts)
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != YAPE_PACKAGE) return

        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return
        if (isSilentOrDnd()) return

        val extras: Bundle = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val raw = listOf(title, text, bigText).filter { it.isNotBlank() }.joinToString(". ")

        if (!looksLikePayment(raw)) return

        val cleaned = buildPaymentPhrase(raw)
        if (cleaned.isBlank()) return

        val now = System.currentTimeMillis()
        if (now - lastSpokenAt.get() < 2500) return
        lastSpokenAt.set(now)

        tts?.speak(cleaned, TextToSpeech.QUEUE_FLUSH, null, "yape_payment")
    }

    private fun configureTts(engine: TextToSpeech?) {
        engine ?: return
        val spanish = listOf(Locale("es", "PE"), Locale("es", "ES"), Locale("es", "MX"))
        val voices = engine.voices.orEmpty()
        val bestVoice = voices
            .filter { voice -> spanish.any { it.language == voice.locale.language && it.country == voice.locale.country } }
            .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
            .firstOrNull()

        if (bestVoice != null) {
            engine.voice = bestVoice
        } else {
            engine.language = Locale("es", "PE")
        }

        // Slightly slower than default for clearer announcements while driving.
        engine.setSpeechRate(0.96f)
        engine.setPitch(1.0f)
        // USAGE_NOTIFICATION makes Android route this speech through the
        // notification volume, not the multimedia volume.
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }

    private fun looksLikePayment(s: String): Boolean {
        val n = normalize(s)
        val money = Regex("""(?:s\\s*/?\\.?|soles?)\\s*\\d|\\d+(?:[.,]\\d{1,2})?\\s*(?:soles?|s/)""").containsMatchIn(n)
        val received = n.contains("recibiste") || n.contains("recibio") ||
                n.contains("te yapearon") || n.contains("recibiste dinero") ||
                n.contains("te envio") || n.contains("te envio") || n.contains("yapeaste") && n.contains("recib")
        return money && received
    }

    private fun buildPaymentPhrase(s: String): String {
        val cleaned = cleanSecurityText(s)
        val amount = extractAmount(cleaned)
        val name = extractSenderName(cleaned)

        return when {
            name != null && amount != null -> "Recibiste un Yape de $name por $amount."
            amount != null -> "Recibiste un Yape por $amount."
            name != null -> "Recibiste un Yape de $name."
            else -> "Yape recibido."
        }
    }

    private fun extractAmount(s: String): String? {
        val patterns = listOf(
            Regex("(?i)(?:s\\s*/?\\.?|soles?)\\s*([0-9]+(?:[.,][0-9]{1,2})?)"),
            Regex("(?i)([0-9]+(?:[.,][0-9]{1,2})?)\\s*(?:soles?|s/)"),
            Regex("(?i)por\\s+([0-9]+(?:[.,][0-9]{1,2})?)")
        )
        for (p in patterns) {
            val m = p.find(s) ?: continue
            val value = m.groupValues.last().replace(',', '.')
            return "S/ $value"
        }
        return null
    }

    private fun extractSenderName(s: String): String? {
        val patterns = listOf(
            Regex("(?i)recibiste(?:\\s+un)?\\s+(?:yape|pago)?\\s*(?:de|del)\\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)(?=\\s+(?:por|s/|soles?)\\b|[.!]|$)"),
            Regex("(?i)(?:de|del)\\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)(?=\\s+(?:te\\s+envio|te\\s+envió|por|s/|soles?)\\b|[.!]|$)"),
            Regex("(?i)de\\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60})\\s+(?:te\\s+envio|te\\s+envió)")
        )
        for (p in patterns) {
            val m = p.find(s) ?: continue
            val name = m.groupValues[1].trim().replace(Regex("\\s+"), " ")
            if (name.length >= 2 && !name.equals("yape", true)) return name
        }
        return null
    }

    private fun cleanSecurityText(s: String): String {
        var x = s
        x = x.replace(Regex("(?i)(codigo|código)\\s*(de\\s*)?(seguridad|verificacion|verificación)?\\s*[:#-]?\\s*[A-Z0-9-]+"), "")
        x = x.replace(Regex("(?i)(clave|pin|otp)\\s*[:#-]?\\s*[A-Z0-9-]+"), "")
        x = x.replace(Regex("\\b\\d{4,8}\\b"), "")
        return x.replace(Regex("\\s+"), " ").trim()
    }

    private fun isSilentOrDnd(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return true

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: SecurityException) {
            false
        }
    }

    private fun normalize(s: String): String {
        return Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace("\\p{M}+".toRegex(), "")
    }

    companion object {
        const val YAPE_PACKAGE = "com.bcp.innovacxion.yapeapp"

        fun testSpeech(context: Context) {
            lateinit var testTts: TextToSpeech
            testTts = TextToSpeech(context) { result ->
                if (result == TextToSpeech.SUCCESS) {
                    val voices = testTts.voices.orEmpty()
                    val best = voices
                        .filter { it.locale.language == "es" }
                        .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.isNetworkConnectionRequired })
                        .firstOrNull()
                    if (best != null) testTts.voice = best else testTts.language = Locale("es", "PE")
                    testTts.setSpeechRate(0.96f)
                    testTts.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    testTts.speak(
                        "Prueba de Yape Voz. El lector de pagos está funcionando.",
                        TextToSpeech.QUEUE_FLUSH, null, "test"
                    )
                    testTts.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { testTts.shutdown() }
                        override fun onError(utteranceId: String?) { testTts.shutdown() }
                    })
                }
            }
        }
    }
}
