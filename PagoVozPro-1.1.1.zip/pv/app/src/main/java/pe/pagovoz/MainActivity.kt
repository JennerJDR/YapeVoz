package pe.pagovoz

import android.Manifest
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences(PaymentNotificationListener.PREFS, MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private var screen = 0
    private var darkMode = false

    private val purple = Color.rgb(101, 37, 194)
    private val purpleDark = Color.rgb(48, 14, 105)
    private val purpleSoft = Color.rgb(244, 238, 255)
    private val green = Color.rgb(17, 184, 105)
    private val greenDark = Color.rgb(17, 129, 75)
    private val lightBg = Color.rgb(247, 246, 251)
    private val darkBg = Color.rgb(25, 22, 31)
    private val lightText = Color.rgb(29, 27, 35)
    private val muted = Color.rgb(105, 100, 116)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        darkMode = prefs.getBoolean("ui_dark_mode", false)
        buildUi()
        firstLaunchSetup()
        PaymentNotificationListener.syncDefaultVoice(this)
        PaymentWatchdogService.start(this)
    }

    private fun firstLaunchSetup() {
        if (prefs.getBoolean("permissions_onboarding_done", false)) return
        prefs.edit().putBoolean("permissions_onboarding_done", true).apply()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        window.decorView.postDelayed({ showPermissions(true) }, 900L)
    }

    private fun showPermissions(firstLaunch: Boolean = false) {
        val items = arrayOf("Acceso a notificaciones", "Batería sin restricciones", "Autoencendido / inicio automático", "Mostrar notificaciones")
        AlertDialog.Builder(this)
            .setTitle(if (firstLaunch) "Configura los permisos" else "Permisos de Pago Voz Pro")
            .setMessage(if (firstLaunch) "Para que Pago Voz Pro pueda detectar pagos y funcionar en segundo plano, revisa estos permisos." else null)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    1 -> try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    2 -> openAutoStart()
                    3 -> if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
                }
            }
            .setPositiveButton("Listo", null)
            .show().also {
                it.window?.setBackgroundDrawable(rounded(Color.WHITE, 22))
                it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(purple)
            }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(if (darkMode) darkBg else lightBg)
        }

        if (screen == 0) {
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(18), dp(22), dp(18), dp(14))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(purple, purpleDark)
                )
            }

            val topLine = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            topLine.addView(Space(this), LinearLayout.LayoutParams(0, dp(1), 1f))
            val mode = TextView(this).apply {
                text = if (darkMode) "☀" else "☾"
                textSize = 24f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(2), dp(4), dp(2))
                setOnClickListener {
                    darkMode = !darkMode
                    prefs.edit().putBoolean("ui_dark_mode", darkMode).apply()
                    buildUi()
                }
            }
            topLine.addView(mode, LinearLayout.LayoutParams(dp(42), dp(42)))
            header.addView(topLine, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))

            val logo = ImageView(this).apply {
                setImageResource(R.drawable.brand_mark)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            header.addView(logo, LinearLayout.LayoutParams(dp(112), dp(112)).apply { topMargin = dp(2) })

            header.addView(TextView(this).apply {
                text = "Tu asistente de cobros"
                textSize = 18f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(0, dp(3), 0, 0)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
            header.addView(TextView(this).apply {
                text = "Te anuncia tus pagos por voz"
                textSize = 13f
                setTextColor(Color.rgb(235, 225, 255))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(24)))

            root.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(270)))
        } else {
            val simpleHeader = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(20), dp(18), dp(20), dp(18))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(purple, purpleDark))
                addView(TextView(this@MainActivity).apply {
                    text = if (screen == 1) "Configuración" else "Resumen"
                    textSize = 24f
                    setTextColor(Color.WHITE)
                    setTypeface(typeface, Typeface.BOLD)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38)))
            }
            root.addView(simpleHeader, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(74)))
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(7))
            setBackgroundColor(if (darkMode) Color.rgb(33, 30, 40) else Color.WHITE)
            elevation = dp(8).toFloat()
        }
        nav.addView(navButton("⌂\nInicio", 0), LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(navButton("⚙\nConfiguración", 1), LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(navButton("ⓘ\nResumen", 2), LinearLayout.LayoutParams(0, dp(58), 1f))
        root.addView(nav)
        setContentView(root)
        show(screen)
    }

    private fun navButton(label: String, target: Int): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setOnClickListener { show(target) }
        setTextColor(if (screen == target) purple else muted)
    }

    private fun show(which: Int) {
        screen = which
        content.removeAllViews()
        when (which) {
            0 -> home()
            1 -> settings()
            else -> summary()
        }
    }

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(radius).toFloat()
        setColor(color)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(if (darkMode) Color.rgb(39, 35, 47) else Color.WHITE, 18)
        elevation = dp(1).toFloat()
    }

    private fun title(text: String, size: Float = 27f): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(if (darkMode) Color.WHITE else lightText)
        setTypeface(typeface, Typeface.BOLD)
    }

    private fun subtitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(if (darkMode) Color.rgb(190,184,201) else muted)
        setPadding(0, dp(3), 0, 0)
    }

    private fun gap(h: Int = 12) { content.addView(Space(this), LinearLayout.LayoutParams(1, dp(h))) }

    private fun home() {
        gap(4)
        sourceCard(
            "Yape",
            "",
            PaymentNotificationListener.KEY_YAPE_ENABLED,
            R.drawable.yape_icon,
            purple
        )
        gap(10)
        sourceCard(
            "Banco Falabella",
            "",
            PaymentNotificationListener.KEY_FALABELLA_ENABLED,
            R.drawable.falabella_icon,
            green
        )
        gap(14)
        val info = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply {
            text = "●"
            textSize = 24f
            setTextColor(green)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(36), dp(36)))
        val infoText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        infoText.addView(TextView(this).apply {
            text = if (PaymentNotificationListener.isConnected(this@MainActivity)) "Lector conectado" else "Lector pendiente"
            textSize = 16f
            setTextColor(if (PaymentNotificationListener.isConnected(this@MainActivity)) greenDark else muted)
            setTypeface(typeface, Typeface.BOLD)
        })
        infoText.addView(subtitle(if (PaymentNotificationListener.isConnected(this@MainActivity)) "Escuchando notificaciones de pagos" else "Revisa los permisos en Configuración"))
        row.addView(infoText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        info.addView(row)
        content.addView(info)
    }

    private fun sourceCard(label: String, sub: String, key: String, iconRes: Int, accent: Int) {
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this).apply { setImageResource(iconRes); scaleType = ImageView.ScaleType.CENTER_CROP }
        row.addView(icon, LinearLayout.LayoutParams(dp(70), dp(70)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16),0,dp(8),0) }
        texts.addView(TextView(this).apply {
            text = label
            textSize = 17f
            setTextColor(if (darkMode) Color.WHITE else lightText)
            setTypeface(typeface, Typeface.BOLD)
        })
        val active = prefs.getBoolean(key, true)
        texts.addView(TextView(this).apply {
            text = if (active) "Activo" else "Inactivo"
            textSize = 13f
            setTextColor(if (active) green else muted)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, 0)
        })
        row.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = Switch(this).apply {
            isChecked = active
            applySwitchTint(this, active)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(key, checked).apply()
                applySwitchTint(this, checked)
                (texts.getChildAt(1) as TextView).apply {
                    text = if (checked) "Activo" else "Inactivo"
                    setTextColor(if (checked) green else muted)
                }
            }
        }
        row.addView(sw)
        c.addView(row)
        content.addView(c)
    }

    private fun settings() {
        gap(12)

        sectionLabel("Voz y audio")
        val audio = card()
        settingRow(audio, "🔊", "Volumen de notificaciones", "Controla el volumen de los anuncios") { showNotificationVolume() }
        divider(audio)
        settingRow(audio, "🎙", "Voz", "Voz natural del sistema") { openTtsSettings() }
        divider(audio)
        settingRow(audio, "👤", "Cómo anunciar el nombre", nameModeSummary()) { showNameModeDialog() }
        content.addView(audio)

        gap(14)
        sectionLabel("Información del pago")
        val payment = card()
        switchRow(payment, "Leer monto", PaymentNotificationListener.KEY_READ_AMOUNT, true)
        divider(payment)
        switchRow(payment, "Leer código de seguridad", PaymentNotificationListener.KEY_READ_CODE, false)
        content.addView(payment)

        gap(14)
        sectionLabel("Otras opciones")
        val other = card()
        switchRow(other, "No molestar / Modo silencio", PaymentNotificationListener.KEY_RESPECT_SILENT, true)
        divider(other)
        settingRow(other, "🛡", "Permisos", "Notificación, batería y auto encendido") { showPermissions() }
        content.addView(other)

        gap(14)
        val test = Button(this).apply {
            text = "▶  Probar anuncio"
            textSize = 15f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            isAllCaps = false
            background = rounded(purple, 18)
            setPadding(0, dp(3), 0, dp(3))
            setOnClickListener { PaymentNotificationListener.testSpeech(this@MainActivity) }
        }
        content.addView(test, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
    }

    private fun sectionLabel(text: String) {
        content.addView(TextView(this).apply {
            this.text = text
            textSize = 18f
            setTextColor(if (darkMode) Color.WHITE else lightText)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(8))
        })
    }

    private fun settingRow(parent: LinearLayout, icon: String, label: String, sub: String, click: () -> Unit) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(3), 0, dp(3)); setOnClickListener { click() } }
        row.addView(TextView(this).apply {
            text = icon
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(purple)
        }, LinearLayout.LayoutParams(dp(42), dp(58)))
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textBox.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(if (darkMode) Color.WHITE else lightText); setTypeface(typeface, Typeface.BOLD) })
        textBox.addView(TextView(this).apply { text = sub; textSize = 12f; setTextColor(if (darkMode) Color.rgb(190,184,201) else muted); setPadding(0, dp(2), 0, 0) })
        row.addView(textBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply { text = "›"; textSize = 28f; setTextColor(muted); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(30), dp(58)))
        parent.addView(row)
    }

    private fun switchRow(parent: LinearLayout, label: String, key: String, default: Boolean) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        row.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(if (darkMode) Color.WHITE else lightText); setTypeface(typeface, Typeface.BOLD) }, LinearLayout.LayoutParams(0, dp(50), 1f))
        row.addView(Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            applySwitchTint(this, isChecked)
            setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(key, v).apply(); applySwitchTint(this, v) }
        })
        parent.addView(row)
    }

    private fun applySwitchTint(sw: Switch, checked: Boolean) {
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf(-android.R.attr.state_checked))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.rgb(245, 245, 245)))
        sw.trackTintList = ColorStateList(states, intArrayOf(green, Color.rgb(190, 190, 190)))
    }

    private fun divider(parent: LinearLayout) {
        parent.addView(View(this).apply { setBackgroundColor(if (darkMode) Color.rgb(65,60,72) else Color.rgb(232,228,238)) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
    }

    private fun nameModeSummary(): String = when (prefs.getString(PaymentNotificationListener.KEY_NAME_MODE, PaymentNotificationListener.NAME_FIRST)) {
        PaymentNotificationListener.NAME_FULL -> "Nombre y apellido"
        else -> "Solo nombre"
    }

    private fun showNameModeDialog() {
        val values = arrayOf("Solo nombre", "Nombre y apellido")
        val checked = if (prefs.getString(PaymentNotificationListener.KEY_NAME_MODE, PaymentNotificationListener.NAME_FIRST) == PaymentNotificationListener.NAME_FULL) 1 else 0
        AlertDialog.Builder(this)
            .setTitle("Cómo anunciar el nombre")
            .setSingleChoiceItems(values, checked) { dialog, which ->
                prefs.edit().putString(PaymentNotificationListener.KEY_NAME_MODE, if (which == 1) PaymentNotificationListener.NAME_FULL else PaymentNotificationListener.NAME_FIRST).apply()
                dialog.dismiss()
                show(1)
            }
            .show().also {
                it.window?.setBackgroundDrawable(rounded(Color.WHITE, 22))
                it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(purple)
            }
    }

    private fun showNotificationVolume() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION)
        val current = audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), dp(4)) }
        val value = TextView(this).apply { text = "${current * 100 / max}%"; gravity = Gravity.CENTER; textSize = 16f; setTextColor(purple); setTypeface(typeface, Typeface.BOLD) }
        val bar = SeekBar(this).apply { this.max = max; this.progress = current }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION, p, 0); value.text = "${p * 100 / max}%" }
            override fun onStartTrackingTouch(s: SeekBar?) = Unit
            override fun onStopTrackingTouch(s: SeekBar?) = Unit
        })
        box.addView(value); box.addView(bar)
        AlertDialog.Builder(this).setTitle("Volumen de notificaciones").setView(box).setPositiveButton("Listo", null).show().also { it.window?.setBackgroundDrawable(rounded(Color.WHITE, 22)); it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(purple) }
    }

    private fun showPermissions() { showPermissions(false) }

    private fun openTtsSettings() {
        val intents = listOf("android.settings.TTS_SETTINGS", "android.settings.TEXT_TO_SPEECH_SETTINGS")
        for (action in intents) {
            try { startActivity(Intent(action)); return } catch (_: Exception) { }
        }
        startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
    }

    private fun summary() {
        content.addView(subtitle("Historial de pagos"))
        gap(14)

        val summary = PaymentNotificationListener.getTodaySummary(this)
        val stat = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        stat.addView(statCard("${summary.first}", "Pagos hoy", purple), LinearLayout.LayoutParams(0, dp(108), 1f))
        stat.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        stat.addView(statCard(formatCents(summary.second), "Total hoy", green), LinearLayout.LayoutParams(0, dp(108), 1f))
        content.addView(stat)
        gap(12)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val reset = Button(this).apply {
            text = "Resetear contador"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            background = rounded(purple, 16)
            setOnClickListener { confirmResetCounter() }
        }
        val clear = Button(this).apply {
            text = "Borrar historial"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            background = rounded(Color.rgb(110, 105, 118), 16)
            setOnClickListener { confirmClearHistory() }
        }
        actions.addView(reset, LinearLayout.LayoutParams(0, dp(48), 1f))
        actions.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        actions.addView(clear, LinearLayout.LayoutParams(0, dp(48), 1f))
        content.addView(actions)
        gap(16)

        val history = readHistory()
        if (history.length() == 0) {
            val empty = card()
            empty.addView(TextView(this).apply { text = "Todavía no hay pagos registrados."; textSize = 15f; setTextColor(muted); gravity = Gravity.CENTER; setPadding(0, dp(20), 0, dp(20)) })
            content.addView(empty)
            return
        }

        for (i in history.length() - 1 downTo 0) {
            val obj = history.optJSONObject(i) ?: continue
            val c = historyCard(obj)
            content.addView(c)
            gap(9)
            if (history.length() - i >= 12) break
        }
    }

    private fun statCard(value: String, label: String, accent: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = rounded(accent, 18)
        addView(TextView(this@MainActivity).apply { text = value; textSize = 22f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER })
        addView(TextView(this@MainActivity).apply { text = label; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) })
    }

    private fun historyCard(obj: org.json.JSONObject): LinearLayout {
        val source = obj.optString("source", "Yape")
        val amount = formatAmount(obj.optLong("soles", 0), obj.optInt("cents", 0))
        val name = obj.optString("name", "").ifBlank { "Sin nombre" }
        val code = obj.optString("code", "")
        val time = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(obj.optLong("timestamp", 0)))
        val accent = if (source == "Banco Falabella") green else purple
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val dot = TextView(this).apply { text = if (source == "Banco Falabella") "f." else "y"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD); background = rounded(accent, 16) }
        row.addView(dot, LinearLayout.LayoutParams(dp(50), dp(50)))
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        textBox.addView(TextView(this).apply { text = source; textSize = 14f; setTextColor(accent); setTypeface(typeface, Typeface.BOLD) })
        textBox.addView(TextView(this).apply { text = "Recibiste $amount de $name"; textSize = 15f; setTextColor(if (darkMode) Color.WHITE else lightText); setTypeface(typeface, Typeface.BOLD); setPadding(0,dp(2),0,0) })
        textBox.addView(TextView(this).apply { text = time; textSize = 12f; setTextColor(muted); setPadding(0,dp(2),0,0) })
        row.addView(textBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener {
            val codeText = if (code.isNotBlank()) "\nCódigo: $code" else ""
            AlertDialog.Builder(this).setTitle(source).setMessage("Monto: $amount\nPagador: $name$codeText\nFecha: $time").setPositiveButton("Cerrar", null).show().also { it.window?.setBackgroundDrawable(rounded(Color.WHITE, 22)); it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(purple) }
        }
        c.addView(row)
        return c
    }

    private fun confirmResetCounter() {
        AlertDialog.Builder(this)
            .setTitle("Resetear contador")
            .setMessage("¿Quieres poner en cero el contador de pagos de hoy? El historial se conservará.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Resetear") { _, _ ->
                prefs.edit().putLong(PaymentNotificationListener.KEY_COUNTER_RESET_AT, System.currentTimeMillis()).apply()
                PaymentWatchdogService.refresh(this@MainActivity)
                show(2)
            }
            .show().also {
                it.window?.setBackgroundDrawable(rounded(Color.WHITE, 22))
                it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(purple)
                it.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(muted)
            }
    }

    private fun confirmClearHistory() {
        AlertDialog.Builder(this)
            .setTitle("Borrar historial")
            .setMessage("¿Quieres borrar todo el historial de pagos? Esta acción no se puede deshacer.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Borrar") { _, _ ->
                prefs.edit().putString(PaymentNotificationListener.KEY_PAYMENT_HISTORY, "[]").putLong(PaymentNotificationListener.KEY_COUNTER_RESET_AT, 0L).apply()
                PaymentWatchdogService.refresh(this@MainActivity)
                show(2)
            }
            .show().also {
                it.window?.setBackgroundDrawable(rounded(Color.WHITE, 22))
                it.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.rgb(190, 40, 55))
                it.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(muted)
            }
    }

    private fun readHistory(): JSONArray = try { JSONArray(prefs.getString(PaymentNotificationListener.KEY_PAYMENT_HISTORY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun formatAmount(soles: Long, cents: Int): String = "S/ ${soles}.${cents.toString().padStart(2, '0')}"
    private fun formatCents(cents: Long): String = formatAmount(cents / 100L, (cents % 100L).toInt())

    private fun openAutoStart() {
        val i = Intent().apply { component = ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity") }
        try { if (i.resolveActivity(packageManager) != null) { startActivity(i); return } } catch (_: Exception) { }
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }
}
