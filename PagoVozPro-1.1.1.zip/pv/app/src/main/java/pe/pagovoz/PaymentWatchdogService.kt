package pe.pagovoz

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat

/**
 * Servicio en primer plano de vigilancia.
 * Mantiene el proceso de Pago Voz Pro activo y pide a Android que vuelva a enlazar
 * el NotificationListener cuando se desconecta.
 */
class PaymentWatchdogService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private val checkRunnable = object : Runnable {
        override fun run() {
            checkListener()
            handler.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        setRunning(this, true)
        createChannel()
        startAsForeground()
        handler.post(checkRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        checkListener()
        return START_STICKY
    }

    override fun onDestroy() {
        setRunning(this, false)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun checkListener() {
        val prefs = getSharedPreferences(PaymentNotificationListener.PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(PaymentNotificationListener.KEY_ENABLED, true)) {
            stopSelf()
            return
        }

        val hasAccess = isNotificationListenerEnabled()
        val connected = PaymentNotificationListener.isConnected(this)
        if (hasAccess && !connected) {
            // La reconexión se solicita desde el propio NotificationListenerService
            // en onListenerDisconnected(). Aquí solo vigilamos y mostramos el estado,
            // evitando llamar a la API desde un componente que no es el listener.
        }

        updateNotification(hasAccess, connected)
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun startAsForeground() {
        val notification = buildNotification(
            access = isNotificationListenerEnabled(),
            connected = PaymentNotificationListener.isConnected(this)
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(access: Boolean, connected: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(access, connected))
    }

    private fun buildNotification(access: Boolean, connected: Boolean): Notification {
        val text = when {
            !access -> "Falta activar el acceso a notificaciones"
            connected -> "Escuchando notificaciones de pagos"
            else -> "Intentando reconectar el lector de pagos"
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        val pendingIntent = PendingIntent.getActivity(this, 0, openIntent, pendingFlags)
        val yapeCount = PaymentNotificationListener.getTodayYapeCount(this)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Pago Voz Pro")
            .setContentText("Yapes hoy: $yapeCount")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pago Voz Pro - servicio activo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mantiene activo el lector de notificaciones de Pago Voz Pro."
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "pago_voz_watchdog"
        private const val NOTIFICATION_ID = 2001
        private const val CHECK_INTERVAL_MS = 60_000L

        private fun setRunning(context: Context, running: Boolean) {
            context.getSharedPreferences(PaymentNotificationListener.PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(PaymentNotificationListener.KEY_WATCHDOG_RUNNING, running).apply()
        }

        fun isRunning(context: Context): Boolean =
            context.getSharedPreferences(PaymentNotificationListener.PREFS, Context.MODE_PRIVATE)
                .getBoolean(PaymentNotificationListener.KEY_WATCHDOG_RUNNING, false)

        fun start(context: Context) {
            val intent = Intent(context, PaymentWatchdogService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
                // Si el sistema no permite iniciarlo en ese momento,
                // la próxima apertura de la app volverá a intentarlo.
            }
        }

        fun refresh(context: Context) {
            try {
                val service = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                service.notify(NOTIFICATION_ID, buildNotificationForContext(context))
            } catch (_: Exception) {
            }
        }

        private fun buildNotificationForContext(context: Context): Notification {
            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
            val pendingIntent = PendingIntent.getActivity(context, 0, openIntent, pendingFlags)
            val yapeCount = PaymentNotificationListener.getTodayYapeCount(context)
            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Pago Voz Pro")
                .setContentText("Yapes hoy: $yapeCount")
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOnlyAlertOnce(true)
                .build()
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, PaymentWatchdogService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
