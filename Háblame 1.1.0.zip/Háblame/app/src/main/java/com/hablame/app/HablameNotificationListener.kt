package com.hablame.app

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.ComponentName
import android.content.pm.PackageManager
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.provider.ContactsContract
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class HablameNotificationListener : NotificationListenerService() {
    companion object {
        private val recent = ConcurrentHashMap<String, Long>()
        @Volatile private var connected = false

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(":").any {
                try { ComponentName.unflattenFromString(it) == ComponentName(context, HablameNotificationListener::class.java) }
                catch (_: Exception) { false }
            }
        }

        fun isConnected(): Boolean = connected

        fun requestRebind(context: Context) {
            try {
                if (isEnabled(context)) {
                    NotificationListenerService.requestRebind(ComponentName(context, HablameNotificationListener::class.java))
                }
            } catch (_: Exception) { }
        }

        fun updatePersistentNotification(context: Context) {
            if (!Prefs.getBool(context, "service_enabled", true) ||
                !Prefs.getBool(context, "permanent_notification", true) ||
                !isConnected()
            ) {
                cancelPersistentNotification(context)
                return
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channelId = "hablame_service"
            if (Build.VERSION.SDK_INT >= 26) {
                val channel = NotificationChannel(
                    channelId,
                    "Estado de Háblame",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Indica que Háblame está escuchando notificaciones"
                    setShowBadge(false)
                }
                nm.createNotificationChannel(channel)
            }
            val intent = Intent(context, MainActivity::class.java)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            val pi = PendingIntent.getActivity(context, 1001, intent, flags)
            val builder = if (Build.VERSION.SDK_INT >= 26)
                Notification.Builder(context, channelId)
            else
                Notification.Builder(context)
            builder.setSmallIcon(R.drawable.ic_bell)
                .setContentTitle("Háblame está activo")
                .setContentText("Escuchando llamadas y notificaciones")
                .setOngoing(true)
                .setAutoCancel(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi)
                .setShowWhen(false)
            try { nm.notify(1001, builder.build()) } catch (_: Exception) { }
        }

        fun cancelPersistentNotification(context: Context) {
            try {
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .cancel(1001)
            } catch (_: Exception) { }
        }
    }
    private val worker: ExecutorService by lazy { Executors.newSingleThreadExecutor() }


    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = true
        if (Prefs.getBool(this, "service_enabled", true)) postServiceNotification() else cancelServiceNotification()
        try { TtsEngine.ensureCurrentEngine(applicationContext) } catch (_: Exception) { }
    }

    override fun onListenerDisconnected() {
        connected = false
        cancelServiceNotification()
        super.onListenerDisconnected()
    }

    private fun postServiceNotification() {
        updatePersistentNotification(applicationContext)
    }

    private fun cancelServiceNotification() {
        cancelPersistentNotification(applicationContext)
    }

    override fun onCreate() {
        super.onCreate()
        // Keep the selected TTS engine initialized while the listener is alive,
        // so a locked-screen notification can be spoken without waiting for the UI.
        try { TtsEngine.ensureCurrentEngine(applicationContext) } catch (_: Exception) { }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.getBool(this, "service_enabled", true)) return
        if (sbn.packageName == packageName) return
        val app = applicationContext
        worker.execute {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            val wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Hablame:NotificationSpeech")
            try {
                wakeLock.acquire(60000L)
                processNotification(app, sbn)
            } catch (_: Exception) {
                // Never let one notification stop the listener worker.
            } finally {
                try { if (wakeLock.isHeld) wakeLock.release() } catch (_: Exception) { }
            }
        }
    }

    override fun onDestroy() {
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun processNotification(context: Context, sbn: StatusBarNotification) {
        if (!Prefs.getBool(context, "service_enabled", true)) return
        val pkg = sbn.packageName
        val knownKey = "app_$pkg"
        val knownApps = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.facebook.katana",
            "com.instagram.android",
            "com.zhiliaoapp.musically",
            "com.google.android.apps.messaging",
            "com.google.android.gm"
        )

        if (pkg in knownApps) {
            if (!Prefs.getBool(context, knownKey, true)) return
        } else if (!Prefs.getBool(context, "read_other_apps", true)) {
            return
        }

        if (!canSpeak()) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return

        val extras = n.extras ?: Bundle()
        val title = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_TITLE))
        val text = TextCleaner.speakableContent(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)
        )
        val conversation = TextCleaner.cleanName(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE))

        // Las llamadas de WhatsApp se anuncian como llamadas, no como mensajes.
        // Una actualización de la misma notificación puede convertirse en
        // “llamada perdida” cuando el usuario no contesta.
        if (pkg == "com.whatsapp" && isWhatsAppCallNotification(n, title, conversation, text)) {
            announceWhatsAppCall(context, extras, title, conversation, text)
            return
        }

        val isGroupConversation = isGroupConversation(extras, title, conversation)

        // WhatsApp puede publicar una actualización/resumen de la conversación
        // como “2 mensajes, Diana”. No es un mensaje individual fiable y, si lo
        // leyéramos, terminaríamos diciendo algo como “WhatsApp familia, 2 mensajes, Diana”.
        // Se omiten esos resúmenes para que solo se anuncien notificaciones con
        // información suficiente del mensaje real.
        if (isMessageCountSummary(title, text) || isMessageCountSummary(conversation, text)) return

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.').ifBlank { "Aplicación" }
        }

        // WhatsApp y otras apps de mensajería pueden publicar una notificación
        // temporal de actividad propia mientras el usuario envía un video, foto,
        // audio, documento, etc. No es un mensaje recibido y no debe anunciarse.
        val selfActivityPackages = setOf(
            "com.whatsapp",
            "org.telegram.messenger",
            "com.facebook.orca",
            "com.instagram.android",
            "com.zhiliaoapp.musically",
            "com.google.android.apps.messaging"
        )
        if (pkg in selfActivityPackages &&
            title.equals(appName, ignoreCase = true) &&
            conversation.isBlank()
        ) return

        val key = "$pkg|$title|$conversation|$text"
        val now = System.currentTimeMillis()
        val old = recent[key]
        if (old != null && now - old < 5000L) return
        recent[key] = now
        recent.entries.removeIf { now - it.value > 15000L }

        val readTitle = Prefs.getBool(context, "title_$pkg", true)
        val readContent = Prefs.getBool(context, "content_$pkg", true)

        // Si WhatsApp muestra el número en lugar del nombre, no se lee toda la
        // cadena de dígitos. Si ese número tampoco existe en Contactos, se usa
        // la frase natural “número desconocido”. Si sí existe, se recupera el
        // nombre guardado en el teléfono.
        val resolvedTitle = if (pkg == "com.whatsapp" && looksLikePhoneNumber(title)) {
            lookupContact(context, title)?.let { TextCleaner.cleanName(it) } ?: "número desconocido"
        } else {
            title
        }
        val titlePart = if (readTitle && resolvedTitle.isNotBlank()) resolvedTitle else ""
        val contentPart = if (readContent && text.isNotBlank()) text else ""

        // Para conversaciones individuales: "WhatsApp de Gerardo".
        // Para grupos: "WhatsApp de Gerardo a Familia".
        // La misma regla se aplica a Telegram, Messenger y las demás apps.
        val intro = when {
            titlePart.isNotBlank() && isGroupConversation && conversation.isNotBlank() ->
                "$appName de $titlePart a $conversation"
            titlePart.isNotBlank() ->
                "$appName de $titlePart"
            isGroupConversation && conversation.isNotBlank() ->
                "$appName a $conversation"
            else ->
                appName
        }
        val speech = if (contentPart.isNotBlank()) "$intro. $contentPart" else intro

        if (speech.isNotBlank()) TtsEngine.speak(context, speech)
    }



    private fun isWhatsAppCallNotification(
        notification: Notification,
        title: String,
        conversation: String,
        text: String
    ): Boolean {
        if (notification.category == Notification.CATEGORY_CALL) return true
        val combined = "$title $conversation $text".lowercase()
        return combined.contains("llamada") ||
            combined.contains("llamando") ||
            combined.contains("llamada entrante") ||
            combined.contains("llamada perdida") ||
            combined.contains("incoming call") ||
            combined.contains("missed call") ||
            combined.contains("voice call") ||
            combined.contains("video call")
    }

    private fun announceWhatsAppCall(
        context: Context,
        extras: Bundle,
        title: String,
        conversation: String,
        text: String
    ) {
        if (!canSpeak()) return

        val combined = "$title $conversation $text"
        val lower = combined.lowercase()
        val missed = lower.contains("perdida") ||
            lower.contains("missed") ||
            lower.contains("rechazada") ||
            lower.contains("declined")

        var sender = ""
        val explicit = Regex(
            "(?:llamada\s+(?:perdida|entrante)?\s*(?:de|from)|(?:de|from))\\s+(.+)",
            RegexOption.IGNORE_CASE
        ).find(combined)
        if (explicit != null) sender = explicit.groupValues[1].trim()

        val generic = setOf(
            "whatsapp", "llamada", "llamada entrante", "llamada perdida",
            "incoming call", "missed call", "voice call", "video call"
        )

        if (sender.isBlank()) {
            val candidates = listOf(title, conversation, text)
                .map { it.trim() }
                .filter { it.isNotBlank() }
            sender = candidates.firstOrNull {
                it.lowercase() !in generic &&
                    !it.lowercase().contains("llamada") &&
                    !it.lowercase().contains("call") &&
                    !it.matches(Regex("^\\d+$"))
            } ?: ""
        }

        sender = TextCleaner.cleanName(sender)
        if (sender.isBlank() || sender.equals("WhatsApp", ignoreCase = true)) {
            sender = "número desconocido"
        } else if (looksLikePhoneNumber(sender)) {
            sender = lookupContact(context, sender)?.let { TextCleaner.cleanName(it) }
                ?: "número desconocido"
        }

        val speech = if (missed) {
            "Llamada perdida de WhatsApp de $sender"
        } else {
            "Llamada de WhatsApp de $sender"
        }

        val key = "whatsapp_call|$missed|$sender"
        val now = System.currentTimeMillis()
        val old = recent[key]
        if (old != null && now - old < 5000L) return
        recent[key] = now
        recent.entries.removeIf { now - it.value > 15000L }

        val repetitions = Prefs.getInt(context, "call_repetitions", 2).coerceIn(1, 5)
        TtsEngine.speakRepeated(context, speech, repetitions)
    }

    private fun isMessageCountSummary(title: String, text: String): Boolean {
        val combined = "${title.trim()} ${text.trim()}"
        return Regex("(^|\\s)\\d+\\s+(mensajes|messages)(\\s|$)", RegexOption.IGNORE_CASE).containsMatchIn(combined)
    }

    private fun looksLikePhoneNumber(value: String): Boolean {
        val normalized = value.replace(Regex("[^0-9+]"), "")
        val digits = normalized.count { it.isDigit() }
        return digits >= 7 && normalized.length <= 20 && normalized.count { it == '+' } <= 1
    }

    private fun lookupContact(context: Context, number: String): String? {
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context, Manifest.permission.READ_CONTACTS
            ) != PackageManager.PERMISSION_GRANTED
        ) return null

        return try {
            val uri = ContactsContract.PhoneLookup.CONTENT_FILTER_URI.buildUpon()
                .appendPath(android.net.Uri.encode(number)).build()
            context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isGroupConversation(
        extras: Bundle,
        title: String,
        conversation: String
    ): Boolean {
        // Android exposes this flag for MessagingStyle notifications when the
        // originating app marks the conversation as a group.
        if (extras.containsKey("android.isGroupConversation") &&
            extras.getBoolean("android.isGroupConversation", false)
        ) return true

        // WhatsApp, Telegram and Messenger frequently provide the group name
        // through EXTRA_CONVERSATION_TITLE without setting the flag. In that
        // case a different conversation title is the reliable group signal.
        if (conversation.isBlank()) return false
        if (conversation.equals(title, ignoreCase = true)) return false
        return true
    }

    private fun canSpeak(): Boolean {
        if (!Prefs.getBool(this, "normal_only", true)) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return false
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        return nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL
    }
}
