# Háblame 1.0.9

Versión de mantenimiento. Incluye recuperación del servicio de notificaciones después de reinicios, auto encendido en segundo plano, indicador permanente de servicio activo, botón de reactivación manual y conserva las funciones de llamadas, notificaciones, TTS y control de velocidad de Háblame.
