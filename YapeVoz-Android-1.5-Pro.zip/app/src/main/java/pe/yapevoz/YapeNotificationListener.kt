package pe.yapevoz

import android.app.Notification
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.Normalizer
import java.util.Locale
import java.util.concurrent.atomic.AtomicLong

class YapeNotificationListener : NotificationListenerService() {

    private var tts: TextToSpeech? = null
    private val lastSpokenAt = AtomicLong(0L)
    private var lastNotificationKey: String? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) {
                configureTts(tts)
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // SOLO la aplicación Yape. La app bancaria del BCP tiene otro paquete.
        if (sbn.packageName != YAPE_PACKAGE) return

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ENABLED, true)) return
        val respectSilent = prefs.getBoolean(KEY_RESPECT_SILENT, true)
        if (respectSilent && isSilentOrDnd()) return
        if (prefs.getBoolean(KEY_SKIP_CALLS, true) && isInCall()) return

        val extras: Bundle = sbn.notification.extras ?: return
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val subText = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()

        // El título de Yape ("Confirmación de Pago") NO contiene el nombre.
        // El nombre, monto y código están en el contenido de la notificación.
        // Por eso ignoramos completamente el título al analizar el pago.
        val raw = listOf(bigText, text, subText)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(". ")

        if (raw.isBlank()) return

        // Evita volver a leer exactamente la misma notificación.
        val notificationKey = sbn.key + "|" + raw
        if (notificationKey == lastNotificationKey) return

        val cleaned = cleanNotificationText(raw)
        val amount = extractAmount(cleaned) ?: return
        if (!looksLikePayment(cleaned)) return

        val sender = extractSenderName(cleaned)
        val nameMode = prefs.getString(KEY_NAME_MODE, NAME_FIRST) ?: NAME_FIRST
        val spokenName = sender?.let { formatName(it, nameMode) }
        val code = if (prefs.getBoolean(KEY_READ_CODE, false)) {
            extractSecurityCode(raw)
        } else {
            null
        }

        val phrase = buildPhrase(spokenName, amount, code)

        val now = System.currentTimeMillis()
        if (now - lastSpokenAt.get() < 1200L) return

        lastSpokenAt.set(now)
        lastNotificationKey = notificationKey

        speak(phrase)
    }

    private fun speak(text: String) {
        val engine = tts ?: return
        if (engine.isSpeaking) engine.stop()
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "yape_payment")
    }

    private fun configureTts(engine: TextToSpeech?) {
        engine ?: return

        // No seleccionamos una voz propia: Android usará la voz que el usuario
        // haya elegido en la configuración de Texto a voz. Así la prueba y los
        // Yapes utilizan la misma voz del teléfono.
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
    }

    private fun looksLikePayment(s: String): Boolean {
        val n = normalize(s)
        val paymentWords = listOf(
            "te envio", "te envió", "te yapeo", "te yapeó",
            "te hizo un yape", "te hizo un pago",
            "recibiste", "confirmacion de pago", "confirmación de pago",
            "pago por"
        )
        return paymentWords.any { n.contains(normalize(it)) }
    }

    private fun extractAmount(s: String): Amount? {
        val patterns = listOf(
            Regex("""(?i)\bs\s*/\s*([0-9]+(?:[.,][0-9]{1,2})?)"""),
            Regex("""(?i)\b([0-9]+(?:[.,][0-9]{1,2})?)\s*(?:soles?|s/)\b"""),
            Regex("""(?i)\bpor\s+(?:s\s*/\s*)?([0-9]+(?:[.,][0-9]{1,2})?)\b""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val value = match.groupValues[1].replace(',', '.')
            val parts = value.split('.')
            val soles = parts[0].toLongOrNull() ?: continue
            val cents = if (parts.size > 1) {
                (parts[1] + "00").take(2).toIntOrNull() ?: 0
            } else {
                0
            }
            if (cents !in 0..99) continue
            return Amount(soles, cents)
        }
        return null
    }

    private fun extractSenderName(s: String): String? {
        // Formato observado: "Nombre Apellido* te envió un pago por S/ 0.1".
        // El nombre se extrae dinámicamente; nunca queda fijado en el código.
        val patterns = listOf(
            Regex("""(?i)^\s*([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)[*]?\s+te\s+(?:envio|envió|yapeo|yapeó)\b"""),
            Regex("""(?i)(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)[*]?\s+(?=por\b|s\s*/|soles?\b)"""),
            Regex("""(?i)(?:recibiste|recibio|recibió)\s+(?:un\s+)?(?:yape|pago)?\s*(?:de|del)\s+([A-Za-zÁÉÍÓÚáéíóúÑñÜü .'-]{2,60}?)[*]?\s+(?=por\b|s\s*/|soles?\b)""")
        )

        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            val name = match.groupValues[1]
                .replace("*", "")
                .trim()
                .replace(Regex("""\s+"""), " ")
                .trim('.', ',', ':', ';', '-')

            if (isPlausibleName(name)) return name
        }
        return null
    }

    private fun isPlausibleName(name: String): Boolean {
        if (name.length !in 2..60) return false
        val words = name.split(Regex("""\s+""")).filter { it.length >= 2 }
        if (words.isEmpty()) return false

        val blocked = setOf("yape", "pago", "dinero", "tu", "un", "una", "el", "la", "te", "confirmacion")
        return normalize(name) !in blocked
    }

    private fun formatName(name: String, mode: String): String {
        val parts = name.split(Regex("""\s+"""))
            .filter { it.isNotBlank() }
            .map { it.trim('.', ',', ':', ';', '-') }

        if (parts.isEmpty()) return name

        return when (mode) {
            NAME_FULL -> parts.joinToString(" ")
            else -> parts.first()
        }
    }

    private fun cleanNotificationText(s: String): String {
        // Quitamos el código de seguridad del texto antes de buscar el monto
        // y el nombre, pero lo extraemos por separado para poder anunciarlo.
        var x = s
        x = x.replace(
            Regex("""(?i)(?:el\s+)?c[oó]d\.?\s*(?:de\s+)?seguridad\s*(?:es|:)?\s*[A-Z0-9-]+"""),
            ""
        )
        x = x.replace(
            Regex("""(?i)(?:codigo|código)\s*(?:de\s+)?(?:seguridad|verificacion|verificación)?\s*(?:es|:)?\s*[A-Z0-9-]+"""),
            ""
        )
        x = x.replace(
            Regex("""(?i)(?:clave|pin|otp)\s*(?:es|:)?\s*[A-Z0-9-]+"""),
            ""
        )
        return x.replace(Regex("""\s+"""), " ").trim()
    }

    private fun extractSecurityCode(s: String): String? {
        val patterns = listOf(
            Regex("""(?i)(?:c[oó]d\.?|codigo|código)\s*(?:de\s+)?seguridad\s*(?:es|:)?\s*([0-9]{3,8})"""),
            Regex("""(?i)(?:clave|pin|otp)\s*(?:es|:)?\s*([0-9]{3,8})""")
        )
        for (pattern in patterns) {
            val match = pattern.find(s) ?: continue
            return match.groupValues[1]
        }
        return null
    }

    private fun buildPhrase(name: String?, amount: Amount, code: String?): String {
        val amountText = amountToSpanish(amount)
        val base = if (!name.isNullOrBlank()) {
            "Recibiste un Yape de $name por $amountText"
        } else {
            "Recibiste un Yape por $amountText"
        }

        return if (!code.isNullOrBlank()) {
            "$base, con código $code."
        } else {
            "$base."
        }
    }

    private fun amountToSpanish(amount: Amount): String {
        val solesText = numberToSpanish(amount.soles)
        return when {
            amount.soles == 0L && amount.cents > 0 -> {
                "${centsToSpanish(amount.cents)} céntimos"
            }
            amount.soles == 1L && amount.cents == 0 -> "un sol"
            amount.cents == 0 -> "$solesText soles"
            amount.soles == 1L -> "un sol con ${centsToSpanish(amount.cents)} céntimos"
            else -> "$solesText soles con ${centsToSpanish(amount.cents)} céntimos"
        }
    }

    private fun centsToSpanish(cents: Int): String {
        return when (cents) {
            1 -> "un"
            2 -> "dos"
            3 -> "tres"
            4 -> "cuatro"
            5 -> "cinco"
            6 -> "seis"
            7 -> "siete"
            8 -> "ocho"
            9 -> "nueve"
            10 -> "diez"
            11 -> "once"
            12 -> "doce"
            13 -> "trece"
            14 -> "catorce"
            15 -> "quince"
            16 -> "dieciséis"
            17 -> "diecisiete"
            18 -> "dieciocho"
            19 -> "diecinueve"
            20 -> "veinte"
            21 -> "veintiún"
            22 -> "veintidós"
            23 -> "veintitrés"
            24 -> "veinticuatro"
            25 -> "veinticinco"
            26 -> "veintiséis"
            27 -> "veintisiete"
            28 -> "veintiocho"
            29 -> "veintinueve"
            30 -> "treinta"
            40 -> "cuarenta"
            50 -> "cincuenta"
            60 -> "sesenta"
            70 -> "setenta"
            80 -> "ochenta"
            90 -> "noventa"
            else -> {
                val tens = (cents / 10) * 10
                val units = cents % 10
                if (tens == 30) "treinta y ${centsToSpanish(units)}"
                else "${centsToSpanish(tens)} y ${centsToSpanish(units)}"
            }
        }
    }

    private fun numberToSpanish(n: Long): String {
        if (n == 0L) return "cero"
        if (n in 1..999_999) return numberUnderMillion(n)
        return n.toString()
    }

    private fun numberUnderMillion(n: Long): String {
        if (n < 1000) return underThousand(n)
        val thousands = n / 1000
        val rest = n % 1000
        val prefix = if (thousands == 1L) "mil" else "${underThousand(thousands)} mil"
        return if (rest == 0L) prefix else "$prefix ${underThousand(rest)}"
    }

    private fun underThousand(n: Long): String {
        val ones = arrayOf("cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve")
        val teens = arrayOf("diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve")
        val tens = arrayOf("", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa")
        val hundreds = arrayOf("", "ciento", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos")

        if (n < 10) return ones[n.toInt()]
        if (n < 20) return teens[(n - 10).toInt()]
        if (n == 20L) return "veinte"
        if (n < 30) return "veinti" + ones[(n - 20).toInt()]
        if (n < 100) {
            val t = (n / 10).toInt()
            val u = (n % 10).toInt()
            return if (u == 0) tens[t] else "${tens[t]} y ${ones[u]}"
        }
        if (n == 100L) return "cien"
        val h = (n / 100).toInt()
        val rest = n % 100
        return if (rest == 0L) hundreds[h] else "${hundreds[h]} ${underThousand(rest)}"
    }

    private fun isSilentOrDnd(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return true

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        return try {
            nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        } catch (_: SecurityException) {
            false
        }
    }

    private fun isInCall(): Boolean {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return audio.mode == AudioManager.MODE_IN_CALL ||
            audio.mode == AudioManager.MODE_IN_COMMUNICATION
    }

    private fun normalize(s: String): String {
        return Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
            .replace(Regex("""\p{M}+"""), "")
    }

    companion object {
        const val YAPE_PACKAGE = "com.bcp.innovacxion.yapeapp"
        const val PREFS = "app"
        const val KEY_ENABLED = "enabled"
        const val KEY_NAME_MODE = "name_mode"
        const val KEY_READ_CODE = "read_security_code"
        const val KEY_SKIP_CALLS = "skip_calls"
        const val KEY_RESPECT_SILENT = "respect_silent"
        const val NAME_FIRST = "first"
        const val NAME_FULL = "full"

        fun testSpeech(context: Context) {
            lateinit var testTts: TextToSpeech
            testTts = TextToSpeech(context) { result ->
                if (result != TextToSpeech.SUCCESS) return@TextToSpeech

                // Igual que el lector principal: respetar la voz elegida en Android.
                testTts.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                testTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { testTts.shutdown() }
                    override fun onError(utteranceId: String?) { testTts.shutdown() }
                })
                testTts.speak(
                    "Prueba de Yape Voz. El lector de pagos está funcionando.",
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "test"
                )
            }
        }
    }

    private data class Amount(val soles: Long, val cents: Int)
}
