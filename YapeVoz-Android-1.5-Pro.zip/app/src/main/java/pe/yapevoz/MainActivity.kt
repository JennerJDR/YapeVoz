package pe.yapevoz

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var nameModeSpinner: Spinner
    private lateinit var codeSwitch: Switch
    private lateinit var callsSwitch: Switch
    private lateinit var silentSwitch: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        enabledSwitch = findViewById(R.id.enabledSwitch)
        nameModeSpinner = findViewById(R.id.nameModeSpinner)
        codeSwitch = findViewById(R.id.codeSwitch)
        callsSwitch = findViewById(R.id.callsSwitch)
        silentSwitch = findViewById(R.id.silentSwitch)

        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)

        val modes = listOf("Solo primer nombre", "Nombre y apellido")
        nameModeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modes
        )

        val savedMode = prefs.getString(
            YapeNotificationListener.KEY_NAME_MODE,
            YapeNotificationListener.NAME_FIRST
        ) ?: YapeNotificationListener.NAME_FIRST

        nameModeSpinner.setSelection(
            if (savedMode == YapeNotificationListener.NAME_FULL) 1 else 0
        )

        nameModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val value = if (position == 1) {
                    YapeNotificationListener.NAME_FULL
                } else {
                    YapeNotificationListener.NAME_FIRST
                }
                prefs.edit().putString(YapeNotificationListener.KEY_NAME_MODE, value).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        enabledSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)
        codeSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_READ_CODE, false)
        callsSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
        silentSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)

        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_ENABLED, checked).apply()
            updateStatus()
        }

        codeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_READ_CODE, checked).apply()
        }

        callsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, checked).apply()
        }

        silentSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, checked).apply()
        }

        findViewById<Button>(R.id.notificationsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        findViewById<Button>(R.id.dndButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }

        findViewById<Button>(R.id.voiceSettingsButton).setOnClickListener {
            openTtsSettings()
        }

        findViewById<Button>(R.id.testButton).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }

        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun openTtsSettings() {
        // En Android/AOSP la pantalla concreta de Texto a voz usa esta acción.
        // Primero la enviamos explícitamente a la app de Ajustes para evitar que
        // algunos teléfonos la interpreten como una pantalla general.
        val intents = listOf(
            Intent("com.android.settings.TTS_SETTINGS").setPackage("com.android.settings"),
            Intent("android.settings.TTS_SETTINGS"),
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent("android.settings.TEXT_TO_SPEECH_SETTINGS")
        )

        for (intent in intents) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: ActivityNotFoundException) {
                // Try the next known TTS action.
            }
        }

        // Último recurso en teléfonos que no exponen la pantalla TTS directamente.
        try {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updateStatus() {
        val listenerOk = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        )?.contains(packageName) == true

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) == true

        status.text = buildString {
            append(if (listenerOk) "✓ Acceso a notificaciones activo\n" else "⚠ Falta acceso a notificaciones\n")
            append(if (batteryOk) "✓ Batería sin restricciones\n" else "⚠ Falta quitar restricción de batería\n")
            append(if (enabledSwitch.isChecked) "✓ Yape Voz está ACTIVADA" else "⏸ Yape Voz está PAUSADA")
        }
    }
}
