package com.hablame.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.regex.Pattern

object Prefs {
    private const val P = "hablame_prefs"
    private fun p(c: Context) = c.getSharedPreferences(P, Context.MODE_PRIVATE)
    fun getBool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun getInt(c: Context, k: String, d: Int) = p(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
    fun getString(c: Context, k: String, d: String) = p(c).getString(k, d) ?: d
    fun setString(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

object TextCleaner {
    private val emoji = Pattern.compile("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{FE0F}\\x{200D}\\x{1F3FB}-\\x{1F3FF}]")

    fun cleanName(value: CharSequence?): String {
        if (value == null) return ""
        val s = emoji.matcher(value.toString()).replaceAll("")
        return s.replace(Regex("[\\p{So}\\p{Cn}]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun cleanContent(value: CharSequence?): String {
        if (value == null) return ""
        return value.toString().replace(Regex("\\s+"), " ").trim()
    }

    fun speakableContent(value: CharSequence?): String {
        if (value == null) return ""
        var s = cleanContent(value)
        val replacements = linkedMapOf(
            "❤️" to " corazón ", "❤" to " corazón ", "😂" to " cara llorando de risa ",
            "🤣" to " rodando de risa ", "😊" to " sonrisa ", "🙂" to " sonrisa ",
            "😀" to " cara feliz ", "😃" to " cara feliz ", "😄" to " sonrisa ",
            "😁" to " sonrisa amplia ", "😆" to " risa ", "😅" to " sonrisa nerviosa ",
            "😉" to " guiño ", "😍" to " enamorado ", "😘" to " beso ",
            "🥰" to " enamorado ", "😎" to " gafas de sol ", "😭" to " llorando ",
            "😢" to " triste ", "😡" to " enojado ", "😠" to " enojado ",
            "😱" to " asustado ", "😮" to " sorprendido ", "😴" to " durmiendo ",
            "🤔" to " pensando ", "🙄" to " poniendo los ojos en blanco ",
            "👍" to " pulgar arriba ", "👎" to " pulgar abajo ", "👏" to " aplausos ",
            "🙏" to " manos juntas ", "🔥" to " fuego ", "🎉" to " celebración ",
            "💯" to " cien por cien ", "⭐" to " estrella ", "✨" to " brillo ",
            "💔" to " corazón roto ", "💚" to " corazón verde ", "💙" to " corazón azul ",
            "💜" to " corazón morado ", "💛" to " corazón amarillo ", "🩷" to " corazón rosa ",
            "🚀" to " cohete ", "⚠️" to " advertencia ", "❗" to " exclamación ",
            "❓" to " pregunta ", "☀️" to " sol ", "🌙" to " luna", "☕" to " café ",
            "🎵" to " nota musical ", "🎶" to " notas musicales "
        )
        replacements.forEach { (emoji, word) -> s = s.replace(emoji, word) }
        return s.replace(Regex("\\s+"), " ").trim()
    }
}

object TtsEngine {
    private fun getSelectedTtsEngine(c: Context): String? = try {
        Settings.Secure.getString(c.contentResolver, "tts_default_synth")
    } catch (_: Exception) {
        null
    }

    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var enginePackage: String? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private val repeatHandler = Handler(Looper.getMainLooper())
    private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val lock = Any()
    private var repeatToken = 0

    fun init(c: Context, onReady: (() -> Unit)? = null) {
        val app = c.applicationContext
        synchronized(lock) {
            if (tts != null && ready) {
                onReady?.invoke()
                return
            }
            audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val selectedEngine = try { getSelectedTtsEngine(app) } catch (_: Exception) { null }
            enginePackage = selectedEngine
            try {
                tts = if (!selectedEngine.isNullOrBlank()) {
                    TextToSpeech(app, { status -> onInitialized(app, status, onReady) }, selectedEngine)
                } else {
                    TextToSpeech(app) { status -> onInitialized(app, status, onReady) }
                }
            } catch (_: Exception) {
                tts = null
                ready = false
                onReady?.invoke()
            }
        }
    }

    private fun onInitialized(c: Context, status: Int, onReady: (() -> Unit)?) {
        ready = status == TextToSpeech.SUCCESS
        if (ready) {
            applySavedVoice(c)
            applyAudioAttributes(c)
        }
        onReady?.invoke()
    }

    private fun applySavedVoice(c: Context) {
        val saved = Prefs.getString(c, "tts_voice", "")
        if (saved.isBlank()) return
        try { tts?.voices?.firstOrNull { it.name == saved }?.let { tts?.voice = it } } catch (_: Exception) { }
    }

    fun ensureCurrentEngine(c: Context, onReady: (() -> Unit)? = null) {
        val app = c.applicationContext
        val selected = try { getSelectedTtsEngine(app) } catch (_: Exception) { null }
        if (tts == null || !ready || selected != enginePackage) {
            reload(app, selected, onReady)
        } else {
            applyAudioAttributes(app)
            onReady?.invoke()
        }
    }

    fun reload(c: Context, onReady: (() -> Unit)? = null) {
        val selected = try { getSelectedTtsEngine(c.applicationContext) } catch (_: Exception) { null }
        reload(c.applicationContext, selected, onReady)
    }

    private fun reload(c: Context, selectedEngine: String?, onReady: (() -> Unit)?) {
        stop()
        synchronized(lock) {
            ready = false
            enginePackage = selectedEngine
            try { tts?.shutdown() } catch (_: Exception) { }
            tts = null
        }
        init(c, onReady)
    }

    private fun usageFor(c: Context): Int = when (Prefs.getString(c, "audio_usage", "notification")) {
        "call" -> AudioAttributes.USAGE_VOICE_COMMUNICATION
        "media" -> AudioAttributes.USAGE_MEDIA
        "alarm" -> AudioAttributes.USAGE_ALARM
        else -> AudioAttributes.USAGE_NOTIFICATION
    }

    private fun streamForUsage(usage: Int): Int = when (usage) {
        AudioAttributes.USAGE_VOICE_COMMUNICATION -> AudioManager.STREAM_VOICE_CALL
        AudioAttributes.USAGE_MEDIA -> AudioManager.STREAM_MUSIC
        AudioAttributes.USAGE_ALARM -> AudioManager.STREAM_ALARM
        else -> AudioManager.STREAM_NOTIFICATION
    }

    fun refreshAudioAttributes(c: Context) {
        applyAudioAttributes(c.applicationContext)
    }

    private fun applyAudioAttributes(c: Context) {
        val attrs = AudioAttributes.Builder()
            .setUsage(usageFor(c))
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        try { tts?.setAudioAttributes(attrs) } catch (_: Exception) { }
    }

    private fun requestFocus(c: Context): Boolean {
        val am = audioManager ?: (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).also { audioManager = it }
        val usage = usageFor(c)
        val attrs = AudioAttributes.Builder()
            .setUsage(usage)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        if (Build.VERSION.SDK_INT >= 26) {
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(attrs)
                .setAcceptsDelayedFocusGain(false)
                .setWillPauseWhenDucked(false)
                .build()
            focusRequest = request
            return am.requestAudioFocus(request) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        @Suppress("DEPRECATION")
        return am.requestAudioFocus(null, streamForUsage(usage), AudioManager.AUDIOFOCUS_GAIN_TRANSIENT) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
    }

    private fun abandonFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            focusRequest?.let { try { am.abandonAudioFocusRequest(it) } catch (_: Exception) { } }
        } else {
            @Suppress("DEPRECATION")
            try { am.abandonAudioFocus(null) } catch (_: Exception) { }
        }
        focusRequest = null
    }

    fun speak(c: Context, text: String) {
        speakRepeated(c, text, 1)
    }

    fun speakRepeated(c: Context, text: String, count: Int) {
        if (text.isBlank()) return
        if (!ready) {
            ensureCurrentEngine(c) {
                if (ready) speakRepeated(c, text, count)
            }
            return
        }
        repeatToken++
        val token = repeatToken
        repeatHandler.removeCallbacksAndMessages(null)
        stopInternal(false)
        applyAudioAttributes(c)
        requestFocus(c)
        var remaining = count.coerceIn(1, 5)

        fun speakNext() {
            if (token != repeatToken || remaining <= 0 || !ready) {
                abandonFocus()
                return
            }
            val utteranceId = "hablame_${System.currentTimeMillis()}_${remaining}"
            val listener = object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    if (token != repeatToken) return
                    remaining--
                    if (remaining > 0) repeatHandler.postDelayed({ speakNext() }, 500L)
                    else abandonFocus()
                }
                override fun onError(id: String?) { if (token == repeatToken) abandonFocus() }
            }
            try {
                tts?.setOnUtteranceProgressListener(listener)
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), utteranceId)
            } catch (_: Exception) { abandonFocus() }
        }
        speakNext()
    }

    private fun stopInternal(abandon: Boolean) {
        try { tts?.stop() } catch (_: Exception) { }
        if (abandon) abandonFocus()
    }

    fun stop() {
        repeatToken++
        repeatHandler.removeCallbacksAndMessages(null)
        stopInternal(true)
    }

    fun loadVoicesAsync(c: Context, onResult: (List<android.speech.tts.Voice>, String?) -> Unit) {
        ensureCurrentEngine(c) {
            val engineName = enginePackage
            worker.execute {
                val result = try { voicesForCurrentConfigurationInternal() } catch (_: Exception) { emptyList() }
                Handler(Looper.getMainLooper()).post { onResult(result, engineName) }
            }
        }
    }

    private fun voicesForCurrentConfigurationInternal(): List<android.speech.tts.Voice> {
        val engine = tts ?: return emptyList()
        val all = try { engine.voices?.toList().orEmpty() } catch (_: Exception) { emptyList() }
        if (all.isEmpty()) return emptyList()

        val selectedLocale = try {
            engine.voice?.locale ?: engine.language ?: Locale.getDefault()
        } catch (_: Exception) { Locale.getDefault() }

        val languageMatches = all.filter { it.locale.language.equals(selectedLocale.language, true) }
        if (languageMatches.isEmpty()) return emptyList()

        val countryMatches = languageMatches.filter {
            selectedLocale.country.isNotBlank() && it.locale.country.equals(selectedLocale.country, true)
        }
        val filtered = if (countryMatches.isNotEmpty()) countryMatches else languageMatches
        return filtered.distinctBy { it.name }.sortedWith(
            compareBy({ it.locale.displayLanguage }, { it.locale.displayCountry }, { it.name })
        )
    }

    fun currentVoiceName(): String = try { tts?.voice?.name.orEmpty() } catch (_: Exception) { "" }
    fun currentEnginePackage(): String? = enginePackage
    fun setVoice(v: android.speech.tts.Voice) { if (ready) try { tts?.voice = v } catch (_: Exception) { } }
}

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private lateinit var statusPill: TextView
    private var current = "inicio"
    private var waitingForPermissionSettings = false
    private var permissionFlowStarted = false
    private var runtimePermissionDenied = false
    private var runtimeDialogActive = false
    private var openedTtsSettings = false
    private val pageCache = mutableMapOf<String, View>()
    private var buildingCachedPage = false

    private val blue by lazy { ContextCompat.getColor(this, R.color.hab_blue) }
    private val green by lazy { ContextCompat.getColor(this, R.color.hab_green) }
    private val textColor by lazy { ContextCompat.getColor(this, R.color.hab_text) }
    private val muted by lazy { ContextCompat.getColor(this, R.color.hab_muted) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val scroll = findViewById<ScrollView>(R.id.scroll)
        setupSwipeNavigation(scroll)
        val baseTop = dp(10)
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { view, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            val bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            view.setPadding(view.paddingLeft, top + baseTop, view.paddingRight, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(scroll)
        content = findViewById(R.id.page_container)
        statusPill = findViewById(R.id.service_status)
        setupBottomNav()
        TtsEngine.init(this)
        refreshStatus()
        showPage("inicio")
    }

    override fun onPause() {
        super.onPause()
        if (!waitingForPermissionSettings && !runtimeDialogActive) {
            permissionFlowStarted = false
            runtimePermissionDenied = false
        }
    }

    override fun onResume() {
        super.onResume()
        if (openedTtsSettings) {
            openedTtsSettings = false
            TtsEngine.ensureCurrentEngine(this) {
                if (current == "voice" && !isFinishing && !isDestroyed) showPage("voice")
            }
        }
        refreshStatus()
        if (waitingForPermissionSettings) {
            waitingForPermissionSettings = false
            Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 450)
        } else if (!permissionFlowStarted && !runtimePermissionDenied) {
            permissionFlowStarted = true
            Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 500)
        }
    }

    private fun continuePermissionFlow() {
        if (isFinishing || isDestroyed) return
        refreshStatus()

        if (!HablameNotificationListener.isEnabled(this)) {
            waitingForPermissionSettings = true
            try {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            return
        }

        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
            return
        }

        if (!hasPermission(Manifest.permission.READ_PHONE_STATE) ||
            (Build.VERSION.SDK_INT >= 26 && !hasPermission(Manifest.permission.READ_PHONE_NUMBERS)) ||
            !hasPermission(Manifest.permission.READ_CALL_LOG)) {
            runtimeDialogActive = true
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_PHONE_STATE,
                    Manifest.permission.READ_PHONE_NUMBERS,
                    Manifest.permission.READ_CALL_LOG
                ), 21
            )
            return
        }

        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
            return
        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        runtimeDialogActive = false
        val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (!allGranted) {
            runtimePermissionDenied = true
            Toast.makeText(this, "Quedan permisos pendientes. Se volverán a solicitar al entrar nuevamente.", Toast.LENGTH_LONG).show()
            refreshStatus()
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({ continuePermissionFlow() }, 350)
    }

    private fun setupBottomNav() {
        findViewById<View>(R.id.nav_home).setOnClickListener { showPage("inicio") }
        findViewById<View>(R.id.nav_apps).setOnClickListener { showPage("apps") }
        findViewById<View>(R.id.nav_calls).setOnClickListener { showPage("calls") }
        findViewById<View>(R.id.nav_voice).setOnClickListener { showPage("voice") }
        findViewById<View>(R.id.nav_permissions).setOnClickListener { showPage("permissions") }
        updateBottomNav("inicio")
    }

    private fun setupSwipeNavigation(scroll: ScrollView) {
        var downX = 0f
        var downY = 0f
        scroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.x
                    downY = event.y
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (kotlin.math.abs(dx) > dp(72) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f) {
                        if (dx < 0) showAdjacentPage(1) else showAdjacentPage(-1)
                    }
                }
            }
            false
        }
    }

    private fun showAdjacentPage(direction: Int) {
        val pages = listOf("inicio", "apps", "calls", "voice", "permissions")
        val index = pages.indexOf(current)
        if (index < 0) return
        val next = (index + direction).coerceIn(0, pages.lastIndex)
        if (next != index) showPage(pages[next])
    }

    private fun updateBottomNav(page: String) {
        val ids = listOf(R.id.nav_home, R.id.nav_apps, R.id.nav_calls, R.id.nav_voice, R.id.nav_permissions)
        ids.forEachIndexed { index, id ->
            val item = findViewById<LinearLayout>(id)
            val active = when (index) {
                0 -> page == "inicio"
                1 -> page == "apps"
                2 -> page == "calls"
                3 -> page == "voice"
                else -> page == "permissions"
            }
            item.background = if (active) getDrawable(R.drawable.bg_nav_active) else null
            val icon = item.getChildAt(0) as? ImageView
            val label = item.getChildAt(1) as? TextView
            icon?.setColorFilter(if (active) green else blue)
            label?.setTextColor(if (active) green else blue)
            item.alpha = if (active) 1f else 0.82f
        }
    }

    private fun refreshStatus() {
        val enabled = Prefs.getBool(this, "service_enabled", true)
        val notificationOk = HablameNotificationListener.isEnabled(this)
        val phoneOk = hasPermission(Manifest.permission.READ_PHONE_STATE)
        val contactsOk = hasPermission(Manifest.permission.READ_CONTACTS)
        val permissionsOk = notificationOk && phoneOk && contactsOk
        when {
            !enabled -> {
                statusPill.text = "Servicio desactivado"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_disabled_pill)
            }
            permissionsOk -> {
                statusPill.text = "✓  Servicio activo"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_green_pill)
            }
            else -> {
                statusPill.text = "⚠  Requiere permisos"
                statusPill.setTextColor(Color.WHITE)
                statusPill.setBackgroundResource(R.drawable.bg_red_pill)
            }
        }
    }

    private fun showPage(page: String, forceRebuild: Boolean = false) {
        current = page
        updateBottomNav(page)
        val cacheable = page == "apps" || page == "calls"
        if (forceRebuild && cacheable) pageCache.remove(page)

        val cached = if (cacheable) pageCache[page] else null
        content.removeAllViews()
        if (cached != null) {
            content.addView(cached)
        } else {
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(-1, -2)
            }
            val previous = content
            buildingCachedPage = cacheable
            content = root
            when (page) {
                "inicio" -> homePage()
                "apps" -> appsPage()
                "calls" -> callsPage()
                "voice" -> voicePage()
                "permissions" -> permissionsPage()
            }
            content = previous
            buildingCachedPage = false
            if (cacheable) pageCache[page] = root
            content.addView(root)
        }
        findViewById<ScrollView>(R.id.scroll)?.post { findViewById<ScrollView>(R.id.scroll)?.scrollTo(0, 0) }
    }

    private fun homePage() {
        val enabled = Prefs.getBool(this, "service_enabled", true)
        addSectionTitle("Háblame")
        addText("Lee en voz alta llamadas y notificaciones para que estés siempre informado, sin mirar tu teléfono.", 14, muted)
        val status = card()
        status.addView(text("Estado de Háblame", 17, textColor, true))
        status.addView(space(5))
        status.addView(text(if (enabled) "Llamadas y notificaciones se anuncian según tu configuración." else "Háblame está desactivado. No anunciará llamadas ni notificaciones.", 13, muted))
        content.addView(status)
        addSpacer(10)
        homeActionCard(R.drawable.ic_call, "Llamadas", if (!enabled) "Desactivadas" else if (hasPermission(Manifest.permission.READ_PHONE_STATE)) "Activadas" else "Requiere permiso") { showPage("calls") }
        homeActionCard(R.drawable.ic_bell, "Notificaciones", if (!enabled) "Desactivadas" else if (HablameNotificationListener.isEnabled(this)) "Activadas" else "Requiere acceso") { showPage("apps") }
        addSpacer(8)
        homeActionCard(R.drawable.ic_settings, "Acceso rápido a permisos", "Revisar permisos pendientes") { showPage("permissions") }
        addSpacer(10)
        val toggle = button(if (enabled) "Desactivar Háblame" else "Activar Háblame")
        toggle.background = getDrawable(if (enabled) R.drawable.bg_blue_button else R.drawable.bg_inactive_button)
        toggle.setOnClickListener {
            val next = !Prefs.getBool(this, "service_enabled", true)
            Prefs.setBool(this, "service_enabled", next)
            if (!next) TtsEngine.stop()
            refreshStatus()
            showPage("inicio")
            Toast.makeText(this, if (next) "Háblame activado." else "Háblame desactivado.", Toast.LENGTH_SHORT).show()
        }
        content.addView(toggle)
        addSpacer(18)
    }

    private fun appsPage() {
        addSectionTitle("Aplicaciones")
        addText("Todas las aplicaciones con notificaciones pueden ser leídas. Háblame anuncia primero la aplicación y luego el título de la notificación.", 14, muted)

        val apps = listOf(
            Triple("WhatsApp", "com.whatsapp", "app_com.whatsapp"),
            Triple("Telegram", "org.telegram.messenger", "app_org.telegram.messenger"),
            Triple("Messenger", "com.facebook.orca", "app_com.facebook.orca"),
            Triple("Facebook", "com.facebook.katana", "app_com.facebook.katana"),
            Triple("Instagram", "com.instagram.android", "app_com.instagram.android"),
            Triple("TikTok", "com.zhiliaoapp.musically", "app_com.zhiliaoapp.musically"),
            Triple("Mensajes", "com.google.android.apps.messaging", "app_com.google.android.apps.messaging"),
            Triple("Gmail", "com.google.android.gm", "app_com.google.android.gm")
        )
        apps.forEach { (name, pkg, key) -> appRow(name, pkg, key) }

        val other = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text("Otras aplicaciones", 15, textColor, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = newGreenSwitch()
        sw.isChecked = Prefs.getBool(this, "read_other_apps", true)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, "read_other_apps", v) }
        row.addView(sw)
        other.addView(row)
        other.addView(text("Lee la aplicación y el título de cualquier otra notificación.", 11, muted))
        content.addView(other)
        addSpacer(7)
    }

    private fun appRow(name: String, pkg: String, key: String) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        val lp = LinearLayout.LayoutParams(dp(40), dp(40))
        lp.marginEnd = dp(12)
        icon.layoutParams = lp
        try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) }
        catch (_: Exception) { icon.setImageResource(R.drawable.ic_bell) }
        row.addView(icon)
        val label = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        label.addView(text(name, 15, textColor, true))
        label.addView(text("Lectura de notificaciones", 11, muted))
        row.addView(label)
        val sw = newGreenSwitch()
        sw.isChecked = Prefs.getBool(this, key, true)
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v) }
        row.addView(sw)
        c.addView(row)
        c.setOnClickListener { appDetail(name, pkg, key) }
        content.addView(c)
        addSpacer(7)
    }

    private fun appDetail(name: String, pkg: String, key: String) {
        content.removeAllViews()
        addBack("Aplicaciones") { showPage("apps") }
        addSectionTitle(name)
        addText("Háblame leerá la notificación que llegue de $name.", 14, muted)
        settingSwitch("Activada", Prefs.getBool(this, key, true), key) { }
        settingSwitch("Leer el título de la notificación", Prefs.getBool(this, "title_$pkg", true), "title_$pkg") { }
        settingSwitch("Leer el contenido de la notificación", Prefs.getBool(this, "content_$pkg", true), "content_$pkg") { }
        addSubTitle("Regla general")
        val rule = card()
        rule.addView(text("Emojis y símbolos del nombre de la persona o del grupo se omiten. Los emojis que estén dentro del mensaje se interpretan y se anuncian.", 13, muted))
        content.addView(rule)
    }

    private fun callsPage() {
        addSectionTitle("Llamadas")
        addText("Configura cómo quieres que se anuncien las llamadas entrantes.", 14, muted)
        settingSwitch("Contactos guardados — leer el nombre del contacto", Prefs.getBool(this, "call_contact_name", true), "call_contact_name") { }
        addSubTitle("Números desconocidos")
        val group = RadioGroup(this)
        group.orientation = RadioGroup.VERTICAL
        val a = RadioButton(this).apply { id = View.generateViewId(); text = "Leer el número" }
        val b = RadioButton(this).apply { id = View.generateViewId(); text = "Decir “número desconocido”" }
        val c = RadioButton(this).apply { id = View.generateViewId(); text = "No anunciar" }
        group.addView(a); group.addView(b); group.addView(c)
        when (Prefs.getString(this, "unknown_mode", "number")) {
            "unknown" -> b.isChecked = true
            "none" -> c.isChecked = true
            else -> a.isChecked = true
        }
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setString(this, "unknown_mode", when (id) { b.id -> "unknown"; c.id -> "none"; else -> "number" })
        }
        content.addView(group)
        addSubTitle("Repetición del anuncio")
        val repCard = card()
        repCard.addView(text("Cuántas veces anunciar una llamada entrante", 14, textColor, true))
        val repSpinner = Spinner(this)
        val repLabels = (1..5).map { if (it == 1) "1 vez" else "$it veces" }
        repSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, repLabels)
        repSpinner.setSelection((Prefs.getInt(this, "call_repetitions", 2).coerceIn(1, 5)) - 1)
        repSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Prefs.setInt(this@MainActivity, "call_repetitions", position + 1)
            }
        }
        repCard.addView(repSpinner)
        content.addView(repCard)
        addSpacer(8)
        addSubTitle("Otras opciones")
        val info = card()
        info.addView(text("Háblame solo habla en modo de sonido normal.", 14, textColor, true))
        info.addView(text("En silencio, vibración o No molestar no realizará anuncios.", 12, muted))
        content.addView(info)
    }

    private fun voicePage() {
        addSectionTitle("Voz")
        addText("Configura la voz del motor TTS seleccionado en Android y el canal de audio para sus anuncios.", 14, muted)

        val c = card()
        c.addView(text("Voces del TTS actual", 13, textColor, true))
        val settings = button("⚙  Configurar TTS")
        settings.setOnClickListener {
            openedTtsSettings = true
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { } }
        }
        c.addView(settings)
        addSpacer(6)

        val engineInfo = text("Motor TTS: detectando…", 11, muted)
        c.addView(engineInfo)
        addSpacer(3)
        val spinner = Spinner(this)
        spinner.isEnabled = false
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Cargando voces del motor TTS…"))
        c.addView(spinner)
        addSpacer(5)

        val test = button("▶  Probar voz")
        test.setOnClickListener { TtsEngine.speak(this, "Esta es una prueba de voz de Háblame.") }
        c.addView(test)
        content.addView(c)

        TtsEngine.loadVoicesAsync(this) { voices, enginePackage ->
            if (isFinishing || isDestroyed || current != "voice") return@loadVoicesAsync
            val engineLabel = try {
                if (!enginePackage.isNullOrBlank()) packageManager.getApplicationLabel(packageManager.getApplicationInfo(enginePackage, 0)).toString()
                else "Motor TTS del sistema"
            } catch (_: Exception) { enginePackage ?: "Motor TTS del sistema" }
            engineInfo.text = "Motor TTS: $engineLabel"

            val labels = voices.map { voice ->
                val locale = voice.locale.toLanguageTag().ifBlank { voice.locale.displayLanguage }
                val voiceLabel = voice.name.substringAfterLast(".").replace("-local", " local").replace("-network", " red")
                "$locale — $voiceLabel"
            }.ifEmpty { listOf("No hay voces del idioma configurado en este motor") }

            spinner.isEnabled = voices.isNotEmpty()
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

            val saved = Prefs.getString(this, "tts_voice", "")
            val currentVoice = TtsEngine.currentVoiceName()
            val idx = voices.indexOfFirst { it.name == saved || it.name == currentVoice }
            if (idx >= 0) spinner.setSelection(idx, false)

            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {}
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position in voices.indices) {
                        TtsEngine.setVoice(voices[position])
                        Prefs.setString(this@MainActivity, "tts_voice", voices[position].name)
                    }
                }
            }
        }

        addSpacer(8)
        addSubTitle("Canal de audio")
        val audioCard = card()
        audioCard.addView(text("Elige por qué canal del sistema quieres escuchar la voz de Háblame.", 12, muted))
        val audioGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val options = listOf("call" to "Llamadas", "notification" to "Notificaciones", "media" to "Multimedia", "alarm" to "Alarma")
        val radioByKey = mutableMapOf<String, RadioButton>()
        options.forEach { (key, label) ->
            val rb = RadioButton(this).apply {
                id = View.generateViewId()
                text = label
                setPadding(0, dp(2), 0, dp(2))
            }
            radioByKey[key] = rb
            audioGroup.addView(rb)
        }
        radioByKey[Prefs.getString(this, "audio_usage", "notification")]?.isChecked = true
        audioGroup.setOnCheckedChangeListener { _, checkedId ->
            val selected = options.firstOrNull { radioByKey[it.first]?.id == checkedId }?.first ?: "notification"
            Prefs.setString(this, "audio_usage", selected)
            TtsEngine.refreshAudioAttributes(this)
        }
        audioCard.addView(audioGroup)
        audioCard.addView(text("Se usa el canal de audio elegido y prioridad temporal mientras habla, sin cambiar el volumen del teléfono.", 12, muted))
        content.addView(audioCard)

        addSpacer(8)
        settingSwitch("Solo en modo sonido normal", Prefs.getBool(this, "normal_only", true), "normal_only") { }
        addText("No hablar en silencio, vibración o No molestar.", 12, muted)
        val rule = card()
        rule.addView(text("Emojis y símbolos en nombres y grupos", 14, textColor, true))
        rule.addView(text("Se omiten automáticamente en el nombre de la persona o del grupo. Si aparecen dentro del mensaje, Háblame los interpreta al hablar.", 12, muted))
        content.addView(rule)
    }

    private fun permissionsPage() {
        addSectionTitle("Permisos")
        addText("Al entrar por primera vez, Háblame solicita automáticamente los permisos que falten.", 14, muted)
        permissionRow("Acceso a notificaciones", HablameNotificationListener.isEnabled(this)) {
            waitingForPermissionSettings = true
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        permissionRow("Notificaciones de Háblame", Build.VERSION.SDK_INT < 33 || hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }
        permissionRow("Optimización de batería de Android", isBatteryOptimized()) {
            waitingForPermissionSettings = true
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        permissionRow("Inicio automático", true) {
            Toast.makeText(this, "El inicio automático depende del fabricante del teléfono.", Toast.LENGTH_LONG).show()
        }
        permissionRow("Teléfono", hasPermission(Manifest.permission.READ_PHONE_STATE) && hasPermission(Manifest.permission.READ_CALL_LOG)) {
            requestPermissions(arrayOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_PHONE_NUMBERS, Manifest.permission.READ_CALL_LOG), 21)
        }
        permissionRow("Contactos", hasPermission(Manifest.permission.READ_CONTACTS)) {
            runtimeDialogActive = true
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 22)
        }
        permissionRow("Texto a voz", true) {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) { }
        }
    }

    private fun permissionRow(title: String, ok: Boolean, action: () -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        icon.setImageResource(if (ok) R.drawable.ic_shield else R.drawable.ic_bell)
        row.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(text(title, 14, textColor, true))
        col.addView(text(if (ok) "Permitido" else "Requiere atención", 12, if (ok) green else ContextCompat.getColor(this, R.color.hab_red)))
        row.addView(col)
        row.addView(text(if (ok) "✓" else "›", 20, if (ok) green else blue, true))
        c.addView(row)
        c.setOnClickListener { action() }
        content.addView(c)
        addSpacer(7)
    }

    private fun newGreenSwitch(): androidx.appcompat.widget.SwitchCompat {
        val sw = androidx.appcompat.widget.SwitchCompat(this)
        val checked = intArrayOf(android.R.attr.state_checked)
        val unchecked = intArrayOf(-android.R.attr.state_checked)
        sw.thumbTintList = ColorStateList(arrayOf(checked, unchecked), intArrayOf(green, Color.rgb(97, 97, 97)))
        sw.trackTintList = ColorStateList(arrayOf(checked, unchecked), intArrayOf(ContextCompat.getColor(this, R.color.hab_green_light), Color.rgb(210, 210, 210)))
        return sw
    }

    private fun settingSwitch(label: String, checked: Boolean, key: String, onChanged: (Boolean) -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(text(label, 14, textColor, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = newGreenSwitch()
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, v -> Prefs.setBool(this, key, v); onChanged(v) }
        row.addView(sw)
        c.addView(row)
        content.addView(c)
        addSpacer(7)
    }

    private fun homeActionCard(iconRes: Int, title: String, sub: String, onClick: () -> Unit) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val icon = ImageView(this)
        icon.setImageResource(iconRes)
        row.addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        col.addView(text(title, 15, textColor, true))
        col.addView(text(sub, 12, green))
        row.addView(col)
        row.addView(text("✓", 20, green, true))
        c.addView(row)
        c.setOnClickListener { onClick() }
        content.addView(c)
        addSpacer(7)
    }

    private fun addBack(label: String, onClick: () -> Unit) {
        val b = TextView(this).apply {
            text = "‹  $label"; textSize = 14f; setTextColor(blue); setPadding(0, 4, 0, 12); setOnClickListener { onClick() }
        }
        content.addView(b)
    }

    private fun addSectionTitle(s: String): TextView {
        val t = text(s, 25, textColor, true)
        t.setPadding(0, 4, 0, 4)
        content.addView(t)
        return t
    }

    private fun addSubTitle(s: String) { content.addView(text(s, 14, textColor, true)); addSpacer(4) }
    private fun addText(s: String, size: Int, color: Int) { content.addView(text(s, size, color, false)); addSpacer(7) }
    private fun addSpacer(n: Int) { content.addView(space(n)) }
    private fun text(s: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(2, 2, 2, 2) }
    private fun space(h: Int) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = getDrawable(R.drawable.bg_card); setPadding(dp(14), dp(12), dp(14), dp(12)); layoutParams = LinearLayout.LayoutParams(-1, -2) }
    private fun button(label: String) = Button(this).apply { text = label; textSize = 14f; setTextColor(Color.WHITE); background = getDrawable(R.drawable.bg_blue_button); isAllCaps = false; minHeight = dp(48) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun isBatteryOptimized(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
        return !pm.isIgnoringBatteryOptimizations(packageName)
    }
}
