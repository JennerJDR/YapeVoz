package pe.yapevoz

import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Build
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.graphics.Color
import android.content.res.ColorStateList
import android.widget.LinearLayout
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.SeekBar
import android.widget.Switch
import android.widget.RadioButton
import android.app.AlertDialog
import android.widget.TextView
import android.widget.Toast
import android.widget.ViewFlipper
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var screenFlipper: ViewFlipper
    private lateinit var status: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var nameModeSpinner: Spinner
    private lateinit var codeSwitch: Switch
    private lateinit var callsSwitch: Switch
    private lateinit var silentSwitch: Switch
    private lateinit var notificationAccessSwitch: Switch
    private lateinit var showNotificationsSwitch: Switch
    private lateinit var batterySwitch: Switch
    private lateinit var autostartSwitch: Switch
    private lateinit var todayCount: TextView
    private lateinit var todayTotal: TextView
    private lateinit var historyText: TextView

    private var firstSetupStage = 0
    private var firstSetupWaitingForReturn = false
    private val firstSetupHandler = Handler(Looper.getMainLooper())

    private lateinit var navInicio: Button
    private lateinit var navVoz: Button
    private lateinit var navLectura: Button
    private lateinit var navAjustes: Button

    private val statusHandler = Handler(Looper.getMainLooper())
    private val statusRunnable = object : Runnable {
        override fun run() {
            updateStatus()
            updateStats()
            statusHandler.postDelayed(this, 2000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val themePrefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        val savedTheme = themePrefs.getString(KEY_THEME, THEME_LIGHT) ?: THEME_LIGHT
        AppCompatDelegate.setDefaultNightMode(
            if (savedTheme == THEME_DARK) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
        setContentView(R.layout.activity_main)

        screenFlipper = findViewById(R.id.screenFlipper)
        status = findViewById(R.id.status)
        enabledSwitch = findViewById(R.id.enabledSwitch)
        nameModeSpinner = findViewById(R.id.nameModeSpinner)
        codeSwitch = findViewById(R.id.codeSwitch)
        callsSwitch = findViewById(R.id.callsSwitch)
        silentSwitch = findViewById(R.id.silentSwitch)
        notificationAccessSwitch = findViewById(R.id.notificationAccessSwitch)
        showNotificationsSwitch = findViewById(R.id.showNotificationsSwitch)
        batterySwitch = findViewById(R.id.batterySwitch)
        autostartSwitch = findViewById(R.id.autostartSwitch)
        todayCount = findViewById(R.id.todayCount)
        todayTotal = findViewById(R.id.todayTotal)
        historyText = findViewById(R.id.historyText)

        val root = findViewById<View>(R.id.root)
        val initialTop = root.paddingTop
        val initialBottom = root.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(view.paddingLeft, initialTop + bars.top, view.paddingRight, initialBottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)

        navInicio = findViewById(R.id.navInicio)
        navVoz = findViewById(R.id.navVoz)
        navLectura = findViewById(R.id.navLectura)
        navAjustes = findViewById(R.id.navAjustes)

        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)

        val modes = listOf("Solo primer nombre", "Nombre y apellido")
        nameModeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            modes
        )

        val savedMode = prefs.getString(
            YapeNotificationListener.KEY_NAME_MODE,
            YapeNotificationListener.NAME_FIRST
        ) ?: YapeNotificationListener.NAME_FIRST

        nameModeSpinner.setSelection(
            if (savedMode == YapeNotificationListener.NAME_FULL) 1 else 0
        )

        nameModeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val value = if (position == 1) {
                    YapeNotificationListener.NAME_FULL
                } else {
                    YapeNotificationListener.NAME_FIRST
                }
                prefs.edit().putString(YapeNotificationListener.KEY_NAME_MODE, value).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        enabledSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)
        codeSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_READ_CODE, false)
        callsSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
        silentSwitch.isChecked = prefs.getBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)

        enabledSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_ENABLED, checked).apply()
            if (checked) {
                startProtection()
            } else {
                YapeWatchdogService.stop(this)
            }
            updateStatus()
        }

        codeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_READ_CODE, checked).apply()
        }

        callsSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, checked).apply()
        }

        silentSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, checked).apply()
        }

        findViewById<Button>(R.id.testButtonVoice).setOnClickListener {
            YapeNotificationListener.testSpeech(this)
        }

        findViewById<Button>(R.id.reactivateButton).setOnClickListener {
            reactivateService()
        }

        findViewById<Button>(R.id.notificationsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        notificationAccessSwitch.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        findViewById<Button>(R.id.showNotificationsButton).setOnClickListener {
            openAppNotificationSettings()
        }
        showNotificationsSwitch.setOnClickListener {
            openAppNotificationSettings()
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            openBatterySettings()
        }
        batterySwitch.setOnClickListener {
            openBatterySettings()
        }

        findViewById<Button>(R.id.autostartButton).setOnClickListener {
            confirmAndOpenAutoStart()
        }
        autostartSwitch.setOnClickListener {
            confirmAndOpenAutoStart()
        }

        if (isSamsungDevice()) {
            (findViewById<Button>(R.id.autostartButton).parent as? View)?.visibility = View.GONE
        }

        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            showScreen(3)
        }

        setupSettings()

        findViewById<Button>(R.id.voiceSettingsButton).setOnClickListener {
            openTtsSettings()
        }

        setupNavigation()
        showScreen(0)
        startProtection()
        updateStatus()
        updateStats()
        applyTheme(savedTheme)

        if (!prefs.getBoolean(KEY_FIRST_SETUP_DONE, false)) {
            firstSetupHandler.postDelayed({ startFirstSetup() }, 500L)
        }
    }

    override fun onResume() {
        super.onResume()
        if (firstSetupWaitingForReturn) {
            firstSetupWaitingForReturn = false
            firstSetupHandler.postDelayed({ continueFirstSetup() }, 450L)
        }
        startProtection()
        YapeNotificationListener.syncDefaultVoice(this)
        updatePermissionSwitches()
        val savedTheme = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
            .getString(KEY_THEME, THEME_LIGHT) ?: THEME_LIGHT
        applyTheme(savedTheme)
        updateStatus()
        updateStats()
        statusHandler.removeCallbacks(statusRunnable)
        statusHandler.postDelayed(statusRunnable, 1000L)
    }

    override fun onPause() {
        statusHandler.removeCallbacks(statusRunnable)
        super.onPause()
    }


    private fun openBatterySettings() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun updatePermissionSwitches() {
        notificationAccessSwitch.isChecked = isNotificationListenerEnabled()
        showNotificationsSwitch.isChecked = if (Build.VERSION.SDK_INT >= 33) {
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        } else {
            val nm = getSystemService(android.app.NotificationManager::class.java)
            nm?.areNotificationsEnabled() == true
        }
        val pm = getSystemService(PowerManager::class.java)
        batterySwitch.isChecked = pm?.isIgnoringBatteryOptimizations(packageName) == true
        if (isSamsungDevice()) {
            autostartSwitch.isChecked = false
        } else {
            autostartSwitch.isChecked = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
                .getBoolean(KEY_AUTOSTART_CONFIRMED, false)
        }
    }


    private fun confirmAndOpenAutoStart() {
        if (isSamsungDevice()) return
        getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTOSTART_CONFIRMED, true).apply()
        autostartSwitch.isChecked = true
        openAutoStartSettings()
    }

    private fun isSamsungDevice(): Boolean =
        Build.MANUFACTURER.lowercase(Locale.ROOT).contains("samsung")

    private fun applyTheme(theme: String) {
        val dark = theme == THEME_DARK
        val root = findViewById<View>(R.id.root)
        if (!dark) {
            root.setBackgroundColor(Color.rgb(250, 249, 253))
            findViewById<View>(R.id.bottomNav).setBackgroundColor(Color.WHITE)
            window.statusBarColor = Color.rgb(33, 22, 83)
            window.navigationBarColor = Color.WHITE
            findViewById<Button>(R.id.settingsButton).backgroundTintList = ColorStateList.valueOf(Color.rgb(91, 32, 216))
            return
        }

        val surface = Color.rgb(43, 40, 51)
        val primary = Color.WHITE
        val secondary = Color.rgb(205, 198, 216)
        val accent = Color.rgb(132, 84, 238)
        root.setBackgroundColor(Color.rgb(20, 18, 25))
        findViewById<View>(R.id.bottomNav).setBackgroundColor(Color.rgb(27, 24, 34))
        findViewById<Button>(R.id.settingsButton).backgroundTintList = ColorStateList.valueOf(accent)
        applyDarkThemeRecursive(root, surface, primary, secondary)
        window.statusBarColor = Color.rgb(14, 12, 18)
        window.navigationBarColor = Color.rgb(14, 12, 18)
    }

    private fun applyDarkThemeRecursive(view: View, surface: Int, primary: Int, secondary: Int) {
        if (view is TextView) {
            val c = view.currentTextColor
            if (c != Color.WHITE && c != Color.rgb(233, 225, 255) && c != Color.rgb(228, 255, 240)) {
                view.setTextColor(secondary)
            }
        }
        if (view is Button) {
            val t = view.text.toString()
            if (t.contains("Abrir configuración") || t.contains("Restablecer") || t.contains("Reactivar") || t.contains("Inicio") || t.contains("Lectura") || t.contains("Voz") || t.contains("Resumen")) {
                view.setTextColor(primary)
            }
        }
        if (view is LinearLayout && view.id != R.id.root && view.id != R.id.bottomNav) {
            view.backgroundTintList = ColorStateList.valueOf(surface)
        }
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                applyDarkThemeRecursive(view.getChildAt(i), surface, primary, secondary)
            }
        }
    }

    private fun isXiaomiDevice(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase(Locale.ROOT)
        return manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco")
    }

    private fun startFirstSetup() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_FIRST_SETUP_DONE, false)) return
        firstSetupStage = 0
        continueFirstSetup()
    }

    private fun continueFirstSetup() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_FIRST_SETUP_DONE, false)) return

        when (firstSetupStage) {
            0 -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_POST_NOTIFICATIONS)
                    return
                }
                firstSetupStage = 1
                continueFirstSetup()
            }
            1 -> {
                if (!isNotificationListenerEnabled()) {
                    firstSetupWaitingForReturn = true
                    startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    return
                }
                firstSetupStage = 2
                continueFirstSetup()
            }
            2 -> {
                val pm = getSystemService(PowerManager::class.java)
                if (pm?.isIgnoringBatteryOptimizations(packageName) != true) {
                    firstSetupWaitingForReturn = true
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }
                    return
                }
                firstSetupStage = 3
                continueFirstSetup()
            }
            3 -> {
                firstSetupStage = 4
                firstSetupWaitingForReturn = true
                openAutoStartSettings()
            }
            else -> {
                prefs.edit().putBoolean(KEY_FIRST_SETUP_DONE, true).apply()
                Toast.makeText(this, "Configuración inicial lista. Yape Voz está preparado.", Toast.LENGTH_SHORT).show()
                updateStatus()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_POST_NOTIFICATIONS) {
            firstSetupStage = 1
            firstSetupHandler.postDelayed({ continueFirstSetup() }, 300L)
        }
    }

    private fun openAppNotificationSettings() {
        try {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            })
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
    }

    private fun openAutoStartSettings() {
        // Xiaomi/Redmi/POCO: abre directamente la pantalla de
        // "Autoencendido" (Autostart) de Seguridad. Xiaomi expone
        // esta pantalla mediante SecurityCenter; el usuario debe
        // activar manualmente Yape Voz.
        val xiaomiIntent = Intent().apply {
            component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
        }
        try {
            if (xiaomiIntent.resolveActivity(packageManager) != null) {
                startActivity(xiaomiIntent)
                return
            }
        } catch (_: Exception) {}

        // Algunas versiones de HyperOS exponen una acción propia.
        val hyperOsIntent = Intent("miui.intent.action.OP_AUTO_START").apply {
            setPackage("com.miui.securitycenter")
            data = Uri.parse("package:$packageName")
        }
        try {
            if (hyperOsIntent.resolveActivity(packageManager) != null) {
                startActivity(hyperOsIntent)
                return
            }
        } catch (_: Exception) {}

        // Último recurso: información de la aplicación.
        val appDetails = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
        }
        try {
            startActivity(appDetails)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updateStats() {
        val summary = YapeNotificationListener.getTodaySummary(this)
        todayCount.text = summary.first.toString()
        todayTotal.text = String.format(Locale.US, "S/ %.2f", summary.second / 100.0)
        historyText.text = YapeNotificationListener.getHistoryText(this)
    }

    private fun setupSettings() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        val lightRadio = findViewById<RadioButton>(R.id.themeLightRadio)
        val darkRadio = findViewById<RadioButton>(R.id.themeDarkRadio)
        val volumeBar = findViewById<SeekBar>(R.id.settingsVolumeSeekBar)
        val volumeValue = findViewById<TextView>(R.id.settingsVolumeValue)

        fun refreshSettingsControls() {
            val dark = prefs.getString(KEY_THEME, THEME_LIGHT) == THEME_DARK
            lightRadio.isChecked = !dark
            darkRadio.isChecked = dark
            val volume = prefs.getFloat(YapeNotificationListener.KEY_TTS_VOLUME, YapeNotificationListener.DEFAULT_TTS_VOLUME)
                .coerceIn(YapeNotificationListener.MIN_TTS_VOLUME, YapeNotificationListener.MAX_TTS_VOLUME)
            volumeBar.progress = (volume * 100f).toInt().coerceIn(0, 100)
            volumeValue.text = String.format(Locale.US, "%d%%", (volume * 100).toInt())
        }

        lightRadio.setOnClickListener {
            prefs.edit().putString(KEY_THEME, THEME_LIGHT).apply()
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        darkRadio.setOnClickListener {
            prefs.edit().putString(KEY_THEME, THEME_DARK).apply()
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
        volumeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = (progress.coerceIn(0, 100) / 100f).coerceIn(
                    YapeNotificationListener.MIN_TTS_VOLUME, YapeNotificationListener.MAX_TTS_VOLUME
                )
                prefs.edit().putFloat(YapeNotificationListener.KEY_TTS_VOLUME, value).apply()
                volumeValue.text = String.format(Locale.US, "%d%%", (value * 100).toInt())
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        findViewById<Button>(R.id.backSettingsButton).setOnClickListener { showScreen(0) }
        findViewById<Button>(R.id.resetSettingsButton).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Restablecer ajustes")
                .setMessage("Se restaurarán los ajustes de Yape Voz Pro a sus valores predeterminados.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Restablecer") { _, _ ->
                    prefs.edit()
                        .putBoolean(YapeNotificationListener.KEY_ENABLED, true)
                        .putBoolean(YapeNotificationListener.KEY_READ_CODE, false)
                        .putBoolean(YapeNotificationListener.KEY_SKIP_CALLS, true)
                        .putBoolean(YapeNotificationListener.KEY_RESPECT_SILENT, true)
                        .putString(YapeNotificationListener.KEY_NAME_MODE, YapeNotificationListener.NAME_FIRST)
                        .putFloat(YapeNotificationListener.KEY_TTS_VOLUME, YapeNotificationListener.DEFAULT_TTS_VOLUME)
                        .putString(KEY_THEME, THEME_LIGHT)
                        .apply()
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                }
                .show()
        }
        findViewById<Button>(R.id.aboutButton).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Yape Voz Pro")
                .setMessage("Versión 2.7.3\n\nAnuncia tus pagos de Yape en voz alta.\n\nMantén activados los permisos necesarios para que el servicio funcione en segundo plano.")
                .setPositiveButton("Aceptar", null)
                .show()
        }
        refreshSettingsControls()
    }

    private fun setupNavigation() {
        navInicio.setOnClickListener { showScreen(0) }
        navLectura.setOnClickListener { showScreen(1) }
        navVoz.setOnClickListener { showScreen(2) }
        navAjustes.setOnClickListener { showScreen(4) }
    }

    private fun showScreen(index: Int) {
        screenFlipper.displayedChild = index

        val selected = "#5B20D8"
        val normal = "#776F87"
        navInicio.setTextColor(if (index == 0) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navLectura.setTextColor(if (index == 1) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navVoz.setTextColor(if (index == 2) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))
        navAjustes.setTextColor(if (index == 4) android.graphics.Color.parseColor(selected) else android.graphics.Color.parseColor(normal))

        navInicio.setBackgroundResource(if (index == 0) R.drawable.bg_selected_nav else android.R.color.transparent)
        navLectura.setBackgroundResource(if (index == 1) R.drawable.bg_selected_nav else android.R.color.transparent)
        navVoz.setBackgroundResource(if (index == 2) R.drawable.bg_selected_nav else android.R.color.transparent)
        navAjustes.setBackgroundResource(if (index == 4) R.drawable.bg_selected_nav else android.R.color.transparent)
    }

    private fun openTtsSettings() {
        val intents = listOf(
            Intent("com.android.settings.TTS_SETTINGS").setPackage("com.android.settings"),
            Intent("android.settings.TTS_SETTINGS"),
            Intent("com.android.settings.TTS_SETTINGS"),
            Intent("android.settings.TEXT_TO_SPEECH_SETTINGS")
        )

        for (intent in intents) {
            try {
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                    return
                }
            } catch (_: ActivityNotFoundException) {
                // Intentar la siguiente opción.
            }
        }

        try {
            startActivity(Intent(Settings.ACTION_SOUND_SETTINGS))
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun startProtection() {
        val prefs = getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
        if (prefs.getBoolean(YapeNotificationListener.KEY_ENABLED, true)) {
            YapeWatchdogService.start(this)
        }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        ) ?: return false
        return enabled.contains(packageName)
    }

    private fun reactivateService() {
        if (!isNotificationListenerEnabled()) {
            Toast.makeText(
                this,
                "Activa primero el acceso a notificaciones de Yape Voz.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return
        }

        getSharedPreferences(YapeNotificationListener.PREFS, MODE_PRIVATE)
            .edit().putBoolean(YapeNotificationListener.KEY_ENABLED, true).apply()
        enabledSwitch.isChecked = true
        YapeWatchdogService.start(this)

        Toast.makeText(this, "Servicio de Yape Voz reactivado.", Toast.LENGTH_SHORT).show()
        updateStatus()
    }

    private fun updateStatus() {
        val listenerAccess = isNotificationListenerEnabled()
        val connected = YapeNotificationListener.isConnected(this)
        val watchdog = YapeWatchdogService.isRunning(this)

        val pm = getSystemService(PowerManager::class.java)
        val batteryOk = pm?.isIgnoringBatteryOptimizations(packageName) == true

        status.text = buildString {
            append(if (connected) "✓ Escuchando notificaciones de Yape\n" else if (listenerAccess) "⚠ Acceso activo, pero el lector no está conectado\n" else "⚠ Falta acceso a notificaciones\n")
            append(if (watchdog) "✓ Protección en segundo plano activa\n" else "⚠ Protección en segundo plano detenida\n")
            append(if (batteryOk) "✓ Batería sin restricciones\n" else "⚠ Falta quitar restricción de batería\n")
            append(if (enabledSwitch.isChecked) "✓ Yape Voz está ACTIVADA" else "⏸ Yape Voz está PAUSADA")
        }
    }

    companion object {
        private const val REQUEST_POST_NOTIFICATIONS = 9001
        private const val KEY_FIRST_SETUP_DONE = "first_setup_done"
        private const val KEY_AUTOSTART_CONFIRMED = "autostart_confirmed"
        private const val KEY_THEME = "theme"
        private const val THEME_LIGHT = "light"
        private const val THEME_DARK = "dark"
    }
}
